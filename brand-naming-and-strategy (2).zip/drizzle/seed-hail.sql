-- Sürücülü yolculuk pilot verisi. TÜMÜ is_demo=true, arayüzde etiketli.
INSERT INTO users (email, full_name, phone, role, passcode) VALUES
  ('surucu@anbean.com.tr','Kerem Bal','05321000001','surucu','1234'),
  ('guvenlik@anbean.com.tr','Aylin Doruk','05321000002','guvenlik','1234')
ON CONFLICT (email) DO NOTHING;

INSERT INTO chauffeur_tariffs (code, name, base_kurus, per_km_kurus, per_min_kurus, min_fare_kurus, night_surcharge_percent, airport_surcharge_kurus, cancel_fee_kurus, commission_percent) VALUES
  ('suruculu_standart','Sürücülü Standart',4500,1800,350,12000,25,15000,5000,15),
  ('suruculu_konfor','Sürücülü Konfor',8000,2600,500,20000,25,20000,8000,18)
ON CONFLICT (code) DO NOTHING;

-- 2 doğrulanmış demo sürücü + 1 aday
INSERT INTO chauffeur_profiles (user_id, full_name, phone_masked, city, status, verification_level, is_verified, commercial_docs_verified, availability, rating_sum, rating_count, total_trips, accepted_offers, last_lat, last_lng, last_location_at, is_demo)
SELECT u.id, v.full_name, v.phone_masked, 'İstanbul', v.status, v.verification_level, v.is_verified, v.commercial_docs_verified, v.availability, v.rating_sum, v.rating_count, v.total_trips, v.accepted_offers, v.lat, v.lng, now(), true
FROM (VALUES
  ('surucu@anbean.com.tr','Kerem Bal','053*****01','aktif','ileri',true,true,'online_idle',44,10,38,31,41.0082,29.0100),
  (NULL,'Nuran Şen','053*****02','aktif','ileri',true,true,'online_idle',39,8,27,22,41.0351,28.9833),
  (NULL,'Baran Efe','053*****03','belge_bekliyor','temel',false,false,'offline',0,0,0,0,NULL,NULL)
) AS v(user_email, full_name, phone_masked, status, verification_level, is_verified, commercial_docs_verified, availability, rating_sum, rating_count, total_trips, accepted_offers, lat, lng)
LEFT JOIN users u ON u.email = v.user_email
WHERE NOT EXISTS (SELECT 1 FROM chauffeur_profiles cp WHERE cp.full_name = v.full_name);

-- Belgeler: doğrulanmış sürücülerde approved, adayda not_uploaded
INSERT INTO chauffeur_documents (chauffeur_id, doc_type, status, issued_at, expires_at, storage_ref)
SELECT cp.id, d.doc_type,
       CASE WHEN cp.commercial_docs_verified THEN 'approved' ELSE 'not_uploaded' END,
       CASE WHEN cp.commercial_docs_verified THEN now() - interval '200 days' ELSE NULL END,
       CASE WHEN cp.commercial_docs_verified THEN now() + interval '500 days' ELSE NULL END,
       CASE WHEN cp.commercial_docs_verified THEN 'metadata-only:'||d.doc_type ELSE '' END
FROM chauffeur_profiles cp
CROSS JOIN (VALUES ('identity'),('driver_license'),('vehicle_registration'),('insurance'),('criminal_record'),('commercial_license')) AS d(doc_type)
WHERE NOT EXISTS (SELECT 1 FROM chauffeur_documents cd WHERE cd.chauffeur_id=cp.id AND cd.doc_type=d.doc_type);

INSERT INTO chauffeur_vehicles (chauffeur_id, plate, make, model, year, color, seat_count, vehicle_type, ownership, is_active, documents_verified, is_demo)
SELECT cp.id, v.plate, v.make, v.model, v.year, v.color, v.seats, v.vtype, 'platform', true, cp.commercial_docs_verified, true
FROM (VALUES
  ('Kerem Bal','34 ABC 111','Renault','Clio',2021,'Beyaz',4,'standard'),
  ('Nuran Şen','34 XYZ 222','Fiat','Egea',2022,'Gri',4,'comfort'),
  ('Baran Efe','34 DEF 333','Toyota','Corolla',2019,'Siyah',4,'standard')
) AS v(driver, plate, make, model, year, color, seats, vtype)
JOIN chauffeur_profiles cp ON cp.full_name = v.driver
WHERE NOT EXISTS (SELECT 1 FROM chauffeur_vehicles cv WHERE cv.plate = v.plate);

-- Sürücü cüzdanları
INSERT INTO wallets (owner_kind, owner_id, balance_kurus)
SELECT 'chauffeur', cp.id, 0 FROM chauffeur_profiles cp
WHERE NOT EXISTS (SELECT 1 FROM wallets w WHERE w.owner_kind='chauffeur' AND w.owner_id=cp.id);

-- Güvenilen kişi (telefon özeti ile, düz metin yok)
INSERT INTO trusted_contacts (user_id, name, phone_hash, phone_masked)
SELECT u.id, 'Anne', encode(digest('5551234567','sha256'),'hex'), '055*****67'
FROM users u WHERE u.email='musteri@anbean.com.tr'
  AND NOT EXISTS (SELECT 1 FROM trusted_contacts tc WHERE tc.user_id=u.id AND tc.name='Anne');
