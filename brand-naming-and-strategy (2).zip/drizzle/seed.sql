-- ANBEAN seed — idempotent
BEGIN;

INSERT INTO organizations (name, slug, type) VALUES
  ('Anbean Bireysel', 'bireysel', 'bireysel'),
  ('Moda Butik', 'moda-butik', 'isletme'),
  ('Kadıköy Teknoloji A.Ş.', 'kadikoy-teknoloji', 'kurumsal')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO users (email, full_name, phone, role, org_id, passcode) VALUES
  ('musteri@anbean.com.tr', 'Elif Demir', '05321110011', 'musteri', (SELECT id FROM organizations WHERE slug='moda-butik'), '1234'),
  ('kurye@anbean.com.tr', 'Mert Aksoy', '05322220022', 'kurye', NULL, '1234'),
  ('ops@anbean.com.tr', 'Burcu Yılmaz', '05323330033', 'ops', NULL, '1234'),
  ('admin@anbean.com.tr', 'Can Öztürk', '05324440044', 'admin', NULL, '1234')
ON CONFLICT (email) DO NOTHING;

INSERT INTO tariffs (code, name, description, base_kurus, per_km_kurus, per_kg_kurus, sla_minutes, accent_status) VALUES
  ('sehir_ici', 'Şehir İçi', 'Aynı şehir içinde, aynı gün teslim. Standart operasyon penceresi.', 7900, 950, 1200, 300, 'transit'),
  ('ekspres', 'Ekspres', 'Alımdan itibaren 90 dakika hedefli, önceliklendirilmiş kurye ataması.', 14900, 1450, 1600, 90, 'waiting'),
  ('kurumsal', 'Kurumsal', 'Sözleşmeli hacim, API entegrasyonu ve SLA raporlaması.', 5900, 780, 900, 240, 'delivered')
ON CONFLICT (code) DO NOTHING;

INSERT INTO service_zones (city, district, zone_code, surcharge_kurus) VALUES
  ('İstanbul', 'Kadıköy', 'IST-A', 0),
  ('İstanbul', 'Beşiktaş', 'IST-A', 0),
  ('İstanbul', 'Şişli', 'IST-A', 0),
  ('İstanbul', 'Üsküdar', 'IST-A', 0),
  ('İstanbul', 'Bakırköy', 'IST-B', 1500),
  ('İstanbul', 'Maltepe', 'IST-B', 1500),
  ('İstanbul', 'Beylikdüzü', 'IST-C', 3500),
  ('İstanbul', 'Pendik', 'IST-C', 3500),
  ('Ankara', 'Çankaya', 'ANK-A', 0),
  ('İzmir', 'Konak', 'IZM-A', 0)
ON CONFLICT DO NOTHING;

INSERT INTO media_slots (slot_key, query, kind, provider_id, url, credit, fallback_css) VALUES
  ('home.hero', 'courier delivery van city street', 'gradyan', '', '', 'Pexels',
    'radial-gradient(900px 480px at 15% 10%, rgba(255,92,53,0.30), transparent 60%), radial-gradient(700px 420px at 85% 25%, rgba(37,99,235,0.28), transparent 60%), linear-gradient(180deg,#0B1220,#0a101c)'),
  ('home.trust', 'smiling courier with parcel', 'foto', '7843937',
    'https://images.pexels.com/photos/7843937/pexels-photo-7843937.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', 'Pexels — Kampus Production', ''),
  ('services.city', 'delivery van night city lights', 'foto', '7363197',
    'https://images.pexels.com/photos/7363197/pexels-photo-7363197.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', 'Pexels — RDNE Stock project', ''),
  ('services.corporate', 'logistics warehouse conveyor packages', 'foto', '10834810',
    'https://images.pexels.com/photos/10834810/pexels-photo-10834810.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', 'Pexels — Ihsan Adityawarman', ''),
  ('corporate.hero', 'city aerial dusk traffic', 'foto', '1267329',
    'https://images.pexels.com/photos/1267329/pexels-photo-1267329.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', 'Pexels — ELEVATE', ''),
  ('courier.apply', 'cargo bike courier urban', 'foto', '7843984',
    'https://images.pexels.com/photos/7843984/pexels-photo-7843984.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', 'Pexels — Kampus Production', '')
ON CONFLICT (slot_key) DO NOTHING;

INSERT INTO cms_pages (slug, title, body) VALUES
  ('hakkimizda', 'Hakkımızda', 'Anbean, şehir içi teslimatta belirsizliği ortadan kaldırmak için kuruldu. Vaadimiz hız değil görünürlük: gönderinin nerede olduğunu an be an bilmek.'),
  ('iletisim', 'İletişim', 'Merkez: Kadıköy / İstanbul · destek@anbean.com.tr · 0850 000 00 00'),
  ('kvkk', 'KVKK Aydınlatma Metni', 'Kişisel verileriniz yalnızca teslimat hizmetinin ifası amacıyla işlenir. Takip sayfasında adres ve telefon bilgisi gösterilmez.')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO couriers (user_id, full_name, phone, city, vehicle, status, active_load, last_lat, last_lng, last_seen_at) VALUES
  ((SELECT id FROM users WHERE email='kurye@anbean.com.tr'), 'Mert Aksoy', '05322220022', 'İstanbul', 'motosiklet', 'aktif', 1, 40.9901, 29.0275, now()),
  (NULL, 'Seda Kaya', '05325550055', 'İstanbul', 'motosiklet', 'aktif', 0, 41.0422, 29.0094, now()),
  (NULL, 'Onur Şahin', '05326660066', 'İstanbul', 'panelvan', 'aktif', 2, 41.0138, 28.9497, now()),
  (NULL, 'Deniz Arslan', '05327770077', 'İstanbul', 'bisiklet', 'evrak_bekliyor', 0, NULL, NULL, NULL)
ON CONFLICT DO NOTHING;

COMMIT;

-- Tur 4: hero video slotu + append-only triggerlar
UPDATE media_slots SET kind='video', provider_id='11533609',
  url='https://videos.pexels.com/video-files/11533609/11533609-hd_1280_720_60fps.mp4',
  poster_url='https://images.pexels.com/videos/11533609/pexels-photo-11533609.jpeg?auto=compress&cs=tinysrgb&w=1280',
  credit='Pexels — Altaf Shah', query='birds eye view street night'
WHERE slot_key='home.hero';

-- Append-only: ledger ve denetim kaydi veritabani seviyesinde degistirilemez.
CREATE OR REPLACE FUNCTION anbean_append_only() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'append-only: % tablosunda % yasak, duzeltme ters kayitla yapilir', TG_TABLE_NAME, TG_OP;
END;
$$;
DROP TRIGGER IF EXISTS ledger_entries_append_only ON ledger_entries;
CREATE TRIGGER ledger_entries_append_only BEFORE UPDATE OR DELETE ON ledger_entries FOR EACH ROW EXECUTE FUNCTION anbean_append_only();
DROP TRIGGER IF EXISTS ledger_entries_no_truncate ON ledger_entries;
CREATE TRIGGER ledger_entries_no_truncate BEFORE TRUNCATE ON ledger_entries FOR EACH STATEMENT EXECUTE FUNCTION anbean_append_only();
DROP TRIGGER IF EXISTS audit_log_append_only ON audit_log;
CREATE TRIGGER audit_log_append_only BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION anbean_append_only();
DROP TRIGGER IF EXISTS audit_log_no_truncate ON audit_log;
CREATE TRIGGER audit_log_no_truncate BEFORE TRUNCATE ON audit_log FOR EACH STATEMENT EXECUTE FUNCTION anbean_append_only();

-- Tur 5: finans ve destek demo hesaplari (rol matrisi testleri icin)
INSERT INTO users (email, full_name, phone, role, passcode) VALUES
  ('finans@anbean.com.tr','Selin Kara','05328880088','finance','1234'),
  ('destek@anbean.com.tr','Emre Tan','05329990099','support','1234')
ON CONFLICT (email) DO NOTHING;

-- Tur 6: riza kayitlari append-only (geri cekme yeni kayitla olur, silme yok)
DROP TRIGGER IF EXISTS consents_append_only ON consents;
CREATE TRIGGER consents_append_only BEFORE UPDATE OR DELETE ON consents FOR EACH ROW EXECUTE FUNCTION anbean_append_only();
DROP TRIGGER IF EXISTS consents_no_truncate ON consents;
CREATE TRIGGER consents_no_truncate BEFORE TRUNCATE ON consents FOR EACH STATEMENT EXECUTE FUNCTION anbean_append_only();
-- Sürücülü yolculuk pilot verisi. TÜMÜ is_demo=true, arayüzde etiketli.
INSERT INTO users (email, full_name, phone, role, passcode) VALUES
  ('surucu@anbean.com.tr','Kerem Bal','05321000001','surucu','1234'),
  ('guvenlik@anbean.com.tr','Aylin Doruk','05321000002','guvenlik','1234')
ON CONFLICT (email) DO NOTHING;

INSERT INTO chauffeur_tariffs (code, name, base_kurus, per_km_kurus, per_min_kurus, min_fare_kurus, night_surcharge_percent, airport_surcharge_kurus, cancel_fee_kurus, commission_percent) VALUES
  ('suruculu_standart','Sürücülü Standart',4500,1800,350,12000,25,15000,5000,15),
  ('suruculu_konfor','Sürücülü Konfor',8000,2600,500,20000,25,20000,8000,18)
ON CONFLICT (code) DO NOTHING;

-- 2 doğrulanmış demo sürücü + 1 aday
INSERT INTO chauffeur_profiles (user_id, full_name, phone_masked, city, status, verification_level, is_verified, commercial_docs_verified, availability, rating_sum, rating_count, total_trips, accepted_offers, last_lat, last_lng, last_location_at, is_demo)
SELECT u.id, v.full_name, v.phone_masked, 'İstanbul', v.status, v.verification_level, v.is_verified, v.commercial_docs_verified, v.availability, v.rating_sum, v.rating_count, v.total_trips, v.accepted_offers, v.lat, v.lng, now(), true
FROM (VALUES
  ('surucu@anbean.com.tr','Kerem Bal','053*****01','aktif','ileri',true,true,'online_idle',44,10,38,31,41.0082,29.0100),
  (NULL,'Nuran Şen','053*****02','aktif','ileri',true,true,'online_idle',39,8,27,22,41.0351,28.9833),
  (NULL,'Baran Efe','053*****03','belge_bekliyor','temel',false,false,'offline',0,0,0,0,NULL,NULL)
) AS v(user_email, full_name, phone_masked, status, verification_level, is_verified, commercial_docs_verified, availability, rating_sum, rating_count, total_trips, accepted_offers, lat, lng)
LEFT JOIN users u ON u.email = v.user_email
WHERE NOT EXISTS (SELECT 1 FROM chauffeur_profiles cp WHERE cp.full_name = v.full_name);

-- Belgeler: doğrulanmış sürücülerde approved, adayda not_uploaded
INSERT INTO chauffeur_documents (chauffeur_id, doc_type, status, issued_at, expires_at, storage_ref)
SELECT cp.id, d.doc_type,
       CASE WHEN cp.commercial_docs_verified THEN 'approved' ELSE 'not_uploaded' END,
       CASE WHEN cp.commercial_docs_verified THEN now() - interval '200 days' ELSE NULL END,
       CASE WHEN cp.commercial_docs_verified THEN now() + interval '500 days' ELSE NULL END,
       CASE WHEN cp.commercial_docs_verified THEN 'metadata-only:'||d.doc_type ELSE '' END
FROM chauffeur_profiles cp
CROSS JOIN (VALUES ('identity'),('driver_license'),('vehicle_registration'),('insurance'),('criminal_record'),('commercial_license')) AS d(doc_type)
WHERE NOT EXISTS (SELECT 1 FROM chauffeur_documents cd WHERE cd.chauffeur_id=cp.id AND cd.doc_type=d.doc_type);

INSERT INTO chauffeur_vehicles (chauffeur_id, plate, make, model, year, color, seat_count, vehicle_type, ownership, is_active, documents_verified, is_demo)
SELECT cp.id, v.plate, v.make, v.model, v.year, v.color, v.seats, v.vtype, 'platform', true, cp.commercial_docs_verified, true
FROM (VALUES
  ('Kerem Bal','34 ABC 111','Renault','Clio',2021,'Beyaz',4,'standard'),
  ('Nuran Şen','34 XYZ 222','Fiat','Egea',2022,'Gri',4,'comfort'),
  ('Baran Efe','34 DEF 333','Toyota','Corolla',2019,'Siyah',4,'standard')
) AS v(driver, plate, make, model, year, color, seats, vtype)
JOIN chauffeur_profiles cp ON cp.full_name = v.driver
WHERE NOT EXISTS (SELECT 1 FROM chauffeur_vehicles cv WHERE cv.plate = v.plate);

-- Sürücü cüzdanları
INSERT INTO wallets (owner_kind, owner_id, balance_kurus)
SELECT 'chauffeur', cp.id, 0 FROM chauffeur_profiles cp
WHERE NOT EXISTS (SELECT 1 FROM wallets w WHERE w.owner_kind='chauffeur' AND w.owner_id=cp.id);

-- Güvenilen kişi (telefon özeti ile, düz metin yok)
INSERT INTO trusted_contacts (user_id, name, phone_hash, phone_masked)
SELECT u.id, 'Anne', encode(digest('5551234567','sha256'),'hex'), '055*****67'
FROM users u WHERE u.email='musteri@anbean.com.tr'
  AND NOT EXISTS (SELECT 1 FROM trusted_contacts tc WHERE tc.user_id=u.id AND tc.name='Anne');
-- Yönetim paneli demo verisi. Gerçek kişisel veri YOK; tümü sahte.
INSERT INTO users (email, full_name, phone, role, passcode) VALUES
  ('editor@anbean.com.tr','Deniz Aklar','05321000010','editor','1234'),
  ('isletme@anbean.com.tr','Moda Butik Yetkilisi','05321000011','isletme_sahibi','1234'),
  ('personel@anbean.com.tr','Moda Butik Personeli','05321000012','isletme_calisani','1234'),
  ('sahip@anbean.com.tr','Platform Sahibi','05321000013','super_admin','1234')
ON CONFLICT (email) DO NOTHING;

INSERT INTO plans (code, name, monthly_kurus, shipment_limit, seat_limit, courier_limit, features) VALUES
  ('baslangic','Başlangıç',99000,200,2,0,'["Panel","Takip","E-posta destek"]'),
  ('buyume','Büyüme',499000,2000,10,5,'["Panel","Takip","API","Webhook","Öncelikli destek"]'),
  ('kurumsal','Kurumsal',1999000,20000,50,25,'["Panel","API","Özel tarife","SLA raporu","Hesap yöneticisi"]')
ON CONFLICT (code) DO NOTHING;

-- İşletme dosyası alanları
UPDATE organizations SET category='Perakende', description='Moda semtinde butik giyim. Aynı gün teslimat için Anbean kullanıyor.',
  contact_email='info@modabutik.example', contact_phone='02160000000', city='İstanbul', district='Kadıköy',
  working_hours='{"pazartesi":"09:00-19:00","sali":"09:00-19:00","cumartesi":"10:00-18:00"}'::jsonb,
  verification_status='dogrulandi' WHERE slug='moda-butik' AND category='';
UPDATE organizations SET category='Teknoloji', description='Kurumsal gönderi hacmi olan teknoloji şirketi.',
  contact_email='lojistik@kadikoytech.example', city='İstanbul', district='Şişli', verification_status='incelemede'
  WHERE slug='kadikoy-teknoloji' AND category='';

INSERT INTO subscriptions (org_id, plan_id, status, trial_ends_at, current_period_end)
SELECT o.id, p.id, 'aktif', now() + interval '14 days', now() + interval '30 days'
FROM organizations o JOIN plans p ON p.code='buyume' WHERE o.slug='moda-butik'
  AND NOT EXISTS (SELECT 1 FROM subscriptions s WHERE s.org_id=o.id);
INSERT INTO subscriptions (org_id, plan_id, status, trial_ends_at, current_period_end)
SELECT o.id, p.id, 'deneme', now() + interval '7 days', NULL
FROM organizations o JOIN plans p ON p.code='kurumsal' WHERE o.slug='kadikoy-teknoloji'
  AND NOT EXISTS (SELECT 1 FROM subscriptions s WHERE s.org_id=o.id);

INSERT INTO invoices (number, org_id, subscription_id, amount_kurus, tax_kurus, total_kurus, status, due_date, provider_ref, note)
SELECT 'FTR-2026-000001', o.id, s.id, 499000, 99800, 598800, 'gonderildi', now() + interval '7 days', '', 'Ödeme sağlayıcısı bağlı değil; tahsilat simülasyondur.'
FROM organizations o JOIN subscriptions s ON s.org_id=o.id WHERE o.slug='moda-butik'
  AND NOT EXISTS (SELECT 1 FROM invoices i WHERE i.number='FTR-2026-000001');

INSERT INTO org_members (org_id, user_id, org_role)
SELECT o.id, u.id, CASE WHEN u.email='isletme@anbean.com.tr' THEN 'sahip' ELSE 'calisan' END
FROM organizations o CROSS JOIN users u
WHERE o.slug='moda-butik' AND u.email IN ('isletme@anbean.com.tr','personel@anbean.com.tr','musteri@anbean.com.tr')
ON CONFLICT (org_id, user_id) DO NOTHING;
UPDATE users SET org_id=(SELECT id FROM organizations WHERE slug='moda-butik') WHERE email IN ('isletme@anbean.com.tr','personel@anbean.com.tr') AND org_id IS NULL;

-- Kurye CV (demo, sahte veri)
INSERT INTO courier_cv (courier_id, display_name, about, default_visibility, availability_note, vehicle_note, profile_published)
SELECT c.id, 'Mert A.', 'Kadıköy ve çevresinde 4 yıldır şehir içi kuryelik. Yoğun saatlerde ekspres gönderilerde deneyimliyim.',
       'personele_acik', 'Hafta içi 10:00-20:00, cumartesi esnek', 'Motosiklet, 250 cc, kapalı kasa', true
FROM couriers c WHERE c.full_name='Mert Aksoy'
  AND NOT EXISTS (SELECT 1 FROM courier_cv cv WHERE cv.courier_id=c.id);

INSERT INTO courier_cv_items (cv_id, kind, title, org, starts_at, ends_at, description, visibility, sort_index)
SELECT cv.id, v.kind, v.title, v.org, v.starts_at, v.ends_at, v.description, v.visibility, v.sort_index
FROM courier_cv cv
CROSS JOIN (VALUES
  ('experience','Şehir içi kurye','Örnek Lojistik A.Ş.','2022','2025','Günde ortalama 25 gönderi, ekspres ve planlı teslimat.','personele_acik',1),
  ('experience','Depo saha elemanı','Örnek Dağıtım','2020','2022','Barkodlu alım ve sevkiyat hazırlığı.','personele_acik',2),
  ('education','Lise','Örnek Anadolu Lisesi','2016','2020','','gizli',3),
  ('skill','Rota planlama','','','','Şehir içi optimal rota.','herkse_acik',4),
  ('skill','Müşteri iletişimi','','','','Teslim anında profesyonel iletişim.','herkse_acik',5),
  ('certification','A2 ehliyet','','2019','2029','Motosiklet sınıfı.','personele_acik',6),
  ('certification','SRC 2 belgesi','','2021','2026','Yolcu/yük taşıma yeterlilik.','personele_acik',7),
  ('language','Türkçe','','','','Ana dil','herkse_acik',8),
  ('language','İngilizce','','','','B1 — teslimatta temel iletişim','herkse_acik',9),
  ('service_area','Kadıköy','','','','Ana hizmet bölgesi','herkse_acik',10),
  ('service_area','Üsküdar','','','','İkincil bölge','herkse_acik',11)
) AS v(kind, title, org, starts_at, ends_at, description, visibility, sort_index)
WHERE cv.display_name='Mert A.'
  AND NOT EXISTS (SELECT 1 FROM courier_cv_items i WHERE i.cv_id=cv.id AND i.title=v.title AND i.kind=v.kind);

-- CMS: blog ve şablonlar
INSERT INTO blog_posts (slug, title, excerpt, body, category, tags, status, published_at, author_id, meta_title, meta_description)
SELECT v.slug, v.title, v.excerpt, v.body, v.category, v.tags::jsonb, 'yayinda', now(), (SELECT id FROM users WHERE email='editor@anbean.com.tr'), v.title, v.excerpt
FROM (VALUES
  ('durum-renk-seridi','Durum Renk Şeridi nasıl okunur?','Altı segment, tek bakışta gönderi durumu.','Her gönderi yatay bir renk şeridiyle temsil edilir. Dolu segmentler tamamlanan aşamaları, soluk segmentler kalan yolu gösterir. Kırmızı segment istisna, mor segment iade sürecidir.','tasarim','["takip","tasarim"]'),
  ('istisna-kuyrugu','İstisna kuyruğu: başarısız teslimatın anatomisi','Beş dakikalık çözüm taahhüdü nasıl işliyor?','Başarısız teslimat istisna kuyruğuna düşer. Operasyon beş dakika içinde yeniden planlama, iade veya inceleme kararı verir; karar denetim kaydına yazılır.','operasyon','["istisna","operasyon"]'),
  ('tek-cuzdan','Tek bakiye: sipariş, gönderi ve sürüş','Üç hizmet aynı bakiyeden ödeniyor.','Sipariş, kurye gönderisi ve elektrikli araç kiralama ücretleri aynı platform bakiyesinden düşer. Her hareket çift taraflı kayıtla yazılır ve silinemez.','urun','["cuzdan","ledger"]')
) AS v(slug,title,excerpt,body,category,tags)
ON CONFLICT (slug) DO NOTHING;

INSERT INTO email_templates (key, name, channel, subject, body) VALUES
  ('durum_teslim_edildi','Teslim edildi bildirimi','email','Gönderin teslim edildi','{{code}} numaralı gönderin {{district}} ilçesinde teslim edildi.'),
  ('durum_istisna','İstisna bildirimi','email','Gönderinle ilgileniyoruz','{{code}} numaralı gönderinde istisna oluştu. Çözüm taahhüdümüz 5 dakika.'),
  ('surus_basladi','Sürüş başladı','sms','—','Sürüşün başladı. Güvenli sürüşler.'),
  ('hakedis_odendi','Hakediş ödemesi','email','Hakedişin ödendi','{{amount}} tutarındaki hakedişin banka çıkışına alındı.')
ON CONFLICT (key) DO NOTHING;

INSERT INTO platform_settings (key, value, updated_by) VALUES
  ('platform', '{"support_phone":"0850 000 00 00","support_email":"destek@anbean.com.tr","default_city":"İstanbul"}'::jsonb, (SELECT id FROM users WHERE email='admin@anbean.com.tr')),
  ('limits', '{"max_shipment_weight_grams":50000,"max_ride_distance_km":200,"payout_min_kurus":10000}'::jsonb, (SELECT id FROM users WHERE email='admin@anbean.com.tr')),
  ('veri_saklama', '{"location_ttl_days":30,"audit_retention_years":10,"cv_media_retention":"saglayici_secilmedi"}'::jsonb, (SELECT id FROM users WHERE email='admin@anbean.com.tr'))
ON CONFLICT (key) DO NOTHING;

-- CMS sayfalarına sürüm geçmişi (mevcut kayıtlar için v1)
INSERT INTO cms_versions (page_id, version, title, body, status, author_id, change_note)
SELECT p.id, 1, p.title, p.body, p.status, (SELECT id FROM users WHERE email='editor@anbean.com.tr'), 'İlk sürüm (geçmiş kayıtlardan oluşturuldu)'
FROM cms_pages p WHERE NOT EXISTS (SELECT 1 FROM cms_versions v WHERE v.page_id=p.id);
