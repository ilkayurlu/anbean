/**
 * İstemci/sunucu ortak tipleri.
 * Durum etiketleri burada tek kopya tutulur; lib/hail.ts sunucu tarafında
 * kalır (db bağımlılığı olduğu için client bundle'a girmemeli).
 */
export const RIDE_STATUS_LABEL_LOCAL: Record<string, string> = {
  REQUESTED: "Talep alındı",
  MATCHING: "Sürücü aranıyor",
  DRIVER_ASSIGNED: "Sürücü atandı",
  DRIVER_EN_ROUTE: "Sürücü yolda",
  DRIVER_ARRIVED: "Sürücü buluşma noktasında",
  IN_PROGRESS: "Yolculuk sürüyor",
  COMPLETED: "Tamamlandı",
  CANCELLED_BY_PASSENGER: "Yolcu iptal etti",
  CANCELLED_BY_DRIVER: "Sürücü iptal etti",
  DRIVER_NO_SHOW: "Sürücü bulunamadı",
  SAFETY_INCIDENT: "Güvenlik olayı",
  OFFER_DECLINED: "Teklif reddedildi",
  OTP_ISSUED: "Buluşma kodu üretildi",
  OTP_VERIFIED: "Buluşma kodu doğrulandı",
  OTP_FAILED: "Buluşma kodu hatalı",
};

export type RideDetail = {
  ride: {
    id: number;
    code: string;
    status: string;
    statusLabel: string;
    quotedFareKurus: number | null;
    finalFareKurus: number | null;
    commissionKurus: number | null;
    paymentStatus: string | null;
    tariffCode: string | null;
    otpVerified: boolean;
    createdAt: string;
    pickupAt: string | null;
    dropoffAt: string | null;
    distanceKm: number;
    durationMin: number;
    isDemo: boolean;
    cancelReason: string | null;
    customerRating?: number | null;
  };
  route: {
    pickupDistrict: string;
    dropDistrict: string;
    pickupAddress: string;
    dropAddress: string;
    pickupLat: number | null;
    pickupLng: number | null;
  };
  passenger: { name: string };
  chauffeur: {
    firstName: string;
    rating: number | null;
    ratingCount: number;
    totalTrips: number;
    isDemo: boolean;
  } | null;
  vehicle: {
    plate: string;
    make: string;
    model: string;
    color: string;
    seatCount: number;
    vehicleType: string;
  } | null;
  events: { id: number; eventType: string; actor: string; note: string; createdAt: string }[];
  capabilities: {
    canCancel: boolean;
    canRequestOtp: boolean;
    canDrive: boolean;
    canReportSafety: boolean;
    canSeePayment: boolean;
  };
};
