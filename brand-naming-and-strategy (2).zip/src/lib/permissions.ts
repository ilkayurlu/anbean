import type { Role } from "./auth";

/**
 * Rol → izin matrisi.
 * Kural: hiçbir rotada "rol adı" ile yetki verilmez, izin adı verilir.
 * Böylece yeni rol eklemek mevcut kontrolleri gevşetmez.
 */
export type Permission =
  | "shipment:create"
  | "shipment:read"
  | "shipment:update"
  | "shipment:cancel"
  | "shipment:assign"
  | "shipment:track"
  | "shipment:resolve"
  | "ride:create"
  | "ride:read"
  | "ride:end"
  | "vehicle:read"
  | "vehicle:unlock"
  | "vehicle:manage"
  | "courier:read"
  | "courier:manage"
  | "courier:verify"
  | "courier:payout:request"
  | "finance:read"
  | "finance:payout"
  | "finance:refund"
  | "support:read"
  | "support:manage"
  | "org:read"
  | "org:manage"
  | "cms:read"
  | "zone:read"
  | "zone:manage"
  | "tariff:read"
  | "tariff:manage"
  | "user:read"
  | "user:manage"
  | "audit:read"
  | "report:read"
  | "notification:send"
  | "cms:manage"
  | "hail:quote"
  | "hail:request"
  | "hail:read"
  | "hail:cancel"
  | "hail:drive"
  | "hail:offer"
  | "chauffeur:read"
  | "chauffeur:manage"
  | "chauffeur:verify"
  | "chauffeur:payout:request"
  | "safety:read"
  | "safety:manage"
  | "safety:report"
  | "member:read"
  | "member:manage"
  | "member:sensitive"
  | "member:archive"
  | "member:export"
  | "member:reset_password"
  | "cv:read"
  | "cv:manage"
  | "org:export"
  | "subscription:read"
  | "subscription:manage"
  | "invoice:read"
  | "invoice:manage"
  | "cms:write"
  | "cms:publish"
  | "cms:restore"
  | "blog:write"
  | "blog:publish"
  | "media:manage"
  | "template:manage"
  | "settings:read"
  | "settings:manage"
  | "mfa:manage"
  | "export:any";

export const ALL_PERMISSIONS: Permission[] = [
  "shipment:create", "shipment:read", "shipment:update", "shipment:cancel", "shipment:assign",
  "shipment:track", "shipment:resolve", "ride:create", "ride:read", "ride:end", "vehicle:read",
  "vehicle:unlock", "vehicle:manage", "courier:read", "courier:manage", "courier:verify",
  "courier:payout:request", "finance:read", "finance:payout", "finance:refund", "support:read",
  "support:manage", "org:read", "org:manage", "cms:read",
  "zone:read", "zone:manage", "tariff:read", "tariff:manage", "user:read",
  "user:manage", "audit:read", "report:read", "notification:send", "cms:manage",
  "hail:quote", "hail:request", "hail:read", "hail:cancel", "hail:drive", "hail:offer",
  "chauffeur:read", "chauffeur:manage", "chauffeur:verify", "chauffeur:payout:request",
  "safety:read", "safety:manage", "safety:report",
  "member:read", "member:manage", "member:sensitive", "member:archive", "member:export",
  "member:reset_password", "cv:read", "cv:manage", "org:export", "subscription:read",
  "subscription:manage", "invoice:read", "invoice:manage", "cms:write", "cms:publish",
  "cms:restore", "blog:write", "blog:publish", "media:manage", "template:manage",
  "settings:read", "settings:manage", "mfa:manage", "export:any",
];

export const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  musteri: [
    "shipment:create", "shipment:read", "shipment:track", "shipment:cancel",
    "ride:create", "ride:read", "ride:end",
    "vehicle:read", "vehicle:unlock",
    "support:read",
    "hail:quote", "hail:request", "hail:read", "hail:cancel", "safety:report", "safety:read",
  ],
  kurye: [
    "shipment:read", "shipment:update", "shipment:track",
    "vehicle:read", "courier:payout:request", "support:read", "report:read",
    "safety:report", "safety:read",
  ],
  // ops = sevkiyat sorumlusu + operasyon yöneticisi
  ops: [
    "member:read", "cv:read", "cv:manage", "org:read",
    "shipment:read", "shipment:update", "shipment:assign", "shipment:track", "shipment:resolve",
    "shipment:cancel", "courier:read", "courier:manage",
    "vehicle:read", "vehicle:manage", "zone:read", "zone:manage",
    "support:read", "support:manage", "report:read", "notification:send", "ride:read",
    "hail:read", "hail:cancel", "chauffeur:read", "chauffeur:manage", "chauffeur:verify",
    "safety:read", "safety:manage",
  ],
  finance: [
    "finance:read", "finance:payout", "finance:refund",
    "member:read", "member:export", "org:read", "org:export",
    "subscription:read", "subscription:manage", "invoice:read", "invoice:manage",
    "export:any",
    "shipment:read", "ride:read", "report:read", "audit:read",
    "hail:read", "chauffeur:read", "chauffeur:payout:request",
  ],
  // Sürücü: kendi yolculukları, teklifleri, kazancı ve konumu.
  surucu: [
    "hail:offer", "hail:drive", "hail:read", "chauffeur:payout:request",
    "support:read", "report:read", "safety:report", "safety:read",
  ],
  // Aday: yalnızca başvuru ve kendi belge durumu.
  surucu_adayi: ["support:read"],
  // Güvenlik: yolculuk detayına erişir AMA ödeme bilgisine erişemez.
  guvenlik: ["safety:read", "safety:manage", "hail:read", "chauffeur:read", "support:read", "report:read"],
  support: [
    "shipment:read", "shipment:track", "ride:read",
    "user:read", "courier:read", "support:read", "support:manage",
    // Destek personeli üye kaydını görür ama hassas alanları GÖREMEZ.
    "member:read", "cv:read", "org:read", "hail:read",
  ],
  admin: ALL_PERMISSIONS,
  // Süper admin: kalıcı silme ve platform sahipliği gerektiren işlemler.
  // Arayüzde kalıcı silme YOK; bu rol ileride gerekirse ayrı bir izne bağlanır.
  super_admin: ALL_PERMISSIONS,
  // CMS editörü: içerik + medya. Kullanıcı, finans ve güvenlik verisine ERİŞEMEZ.
  editor: [
    "cms:read", "cms:write", "cms:publish", "cms:restore",
    "blog:write", "blog:publish", "media:manage", "template:manage",
    "support:read",
  ],
  // İşletme sahibi: YALNIZCA kendi tenant'ı (sorgular orgId ile filtrelenir).
  isletme_sahibi: [
    "org:read", "org:manage", "member:read",
    "shipment:create", "shipment:read", "shipment:track", "shipment:cancel",
    "invoice:read", "subscription:read", "report:read", "support:read",
    "cv:read",
  ],
  isletme_calisani: [
    "org:read", "shipment:create", "shipment:read", "shipment:track", "support:read",
  ],
};

export function hasPermission(role: Role, permission: Permission): boolean {
  return ROLE_PERMISSIONS[role]?.includes(permission) ?? false;
}

/** Rol bazlı ana sayfa — giriş sonrası yönlendirme. */
export const HOME_BY_ROLE: Record<Role, string> = {
  musteri: "/app",
  kurye: "/courier",
  ops: "/ops",
  finance: "/admin/finans",
  support: "/admin/destek",
  surucu: "/surucu",
  super_admin: "/admin",
  editor: "/admin/cms",
  isletme_sahibi: "/isletme",
  isletme_calisani: "/isletme",
  surucu_adayi: "/surucu/belgeler",
  guvenlik: "/ops/guvenlik-olaylari",
  admin: "/admin",
};
