"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { PhoneCall, ShieldAlert, Share2, Star } from "lucide-react";
import { RIDE_STATUS_LABEL_LOCAL, type RideDetail } from "@/lib/hail-types";

function tl(kurus: number) {
  return new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(kurus / 100);
}

const TERMINAL = ["COMPLETED", "CANCELLED_BY_PASSENGER", "CANCELLED_BY_DRIVER", "DRIVER_NO_SHOW"];

/**
 * Canlı yolculuk ekranı.
 * - 10 sn'de bir yoklar; sekme gizliyken durur, hata olursa bekleme uzar.
 * - Durum değişiklikleri aria-live ile duyurulur.
 * - OTP, paylaşım, acil durum ve iptal tek ekranda.
 */
export default function HailLiveView({ rideId }: { rideId: number }) {
  const router = useRouter();
  const [data, setData] = useState<RideDetail | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");
  const [otpCode, setOtpCode] = useState("");
  const [driverOtp, setDriverOtp] = useState("");
  const [shareUrl, setShareUrl] = useState("");
  const [contacts, setContacts] = useState<{ id: number; name: string }[]>([]);
  const [contactId, setContactId] = useState(0);
  const [reportOpen, setReportOpen] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch(`/api/hail/${rideId}`, { cache: "no-store" });
    if (!res.ok) {
      const body = (await res.json().catch(() => ({}))) as { error?: string };
      setError(body.error ?? "Yolculuk yüklenemedi.");
      return;
    }
    setData((await res.json()) as RideDetail);
  }, [rideId]);

  useEffect(() => {
    // Efekt gövdesinde senkron setState yok: ilk yükleme zamanlayıcıyla.
    const first = window.setTimeout(() => void load(), 0);
    void fetch("/api/trusted-contacts")
      .then((r) => (r.ok ? r.json() : { contacts: [] }))
      .then((d: { contacts: { id: number; name: string }[] }) => {
        setContacts(d.contacts ?? []);
        setContactId(d.contacts?.[0]?.id ?? 0);
      })
      .catch(() => setContacts([]));
    return () => window.clearTimeout(first);
  }, [load]);

  useEffect(() => {
    if (!data || TERMINAL.includes(data.ride.status)) return;
    let delay = 10_000;
    let timer: number | undefined;
    let cancelled = false;
    const poll = async () => {
      if (document.visibilityState !== "hidden") {
        try {
          await load();
          delay = 10_000;
        } catch {
          delay = Math.min(delay * 2, 60_000);
        }
      }
      if (!cancelled) timer = window.setTimeout(poll, delay);
    };
    timer = window.setTimeout(poll, delay);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [data, load]);

  async function act(path: string, body: unknown, key: string) {
    setBusy(key);
    setError("");
    const res = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const payload = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    setBusy("");
    if (!res.ok) {
      setError(String(payload.error ?? "İşlem başarısız."));
      return null;
    }
    await load();
    router.refresh();
    return payload;
  }

  if (!data) {
    return <p className="py-10 text-center text-sm text-slate-400">{error || "Yükleniyor…"}</p>;
  }

  const { ride, vehicle, chauffeur, route, capabilities } = data;
  const done = ride.status === "COMPLETED";

  return (
    <div className="space-y-5">
      <div className="rounded-lg border border-white/10 bg-white/3 p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-[11px] uppercase tracking-[0.14em] text-slate-500">{ride.code}</p>
            <p className="mt-1 font-display text-2xl font-bold text-white" role="status">
              {RIDE_STATUS_LABEL_LOCAL[ride.status] ?? ride.status}
            </p>
          </div>
          {ride.isDemo ? (
            <span className="rounded-full border border-st-waiting/40 bg-st-waiting/10 px-3 py-1 text-[11px] font-semibold text-st-waiting">
              Pilot · demo sürücü
            </span>
          ) : null}
        </div>

        <p className="mt-4 text-sm text-slate-300">
          {route.pickupDistrict} → {route.dropDistrict}
        </p>
        <p className="text-xs text-slate-500">
          {route.pickupAddress} · {route.dropAddress}
        </p>

        {(chauffeur || vehicle) && (
          <div className="mt-5 flex flex-wrap items-center gap-4 border-t border-white/8 pt-5">
            {vehicle ? (
              <div>
                <p className="font-display text-xl font-bold tracking-wider text-white">{vehicle.plate}</p>
                <p className="text-xs text-slate-400">
                  {vehicle.make} {vehicle.model} · {vehicle.color} · {vehicle.seatCount} koltuk
                </p>
              </div>
            ) : null}
            {chauffeur ? (
              <div>
                <p className="text-sm text-slate-200">Sürücün {chauffeur.firstName}</p>
                <p className="text-xs text-slate-500">
                  {chauffeur.rating ? `${chauffeur.rating.toFixed(1)} / 5 · ${chauffeur.ratingCount} değerlendirme` : "Henüz değerlendirme yok"}{" "}
                  · {chauffeur.totalTrips} yolculuk
                </p>
                <p className="mt-1 text-[11px] text-slate-600">Soyadı ve telefonu paylaşılmaz.</p>
              </div>
            ) : null}
          </div>
        )}

        {ride.status === "DRIVER_NO_SHOW" ? (
          <p className="mt-5 rounded-md border border-st-risk/40 bg-st-risk/10 p-4 text-sm text-slate-200">
            Uygun sürücü bulunamadı veya teklif süresi doldu. Ücret alınmadı. Yeni talep oluşturabilirsin.
          </p>
        ) : null}
        {ride.cancelReason ? (
          <p className="mt-4 text-xs text-slate-400">İptal nedeni: {ride.cancelReason}</p>
        ) : null}
      </div>

      {/* Buluşma kodu */}
      {capabilities.canRequestOtp ? (
        <div className="rounded-lg border border-accent/30 bg-accent/6 p-5">
          <h2 className="text-sm font-semibold text-white">Buluşma kodu</h2>
          <p className="mt-1 text-sm text-slate-300">
            Sürücüye bu kodu söyle. Kod doğrulanmadan yolculuk başlatılamaz — yanlış araca binmeyi engeller.
          </p>
          {otpCode ? (
            <p className="mt-4 font-display text-4xl font-bold tracking-[0.3em] text-accent">{otpCode}</p>
          ) : (
            <button
              type="button"
              onClick={async () => {
                const res = await act(`/api/hail/${rideId}/otp`, {}, "otp");
                if (res?.code) setOtpCode(String(res.code));
              }}
              disabled={busy === "otp"}
              className="mt-4 rounded-md bg-accent px-5 py-2.5 text-sm font-semibold text-[#0B1220]"
            >
              {busy === "otp" ? "Üretiliyor…" : "Kod oluştur"}
            </button>
          )}
          {ride.otpVerified ? (
            <p className="mt-3 text-xs text-st-delivered">Kod doğrulandı.</p>
          ) : null}
          <p className="mt-3 text-[11px] text-slate-500">
            SMS sağlayıcısı bağlı değil; kod bu ekranda gösterilir. Gerçek dağıtımda yalnızca SMS ile iletilir ve
            ekranda gösterilmez.
          </p>
        </div>
      ) : null}

      {/* Sürücü OTP doğrulama (sürücü oturumunda görünür) */}
      {capabilities.canDrive && !ride.otpVerified ? (
        <div className="rounded-lg border border-white/10 bg-white/3 p-5">
          <h2 className="text-sm font-semibold text-white">Yolcunun buluşma kodunu gir</h2>
          <div className="mt-3 flex gap-2">
            <input
              value={driverOtp}
              onChange={(e) => setDriverOtp(e.target.value)}
              inputMode="numeric"
              maxLength={6}
              aria-label="Buluşma kodu"
              className="input-dark w-40 font-mono tracking-[0.3em]"
            />
            <button
              type="button"
              onClick={() => act(`/api/hail/${rideId}/transition`, { action: "otp_verify", otp: driverOtp }, "otp-verify")}
              disabled={busy === "otp-verify" || driverOtp.length < 6}
              className="rounded-md bg-accent px-4 py-2.5 text-sm font-semibold text-[#0B1220]"
            >
              Doğrula
            </button>
          </div>
        </div>
      ) : null}

      {/* Sürücü aksiyonları */}
      {capabilities.canDrive ? (
        <div className="rounded-lg border border-white/10 bg-white/3 p-5">
          <h2 className="text-sm font-semibold text-white">Yolculuk adımları</h2>
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {[
              { action: "en_route", label: "Yola çıktım", show: ride.status === "DRIVER_ASSIGNED" },
              { action: "arrived", label: "Buluşma noktasındayım", show: ride.status === "DRIVER_EN_ROUTE" },
              { action: "start", label: "Yolculuğu başlat", show: ride.status === "DRIVER_ARRIVED" },
              { action: "complete", label: "Yolculuğu bitir", show: ride.status === "IN_PROGRESS" },
            ]
              .filter((step) => step.show)
              .map((step) => (
                <button
                  key={step.action}
                  type="button"
                  onClick={() =>
                    act(
                      `/api/hail/${rideId}/transition`,
                      {
                        action: step.action,
                        actualDistanceKm: step.action === "complete" ? ride.distanceKm || 8 : undefined,
                        actualDurationMin: step.action === "complete" ? ride.durationMin || 20 : undefined,
                      },
                      step.action,
                    )
                  }
                  disabled={busy !== ""}
                  className="flex h-14 items-center justify-center rounded-md bg-accent text-base font-semibold text-[#0B1220] disabled:opacity-60"
                >
                  {busy === step.action ? "…" : step.label}
                </button>
              ))}
            {ride.status === "DRIVER_ASSIGNED" || ride.status === "DRIVER_EN_ROUTE" ? (
              <button
                type="button"
                onClick={() => act(`/api/hail/${rideId}/transition`, { action: "driver_cancel", reason: "Sürücü iptali" }, "dcancel")}
                className="flex h-14 items-center justify-center rounded-md border border-st-risk/50 text-base font-semibold text-st-risk"
              >
                Yolculuğu iptal et
              </button>
            ) : null}
          </div>
        </div>
      ) : null}

      {/* Ücret ve makbuz */}
      {capabilities.canSeePayment && (
        <div className="rounded-lg border border-white/10 bg-white/3 p-5">
          <h2 className="text-sm font-semibold text-white">Ücret</h2>
          <dl className="mt-3 space-y-2 text-sm">
            <div className="flex justify-between text-slate-300">
              <dt>Tahmini (talep anında kilitlenen)</dt>
              <dd className="tabular-nums">{ride.quotedFareKurus === null ? "—" : tl(ride.quotedFareKurus)}</dd>
            </div>
            {ride.finalFareKurus !== null ? (
              <>
                <div className="flex justify-between text-slate-300">
                  <dt>Kesin (gerçek mesafe/süre)</dt>
                  <dd className="tabular-nums">{tl(ride.finalFareKurus)}</dd>
                </div>
                <div className="flex justify-between font-semibold text-white">
                  <dt>Fark</dt>
                  <dd className="tabular-nums">
                    {ride.finalFareKurus !== null && ride.quotedFareKurus !== null
                      ? `${ride.finalFareKurus >= ride.quotedFareKurus ? "+" : "−"}${tl(
                          Math.abs(ride.finalFareKurus - ride.quotedFareKurus),
                        )}`
                      : "—"}
                  </dd>
                </div>
              </>
            ) : null}
            {ride.commissionKurus !== null && ride.commissionKurus > 0 ? (
              <div className="flex justify-between text-slate-400">
                <dt>Platform komisyonu</dt>
                <dd className="tabular-nums">{tl(ride.commissionKurus)}</dd>
              </div>
            ) : null}
          </dl>
          <p className="mt-3 text-[11px] text-slate-500">
            Kesin tutar sunucuda hesaplanır; istemciden gelen tutar kabul edilmez. Ödeme durumu: {ride.paymentStatus}.
          </p>
        </div>
      )}

      {/* Paylaşım */}
      {!TERMINAL.includes(ride.status) ? (
        <div className="rounded-lg border border-white/10 bg-white/3 p-5">
          <h2 className="flex items-center gap-2 text-sm font-semibold text-white">
            <Share2 size={15} aria-hidden /> Güvendiğim kişiyle paylaş
          </h2>
          {shareUrl ? (
            <p className="mt-3 break-all rounded-md border border-white/10 bg-white/5 p-3 font-mono text-xs text-accent">
              {shareUrl}
            </p>
          ) : contacts.length === 0 ? (
            <p className="mt-3 text-sm text-slate-400">
              Önce güvenilen kişi ekle.{" "}
              <Link href="/app/guvenilen-kisiler" className="text-accent underline-offset-4 hover:underline">
                Ekle
              </Link>
            </p>
          ) : (
            <div className="mt-3 flex flex-wrap gap-2">
              <select
                value={contactId}
                onChange={(e) => setContactId(Number(e.target.value))}
                aria-label="Güvenilen kişi"
                className="input-dark max-w-56 py-2 text-sm"
              >
                {contacts.map((contact) => (
                  <option key={contact.id} value={contact.id} className="bg-[#0b1220]">
                    {contact.name}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={async () => {
                  const res = await act(`/api/hail/${rideId}/share`, { contactId }, "share");
                  if (res?.url) setShareUrl(String(res.url));
                }}
                disabled={busy === "share" || !contactId}
                className="rounded-md bg-accent px-4 py-2 text-sm font-semibold text-[#0B1220]"
              >
                Bağlantı oluştur
              </button>
            </div>
          )}
          <p className="mt-3 text-[11px] text-slate-500">
            Bağlantıda plaka, sürücünün adı ve yaklaşık konum görünür; telefonun, tam adresin ve ödeme bilgin
            görünmez. Yolculuk bitince bağlantı otomatik kapanır.
          </p>
        </div>
      ) : null}

      {/* Acil durum */}
      <div className="rounded-lg border border-st-risk/40 bg-st-risk/8 p-5">
        <h2 className="flex items-center gap-2 text-sm font-semibold text-white">
          <ShieldAlert size={15} aria-hidden /> Acil durum
        </h2>
        <p className="mt-2 text-sm text-slate-300">
          Tehlike varsa önce 112&apos;yi ara. Ardından platforma olay bildir; kritik bildirimde sürücü incelemeye alınır.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          <a
            href="tel:112"
            className="flex h-12 items-center gap-2 rounded-md bg-st-risk px-5 text-sm font-semibold text-white"
          >
            <PhoneCall size={15} aria-hidden /> 112&apos;yi ara
          </a>
          <button
            type="button"
            onClick={() => setReportOpen((v) => !v)}
            className="flex h-12 items-center rounded-md border border-st-risk/50 px-5 text-sm font-semibold text-st-risk"
          >
            Güvenlik olayı bildir
          </button>
        </div>
        {reportOpen ? (
          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            {[
              { type: "harassment", label: "Taciz / rahatsızlık" },
              { type: "accident", label: "Kaza" },
              { type: "wrong_vehicle", label: "Yanlış araç / plaka" },
              { type: "route_issue", label: "Rota sapması" },
              { type: "no_show", label: "Sürücü gelmedi" },
              { type: "other", label: "Diğer" },
            ].map((option) => (
              <button
                key={option.type}
                type="button"
                onClick={() => {
                  void act("/api/safety", { rideId, incidentType: option.type, emergencyCallMade: false }, `safety-${option.type}`);
                  setReportOpen(false);
                }}
                className="h-12 rounded-md border border-white/12 bg-white/5 px-4 text-sm text-slate-200"
              >
                {option.label}
              </button>
            ))}
          </div>
        ) : null}
      </div>

      {/* İptal */}
      {capabilities.canCancel ? (
        <button
          type="button"
          onClick={() => act(`/api/hail/${rideId}/cancel`, { reason: "Yolcu iptali" }, "cancel")}
          disabled={busy === "cancel"}
          className="w-full rounded-md border border-white/15 py-3 text-sm text-slate-300"
        >
          Yolculuğu iptal et
        </button>
      ) : null}

      {/* Değerlendirme */}
      {done && chauffeur && !ride.customerRating ? (
        <div className="rounded-lg border border-white/10 bg-white/3 p-5">
          <h2 className="flex items-center gap-2 text-sm font-semibold text-white">
            <Star size={15} aria-hidden /> Yolculuğu değerlendir
          </h2>
          <div className="mt-3 flex gap-2">
            {[1, 2, 3, 4, 5].map((score) => (
              <button
                key={score}
                type="button"
                aria-label={`${score} puan`}
                onClick={() => act(`/api/hail/${rideId}/rate`, { score }, `rate-${score}`)}
                className="h-11 w-11 rounded-md border border-white/15 text-sm font-semibold text-slate-300"
              >
                {score}
              </button>
            ))}
          </div>
        </div>
      ) : null}

      <ol className="rounded-lg border border-white/10 bg-white/3 p-5 text-sm">
        <li className="text-[11px] uppercase tracking-[0.14em] text-slate-500">Olay geçmişi (salt okunur)</li>
        {data.events.map((event) => (
          <li key={event.id} className="mt-2 flex justify-between gap-3 text-slate-300">
            <span>{RIDE_STATUS_LABEL_LOCAL[event.eventType] ?? event.eventType.replaceAll("_", " ")}</span>
            <span className="shrink-0 text-xs text-slate-500">{new Date(event.createdAt).toLocaleTimeString("tr-TR")}</span>
          </li>
        ))}
      </ol>

      {error ? (
        <p role="alert" className="text-sm text-st-risk">
          {error}
        </p>
      ) : null}
    </div>
  );
}
