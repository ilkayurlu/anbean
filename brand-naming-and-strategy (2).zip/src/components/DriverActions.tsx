"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { useNow } from "@/lib/useNow";

type Offer = { id: number; rideId: number; quotedEtaSec: number; expiresAt: string; status: string };
type OfferView = Offer & {
  rideCode: string;
  pickupDistrict: string;
  dropDistrict: string;
  quotedFareKurus: number | null;
};

function tl(kurus: number) {
  return new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(kurus / 100);
}

/**
 * Sürücü durum anahtarı ve teklif havuzu.
 * Teklifler süre dolunca kendiliğinden düşer; sayaç istemcide işler.
 */
export default function DriverActions({
  availability,
  verified,
  pilotBlocked,
}: {
  availability: string;
  verified: boolean;
  pilotBlocked: boolean;
}) {
  const router = useRouter();
  const [offers, setOffers] = useState<OfferView[]>([]);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  // Saat useSyncExternalStore üzerinden: efekt gövdesinde setState yok.
  const now = useNow(true);

  const load = useCallback(async () => {
    const res = await fetch("/api/chauffeur/offers", { cache: "no-store" });
    if (res.ok) setOffers((await res.json()) as OfferView[]);
  }, []);

  useEffect(() => {
    // İlk yükleme zamanlayıcı içinde: efekt gövdesinde senkron setState olmaz.
    const first = window.setTimeout(() => void load(), 0);
    const poll = window.setInterval(() => void load(), 10_000);
    return () => {
      window.clearTimeout(first);
      window.clearInterval(poll);
    };
  }, [load]);

  async function toggle() {
    setBusy("toggle");
    setError("");
    const next = availability === "online_idle" ? "offline" : "online_idle";
    const res = await fetch("/api/chauffeur/status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ availability: next }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string; pilotMode?: boolean };
    setBusy("");
    if (!res.ok) {
      setError(data.error ?? "Durum değiştirilemedi.");
      return;
    }
    router.refresh();
  }

  async function respond(offerId: number, decision: "accept" | "decline") {
    setBusy(`${decision}-${offerId}`);
    setError("");
    const res = await fetch(`/api/offers/${offerId}/respond`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ decision }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string; rideId?: number };
    setBusy("");
    if (!res.ok) {
      setError(data.error ?? "Teklif işlenemedi.");
      await load();
      return;
    }
    await load();
    router.refresh();
    if (decision === "accept" && data.rideId) router.push(`/app/yolculuk/${data.rideId}`);
  }

  return (
    <div className="space-y-5">
      <section className="rounded-lg border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Durumum</h2>
            <p className="mt-1 font-display text-xl font-bold text-[#0B1220]">
              {availability === "online_idle" ? "Çevrimiçi · boşta" : availability === "on_trip" ? "Yolculukta" : "Çevrimdışı"}
            </p>
          </div>
          <button
            type="button"
            onClick={toggle}
            disabled={busy === "toggle" || availability === "on_trip" || (!verified && availability !== "online_idle")}
            className={`h-14 min-w-40 rounded-md px-5 text-sm font-semibold transition disabled:opacity-50 ${
              availability === "online_idle"
                ? "border border-st-risk/50 text-st-risk"
                : "bg-accent text-[#0B1220]"
            }`}
          >
            {busy === "toggle" ? "…" : availability === "online_idle" ? "Çevrimdışı ol" : "Çevrimiçi ol"}
          </button>
        </div>
        {!verified ? (
          <p className="mt-3 rounded-md border border-st-waiting/40 bg-st-waiting/10 p-3 text-xs text-slate-700">
            Ticari yolcu taşıma belgelerin doğrulanmadan çevrimiçi olamazsın ve teklif alamazsın.
          </p>
        ) : null}
        {pilotBlocked ? (
          <p className="mt-3 rounded-md border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">
            Sürücülü yolculuk hizmeti hukuk onayı beklediği için çevrimiçi olma isteği reddedilir. Bu bir hata değil,
            yayın kapısıdır.
          </p>
        ) : null}
        {error ? (
          <p role="alert" className="mt-3 text-sm text-st-risk">
            {error}
          </p>
        ) : null}
      </section>

      <section className="rounded-lg border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Gelen teklifler</h2>
        {offers.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-500">
            Bekleyen teklif yok. Çevrimiçi olduğunda uygun yolculuklar burada görünür.
          </p>
        ) : (
          <ul className="mt-3 space-y-3">
            {offers.map((offer) => {
              const left = now === null ? null : Math.max(0, Math.round((new Date(offer.expiresAt).getTime() - now) / 1000));
              const expired = left !== null && left <= 0;
              return (
                <li key={offer.id} className="rounded-md border border-slate-200 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="font-display text-sm font-bold text-[#0B1220]">{offer.rideCode}</p>
                    <span
                      className="rounded-full px-2.5 py-1 text-[11px] font-semibold tabular-nums"
                      style={{
                        color: expired ? "#DC2626" : "#B45309",
                        backgroundColor: expired ? "rgba(220,38,38,0.12)" : "rgba(245,158,11,0.14)",
                      }}
                    >
                      {expired ? "süresi doldu" : `${left ?? "--"} sn`}
                    </span>
                  </div>
                  <p className="mt-1.5 text-sm text-slate-700">
                    {offer.pickupDistrict} → {offer.dropDistrict}
                  </p>
                  <p className="text-xs text-slate-500">
                    Tahmini varış {Math.round(offer.quotedEtaSec / 60)} dk
                    {offer.quotedFareKurus !== null ? ` · yolcu ödemesi ${tl(offer.quotedFareKurus)}` : ""}
                  </p>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      disabled={expired || busy !== ""}
                      onClick={() => respond(offer.id, "accept")}
                      className="h-14 rounded-md bg-st-delivered text-base font-semibold text-white disabled:opacity-50"
                    >
                      {busy === `accept-${offer.id}` ? "…" : "Kabul et"}
                    </button>
                    <button
                      type="button"
                      disabled={expired || busy !== ""}
                      onClick={() => respond(offer.id, "decline")}
                      className="h-14 rounded-md border border-st-risk/50 text-base font-semibold text-st-risk disabled:opacity-50"
                    >
                      {busy === `decline-${offer.id}` ? "…" : "Reddet"}
                    </button>
                  </div>
                  <Link href={`/app/yolculuk/${offer.rideId}`} className="mt-2 inline-block text-xs text-slate-500 underline-offset-4 hover:underline">
                    Yolculuk detayı
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
        <p className="mt-4 text-[11px] text-slate-500">
          Teklif süresi 30 saniyedir. Süre dolunca teklif kendiliğinden düşer ve başka sürücüye geçer.
        </p>
      </section>
    </div>
  );
}
