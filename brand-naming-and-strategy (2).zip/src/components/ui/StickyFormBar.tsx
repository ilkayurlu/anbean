"use client";

import { useEffect, type ReactNode } from "react";

/**
 * Uzun formlar için sabit kaydetme çubuğu.
 * - Kaydedilmemiş değişiklik varsa sekme kapatılırken uyarır.
 * - Durumu metinle de söyler ("Kaydedildi" / "Kaydedilmemiş değişiklik var"),
 *   yalnızca renkle anlatmaz.
 */
export default function StickyFormBar({
  dirty,
  saving,
  saved,
  error,
  onSave,
  onReset,
  saveLabel = "Kaydet",
  children,
}: {
  dirty: boolean;
  saving: boolean;
  saved: boolean;
  error?: string;
  onSave: () => void;
  onReset?: () => void;
  saveLabel?: string;
  children?: ReactNode;
}) {
  useEffect(() => {
    if (!dirty) return;
    const handler = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);

  return (
    <div className="sticky bottom-0 z-30 -mx-5 mt-6 border-t border-slate-200 bg-white/95 px-5 py-3 backdrop-blur">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-xs" role="status">
          {error ? (
            <span className="font-semibold text-st-risk">{error}</span>
          ) : dirty ? (
            <span className="font-semibold text-st-waiting">Kaydedilmemiş değişiklik var</span>
          ) : saved ? (
            <span className="font-semibold text-green-700">Kaydedildi</span>
          ) : (
            <span className="text-slate-500">Değişiklik yok</span>
          )}
          {children ? <span className="ml-2 text-slate-500">{children}</span> : null}
        </p>
        <div className="flex gap-2">
          {onReset ? (
            <button
              type="button"
              onClick={onReset}
              disabled={!dirty || saving}
              className="min-h-11 rounded-md border border-slate-300 px-4 text-sm text-slate-700 transition hover:border-slate-500 disabled:opacity-40"
            >
              Geri al
            </button>
          ) : null}
          <button
            type="button"
            onClick={onSave}
            disabled={!dirty || saving}
            className="min-h-11 rounded-md bg-accent px-5 text-sm font-semibold text-[#0B1220] transition hover:bg-accent-soft disabled:opacity-40"
          >
            {saving ? "Kaydediliyor…" : saveLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
