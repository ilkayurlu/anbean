import type { ReactNode } from "react";

/**
 * CSS tabanlı tooltip — JS durumu yok, hover VE focus ile açılır.
 * aria-describedby ile ekran okuyucuya da taşınır.
 */
let counter = 0;
function nextId() {
  counter += 1;
  return `tip-${counter}`;
}

export default function Tooltip({
  label,
  children,
  side = "top",
}: {
  label: string;
  children: ReactNode;
  side?: "top" | "bottom";
}) {
  const id = nextId();
  return (
    <span className="group/tip relative inline-flex" aria-describedby={id}>
      {children}
      <span
        id={id}
        role="tooltip"
        className={`pointer-events-none absolute left-1/2 z-50 w-max max-w-56 -translate-x-1/2 scale-95 rounded-md border border-white/12 bg-[#0b1220] px-2.5 py-1.5 text-[11px] leading-snug text-slate-200 opacity-0 shadow-lg transition duration-150 group-hover/tip:scale-100 group-hover/tip:opacity-100 group-focus-within/tip:scale-100 group-focus-within/tip:opacity-100 ${
          side === "top" ? "bottom-full mb-2" : "top-full mt-2"
        }`}
      >
        {label}
      </span>
    </span>
  );
}
