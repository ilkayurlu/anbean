"use client";

import { useRef, useState, type ReactNode } from "react";

export type TabItem = { key: string; label: string; content: ReactNode; badge?: string | number };

/**
 * Erişilebilir sekme: role=tablist, aria-selected, ok tuşlarıyla gezinme,
 * seçili sekme hem renkle hem alt çizgiyle işaretlenir (yalnızca renk değil).
 */
export default function Tabs({ items, initial }: { items: TabItem[]; initial?: string }) {
  const [active, setActive] = useState(initial ?? items[0]?.key ?? "");
  const refs = useRef<Record<string, HTMLButtonElement | null>>({});

  function move(delta: number) {
    const index = items.findIndex((item) => item.key === active);
    const next = items[(index + delta + items.length) % items.length];
    if (!next) return;
    setActive(next.key);
    refs.current[next.key]?.focus();
  }

  return (
    <div>
      <div role="tablist" aria-label="Bölümler" className="flex flex-wrap gap-1 border-b border-slate-200">
        {items.map((item) => {
          const selected = item.key === active;
          return (
            <button
              key={item.key}
              ref={(node) => {
                refs.current[item.key] = node;
              }}
              role="tab"
              id={`tab-${item.key}`}
              aria-selected={selected}
              aria-controls={`panel-${item.key}`}
              tabIndex={selected ? 0 : -1}
              onClick={() => setActive(item.key)}
              onKeyDown={(e) => {
                if (e.key === "ArrowRight") move(1);
                if (e.key === "ArrowLeft") move(-1);
                if (e.key === "Home") {
                  setActive(items[0].key);
                  refs.current[items[0].key]?.focus();
                }
                if (e.key === "End") {
                  const last = items[items.length - 1];
                  setActive(last.key);
                  refs.current[last.key]?.focus();
                }
              }}
              className={`relative -mb-px min-h-11 px-4 text-sm font-semibold transition ${
                selected
                  ? "border-b-2 border-accent text-[#0B1220]"
                  : "border-b-2 border-transparent text-slate-500 hover:bg-slate-100 hover:text-slate-800"
              }`}
            >
              {item.label}
              {item.badge !== undefined && item.badge !== "" ? (
                <span className="ml-2 rounded-full bg-slate-200 px-2 py-0.5 text-[10px] text-slate-700">{item.badge}</span>
              ) : null}
            </button>
          );
        })}
      </div>
      {items.map((item) => (
        <div
          key={item.key}
          role="tabpanel"
          id={`panel-${item.key}`}
          aria-labelledby={`tab-${item.key}`}
          hidden={item.key !== active}
          className="pt-5"
        >
          {item.key === active ? item.content : null}
        </div>
      ))}
    </div>
  );
}
