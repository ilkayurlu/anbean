"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import StickyFormBar from "@/components/ui/StickyFormBar";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import Tooltip from "@/components/ui/Tooltip";

export type CmsVersion = {
  id: number;
  version: number;
  title: string;
  status: string;
  changeNote: string;
  authorId: number | null;
  createdAt: Date | string;
  body: string;
};

const STATUS_LABEL: Record<string, string> = {
  taslak: "Taslak",
  incelemede: "İncelemede",
  yayinda: "Yayında",
  arsiv: "Arşiv",
};

/** CMS editörü: sürüm geçmişi, geri yükleme, yayın akışı, zamanlama. */
export default function CmsEditor({
  page,
  versions,
  canPublish,
  canRestore,
}: {
  page: {
    id: number;
    slug: string;
    title: string;
    body: string;
    status: string;
    version: number;
    metaTitle: string;
    metaDescription: string;
    scheduledFor: Date | string | null;
    publishedAt: Date | string | null;
  };
  versions: CmsVersion[];
  canPublish: boolean;
  canRestore: boolean;
}) {
  const router = useRouter();
  const initial = {
    title: page.title,
    body: page.body,
    metaTitle: page.metaTitle,
    metaDescription: page.metaDescription,
    status: page.status,
    scheduledFor: page.scheduledFor ? new Date(page.scheduledFor).toISOString().slice(0, 16) : "",
    changeNote: "",
  };
  const [form, setForm] = useState(initial);
  const [draft, setDraft] = useState(initial);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [confirm, setConfirm] = useState<
    | { kind: "publish"; title: string; body: string; label: string }
    | { kind: "archive"; title: string; body: string; label: string }
    | { kind: "restore"; version: number; title: string; body: string; label: string }
    | null
  >(null);

  const dirty = JSON.stringify({ ...form, changeNote: "" }) !== JSON.stringify({ ...draft, changeNote: "" });

  async function save(status?: string) {
    setSaving(true);
    setError("");
    const res = await fetch(`/api/admin/cms/${page.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, status: status ?? form.status }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string; version?: number };
    setSaving(false);
    if (!res.ok) {
      setError(data.error ?? "Kaydedilemedi.");
      return;
    }
    setDraft({ ...form });
    setForm((f) => ({ ...f, changeNote: "" }));
    setSaved(true);
    setConfirm(null);
    router.refresh();
  }

  async function restore(version: number, reason: string) {
    setSaving(true);
    setError("");
    const res = await fetch(`/api/admin/cms/${page.id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "restore", version, reason }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    setSaving(false);
    setConfirm(null);
    if (!res.ok) {
      setError(data.error ?? "Geri yüklenemedi.");
      return;
    }
    router.refresh();
  }

  async function archive(reason: string) {
    setSaving(true);
    const res = await fetch(`/api/admin/cms/${page.id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "archive", reason }),
    });
    setSaving(false);
    setConfirm(null);
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Arşivlenemedi.");
      return;
    }
    router.refresh();
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1.4fr_0.6fr]">
      <section className="rounded-lg border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">
            İçerik · v{page.version} · {STATUS_LABEL[page.status] ?? page.status}
          </h2>
          <code className="rounded bg-slate-100 px-2 py-1 text-[11px] text-slate-600">/{page.slug}</code>
        </div>

        <div className="mt-4">
          <label htmlFor="cms-title" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Başlık</label>
          <input id="cms-title" className="input-light mt-2" value={form.title} maxLength={160}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
        </div>
        <div className="mt-4">
          <label htmlFor="cms-body" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">İçerik</label>
          <textarea id="cms-body" rows={14} className="input-light mt-2 font-mono text-sm" value={form.body} maxLength={20000}
            onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))} />
          <p className="mt-1 text-[11px] text-slate-500">{form.body.length}/20000 · zengin metin editörü bağlı değil, düz metin</p>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="cms-meta-title" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">SEO başlığı</label>
            <input id="cms-meta-title" className="input-light mt-2" value={form.metaTitle} maxLength={120}
              onChange={(e) => setForm((f) => ({ ...f, metaTitle: e.target.value }))} />
          </div>
          <div>
            <label htmlFor="cms-meta-desc" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">SEO açıklaması</label>
            <input id="cms-meta-desc" className="input-light mt-2" value={form.metaDescription} maxLength={240}
              onChange={(e) => setForm((f) => ({ ...f, metaDescription: e.target.value }))} />
          </div>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="cms-status" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Durum</label>
            <select id="cms-status" className="input-light mt-2" value={form.status}
              onChange={(e) => setForm((f) => ({ ...f, status: e.target.value }))}>
              {Object.entries(STATUS_LABEL).map(([value, label]) => (
                <option key={value} value={value}>{label}</option>
              ))}
            </select>
            {!canPublish && form.status === "yayinda" ? (
              <p className="mt-1 text-[11px] text-st-risk">Yayınlama yetkin yok; kayıt taslak olarak kalır.</p>
            ) : null}
          </div>
          <div>
            <label htmlFor="cms-schedule" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Yayın zamanlama</label>
            <input id="cms-schedule" type="datetime-local" className="input-light mt-2" value={form.scheduledFor}
              onChange={(e) => setForm((f) => ({ ...f, scheduledFor: e.target.value }))} />
            <p className="mt-1 text-[11px] text-slate-500">Zamanlanmış yayın için zamanlayıcı görev gerekir; şu an alan saklanır.</p>
          </div>
        </div>
        <div className="mt-4">
          <label htmlFor="cms-change" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
            Değişiklik özeti (zorunlu, sürüm kaydına yazılır)
          </label>
          <input id="cms-change" className="input-light mt-2" value={form.changeNote} minLength={3} maxLength={200}
            onChange={(e) => setForm((f) => ({ ...f, changeNote: e.target.value }))} />
        </div>

        <StickyFormBar dirty={dirty} saving={saving} saved={saved} error={error}
          onSave={() => save()} saveLabel="Yeni sürüm olarak kaydet" onReset={() => setForm({ ...draft })}>
          Kaydedince sürüm {page.version + 1} oluşur; eski sürüm saklanır.
        </StickyFormBar>

        <div className="mt-4 flex flex-wrap gap-2">
          {canPublish ? (
            <Tooltip label="Yayına almadan önce onay istenir">
              <button type="button" disabled={!dirty && form.status === "yayinda"}
                onClick={() => setConfirm({ kind: "publish", title: "Yayına al", body: "İçerik herkese açık sayfada görünür olacak. Değişiklik özeti zorunlu.", label: "Yayına al" })}
                className="min-h-11 rounded-md bg-st-delivered px-4 text-sm font-semibold text-white transition hover:opacity-90 disabled:opacity-40">
                Yayına al
              </button>
            </Tooltip>
          ) : null}
          {canPublish ? (
            <button type="button"
              onClick={() => setConfirm({ kind: "archive", title: "Sayfayı arşivle", body: "Sayfa yayından kalkar ve listelerde görünmez. Kalıcı silme yapılmaz.", label: "Arşivle" })}
              className="min-h-11 rounded-md border border-red-300 px-4 text-sm font-semibold text-red-700 transition hover:bg-red-50">
              Arşivle
            </button>
          ) : null}
          <a href={`/${page.slug.startsWith("yasal") ? page.slug : page.slug}`} className="min-h-11 rounded-md border border-slate-300 px-4 text-sm text-slate-700 transition hover:border-slate-500">
            Önizleme
          </a>
        </div>
      </section>

      <aside className="rounded-lg border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Sürüm geçmişi</h2>
        <ul className="mt-3 space-y-3">
          {versions.map((version) => (
            <li key={version.id} className="rounded-md border border-slate-200 p-3">
              <div className="flex items-center justify-between gap-2">
                <p className="text-sm font-semibold text-[#0B1220]">v{version.version}</p>
                <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] text-slate-600">
                  {STATUS_LABEL[version.status] ?? version.status}
                </span>
              </div>
              <p className="mt-1 text-xs text-slate-600">{version.changeNote || "özet yok"}</p>
              <p className="text-[11px] text-slate-500">{new Date(version.createdAt).toLocaleString("tr-TR")}</p>
              {canRestore && version.version !== page.version ? (
                <button type="button"
                  onClick={() =>
                    setConfirm({
                      kind: "restore",
                      version: version.version,
                      title: `v${version.version} sürümüne dön`,
                      body: "İçerik bu sürümden geri yüklenecek. Geçmiş silinmez: geri yükleme YENİ bir sürüm olarak yazılır ve taslak durumuna döner.",
                      label: "Geri yükle",
                    })
                  }
                  className="mt-2 min-h-11 rounded-md border border-slate-300 px-3 text-xs font-semibold text-slate-700 transition hover:border-slate-500">
                  Bu sürüme dön
                </button>
              ) : null}
            </li>
          ))}
          {versions.length === 0 ? <li className="text-sm text-slate-500">Sürüm yok.</li> : null}
        </ul>
      </aside>

      <ConfirmDialog
        open={confirm !== null}
        title={confirm?.title ?? ""}
        body={confirm?.body ?? ""}
        confirmLabel={confirm?.label ?? "Onayla"}
        tone={confirm?.kind === "archive" ? "danger" : confirm?.kind === "restore" ? "warning" : "neutral"}
        requireReason={confirm?.kind !== "publish"}
        busy={saving}
        onConfirm={(reason) => {
          if (!confirm) return;
          if (confirm.kind === "publish") void save("yayinda");
          else if (confirm.kind === "archive") void archive(reason);
          else void restore(confirm.version, reason);
        }}
        onCancel={() => setConfirm(null)}
      />
    </div>
  );
}
