"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import StickyFormBar from "@/components/ui/StickyFormBar";
import ConfirmDialog from "@/components/ui/ConfirmDialog";

export type OrgDetail = {
  id: number;
  name: string;
  slug: string;
  type: string;
  category: string;
  description: string;
  contactEmail: string;
  contactPhone: string;
  city: string;
  district: string;
  verificationStatus: string;
  archivedAt: Date | string | null;
};

type Pending =
  | { kind: "archive"; title: string; body: string; label: string }
  | { kind: "change_plan"; planCode: string; title: string; body: string; label: string }
  | { kind: "create_invoice"; title: string; body: string; label: string }
  | null;

function tl(kurus: number) {
  return new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(kurus / 100);
}

/** İşletme dosyası: profil, üyeler, abonelik, kullanım ve faturalar. */
export default function OrgPanel({
  org,
  members,
  subscription,
  usage,
  invoices,
  plans,
  canManage,
  canSeeVerification,
}: {
  org: OrgDetail;
  members: { id: number; userId: number; orgRole: string; fullName: string; email: string; isActive: boolean }[];
  subscription: { status: string; trialEndsAt: Date | string | null; currentPeriodEnd: Date | string | null; plan: { code: string; name: string; monthlyKurus: number } | null } | null;
  usage: { shipmentsUsed: number; shipmentLimit: number | null; seatsUsed: number; seatLimit: number | null; overLimit: boolean };
  invoices: { id: number; number: string; totalKurus: number; status: string; dueDate: Date | string | null; note: string }[];
  plans: { code: string; name: string; monthlyKurus: number; shipmentLimit: number; seatLimit: number }[];
  canManage: boolean;
  canSeeVerification: boolean;
}) {
  const router = useRouter();
  const initial = {
    name: org.name,
    description: org.description,
    category: org.category,
    contactEmail: org.contactEmail,
    contactPhone: org.contactPhone,
    city: org.city,
    district: org.district,
    verificationStatus: org.verificationStatus,
  };
  const [form, setForm] = useState(initial);
  const [draft, setDraft] = useState(initial);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [pending, setPending] = useState<Pending>(null);
  const [memberEmail, setMemberEmail] = useState("");

  const dirty = JSON.stringify(form) !== JSON.stringify(draft);

  async function save() {
    setSaving(true);
    setError("");
    const payload = canSeeVerification ? form : { ...form, verificationStatus: undefined };
    const res = await fetch(`/api/admin/orgs/${org.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    setSaving(false);
    if (!res.ok) {
      setError(data.error ?? "Kaydedilemedi.");
      return;
    }
    setDraft({ ...form });
    setSaved(true);
    router.refresh();
  }

  async function post(body: Record<string, unknown>, reason?: string) {
    setSaving(true);
    setError("");
    const res = await fetch(`/api/admin/orgs/${org.id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...body, reason: reason ?? body.reason }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    setSaving(false);
    setPending(null);
    if (!res.ok) {
      setError(data.error ?? "İşlem başarısız.");
      return;
    }
    setMemberEmail("");
    router.refresh();
  }

  return (
    <div className="grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
      <section className="rounded-lg border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">İşletme dosyası</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field id="org-name" label="İşletme adı" value={form.name} disabled={!canManage}
            onChange={(v) => setForm((f) => ({ ...f, name: v }))} />
          <Field id="org-category" label="Kategori" value={form.category} disabled={!canManage}
            onChange={(v) => setForm((f) => ({ ...f, category: v }))} />
          <Field id="org-email" label="İletişim e-postası" value={form.contactEmail} disabled={!canManage}
            onChange={(v) => setForm((f) => ({ ...f, contactEmail: v }))} />
          <Field id="org-phone" label="İletişim telefonu" value={form.contactPhone} disabled={!canManage}
            onChange={(v) => setForm((f) => ({ ...f, contactPhone: v }))} />
          <Field id="org-city" label="Şehir" value={form.city} disabled={!canManage}
            onChange={(v) => setForm((f) => ({ ...f, city: v }))} />
          <Field id="org-district" label="İlçe" value={form.district} disabled={!canManage}
            onChange={(v) => setForm((f) => ({ ...f, district: v }))} />
        </div>
        <div className="mt-4">
          <label htmlFor="org-desc" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Tanıtım metni</label>
          <textarea id="org-desc" rows={4} className="input-light mt-2" value={form.description} disabled={!canManage} maxLength={1200}
            onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
        </div>
        {canSeeVerification ? (
          <div className="mt-4">
            <label htmlFor="org-verification" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Doğrulama durumu</label>
            <select id="org-verification" className="input-light mt-2" value={form.verificationStatus}
              onChange={(e) => setForm((f) => ({ ...f, verificationStatus: e.target.value }))}>
              {[["dogrulanmadi", "Doğrulanmadı"], ["incelemede", "İncelemede"], ["dogrulandi", "Doğrulandı"], ["reddedildi", "Reddedildi"]].map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
              ))}
            </select>
          </div>
        ) : (
          <p className="mt-4 text-[11px] text-slate-500">
            Doğrulama durumu yalnızca platform personeli tarafından değiştirilebilir.
          </p>
        )}
        <StickyFormBar dirty={dirty} saving={saving} saved={saved} error={error} onSave={save} onReset={() => setForm({ ...draft })} />

        {canManage ? (
          <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-4">
            <button type="button" onClick={() => setPending({ kind: "create_invoice", title: "Fatura oluştur", body: "Abonelik planı üzerinden fatura kesilecek. Ödeme sağlayıcısı bağlı değil; fatura kayıt olarak oluşur.", label: "Fatura oluştur" })}
              className="min-h-11 rounded-md border border-slate-300 px-4 text-sm text-slate-700 transition hover:border-slate-500">
              Fatura oluştur
            </button>
            <button type="button" onClick={() => setPending({ kind: "archive", title: "İşletmeyi arşivle", body: "İşletme listelerden kalkar; gönderi, fatura ve denetim kayıtları korunur.", label: "Arşivle" })}
              className="min-h-11 rounded-md border border-red-300 px-4 text-sm font-semibold text-red-700 transition hover:bg-red-50">
              Arşivle
            </button>
          </div>
        ) : null}
      </section>

      <div className="space-y-5">
        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Abonelik ve kullanım</h2>
          {subscription ? (
            <>
              <p className="mt-2 text-sm text-slate-700">
                <strong>{subscription.plan?.name ?? "—"}</strong> · {subscription.status}
              </p>
              <p className="text-xs text-slate-500">
                dönem sonu: {subscription.currentPeriodEnd ? new Date(subscription.currentPeriodEnd).toLocaleDateString("tr-TR") : "—"}
                {subscription.trialEndsAt ? ` · deneme: ${new Date(subscription.trialEndsAt).toLocaleDateString("tr-TR")}` : ""}
              </p>
            </>
          ) : (
            <p className="mt-2 text-sm text-slate-500">Abonelik yok.</p>
          )}
          <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
            <div>
              <dt className="text-[11px] uppercase tracking-[0.1em] text-slate-500">Gönderi kullanımı</dt>
              <dd className={`font-display text-lg font-bold ${usage.overLimit ? "text-st-risk" : "text-[#0B1220]"}`}>
                {usage.shipmentsUsed} / {usage.shipmentLimit ?? "—"}
              </dd>
            </div>
            <div>
              <dt className="text-[11px] uppercase tracking-[0.1em] text-slate-500">Koltuk</dt>
              <dd className="font-display text-lg font-bold text-[#0B1220]">
                {usage.seatsUsed} / {usage.seatLimit ?? "—"}
              </dd>
            </div>
          </dl>
          {usage.overLimit ? (
            <p className="mt-2 rounded-md border border-red-300 bg-red-50 p-2 text-xs text-red-800">
              Limit aşıldı: gönderi sayısı plan sınırının üzerinde.
            </p>
          ) : null}
          {canManage ? (
            <div className="mt-4 flex flex-wrap gap-2">
              {plans.map((plan) => (
                <button key={plan.code} type="button"
                  onClick={() => setPending({ kind: "change_plan", planCode: plan.code, title: "Planı değiştir", body: `${plan.name} (${tl(plan.monthlyKurus)}/ay, ${plan.shipmentLimit} gönderi, ${plan.seatLimit} koltuk). Değişiklik hemen uygulanır ve gerekçe kaydedilir.`, label: "Planı uygula" })}
                  className="min-h-11 rounded-md border border-slate-300 px-3 text-xs text-slate-700 transition hover:border-slate-500">
                  {plan.name}
                </button>
              ))}
            </div>
          ) : null}
        </section>

        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Çalışanlar</h2>
          <ul className="mt-3 divide-y divide-slate-100 text-sm">
            {members.map((member) => (
              <li key={member.id} className="flex items-center justify-between gap-2 py-2">
                <div className="min-w-0">
                  <p className="truncate text-slate-800">{member.fullName}</p>
                  <p className="font-mono text-[11px] text-slate-500">{member.email}</p>
                </div>
                <span className="shrink-0 rounded-full bg-slate-100 px-2 py-0.5 text-[11px] text-slate-600">{member.orgRole}</span>
              </li>
            ))}
            {members.length === 0 ? <li className="py-3 text-slate-500">Üye yok.</li> : null}
          </ul>
          {canManage ? (
            <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); void post({ action: "add_member", email: memberEmail, orgRole: "calisan", reason: "Çalışan eklendi" }); }}>
              <input value={memberEmail} onChange={(e) => setMemberEmail(e.target.value)} placeholder="e-posta" aria-label="Eklenecek üye e-postası" className="input-light py-2 text-sm" />
              <button type="submit" disabled={!memberEmail.includes("@")} className="shrink-0 rounded-md bg-accent px-3 text-xs font-semibold text-[#0B1220] disabled:opacity-50">
                Ekle
              </button>
            </form>
          ) : null}
        </section>

        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Faturalar</h2>
          <ul className="mt-3 divide-y divide-slate-100 text-sm">
            {invoices.map((invoice) => (
              <li key={invoice.id} className="py-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-slate-700">{invoice.number}</span>
                  <span className="font-semibold text-[#0B1220]">{tl(invoice.totalKurus)}</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  {invoice.status} · son ödeme {invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString("tr-TR") : "—"}
                </p>
              </li>
            ))}
            {invoices.length === 0 ? <li className="py-3 text-slate-500">Fatura yok.</li> : null}
          </ul>
          <p className="mt-3 text-[11px] text-slate-500">
            Kart bilgisi saklanmaz; ödeme sağlayıcısı bağlı olmadığı için tahsilat yapılmaz.
          </p>
        </section>
      </div>

      <ConfirmDialog
        open={pending !== null}
        title={pending?.title ?? ""}
        body={pending?.body ?? ""}
        confirmLabel={pending?.label ?? "Onayla"}
        tone={pending?.kind === "archive" ? "danger" : "warning"}
        requireReason
        busy={saving}
        onConfirm={(reason) => {
          if (!pending) return;
          if (pending.kind === "archive") void post({ action: "archive" }, reason);
          else if (pending.kind === "change_plan") void post({ action: "change_plan", planCode: pending.planCode }, reason);
          else void post({ action: "create_invoice" }, reason);
        }}
        onCancel={() => setPending(null)}
      />
    </div>
  );
}

function Field({
  id,
  label,
  value,
  onChange,
  disabled,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  disabled?: boolean;
}) {
  return (
    <div>
      <label htmlFor={id} className="text-[11px] uppercase tracking-[0.12em] text-slate-500">{label}</label>
      <input id={id} className="input-light mt-2" value={value} disabled={disabled} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
