"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Download } from "lucide-react";
import DataTable, { type Column } from "@/components/ui/DataTable";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import Tooltip from "@/components/ui/Tooltip";

export type MemberRow = {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  role: string;
  roleLabel: string;
  orgName: string;
  isActive: boolean;
  isBanned: boolean;
  archived: boolean;
  mfaEnabled: boolean;
  mustChangePassword: boolean;
  verified: boolean;
  lastLoginAt: string | Date | null;
  createdAt: string | Date;
  courierStatus: string | null;
  courierCity: string | null;
};

function Badge({ tone, children }: { tone: "ok" | "warn" | "bad" | "idle"; children: React.ReactNode }) {
  const map = {
    ok: "bg-green-100 text-green-800",
    warn: "bg-amber-100 text-amber-800",
    bad: "bg-red-100 text-red-800",
    idle: "bg-slate-100 text-slate-600",
  } as const;
  return <span className={`rounded-full px-2 py-0.5 text-[11px] font-semibold ${map[tone]}`}>{children}</span>;
}

/** Üye listesi: arama, sıralama, sayfalama, dışa aktarma (gerekçeli). */
export default function MembersTable({
  rows,
  canExport,
  canSeeSensitive,
}: {
  rows: MemberRow[];
  canExport: boolean;
  canSeeSensitive: boolean;
}) {
  const router = useRouter();
  const [exportOpen, setExportOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const columns: Column<MemberRow>[] = [
    {
      key: "fullName",
      header: "Üye",
      value: (row) => row.fullName,
      render: (row) => (
        <span className="font-medium text-[#0B1220]">
          {row.fullName}
          {row.archived ? <span className="ml-2 text-[11px] text-slate-500">(arşiv)</span> : null}
        </span>
      ),
    },
    { key: "email", header: "E-posta", value: (row) => row.email },
    {
      key: "role",
      header: "Rol",
      value: (row) => row.roleLabel,
      render: (row) => <Badge tone={row.role === "admin" || row.role === "super_admin" ? "warn" : "idle"}>{row.roleLabel}</Badge>,
    },
    { key: "orgName", header: "İşletme", value: (row) => row.orgName || "—" },
    {
      key: "status",
      header: "Durum",
      value: (row) => (row.isBanned ? 2 : row.archived ? 3 : row.isActive ? 0 : 1),
      render: (row) =>
        row.isBanned ? (
          <Badge tone="bad">banlı</Badge>
        ) : row.archived ? (
          <Badge tone="idle">arşiv</Badge>
        ) : row.isActive ? (
          <Badge tone="ok">aktif</Badge>
        ) : (
          <Badge tone="warn">pasif</Badge>
        ),
    },
    {
      key: "mfa",
      header: "MFA",
      value: (row) => (row.mfaEnabled ? 1 : 0),
      render: (row) =>
        row.mfaEnabled ? <Badge tone="ok">etkin</Badge> : <Badge tone="idle">kapalı</Badge>,
    },
    {
      key: "lastLoginAt",
      header: "Son giriş",
      value: (row) => (row.lastLoginAt ? new Date(row.lastLoginAt).getTime() : 0),
      render: (row) => (row.lastLoginAt ? new Date(row.lastLoginAt).toLocaleString("tr-TR") : "hiç"),
    },
  ];

  async function runExport(withSensitive: boolean, reasonText: string) {
    setBusy(true);
    setError("");
    const params = new URLSearchParams({ reason: reasonText });
    if (withSensitive) params.set("sensitive", "1");
    const res = await fetch(`/api/admin/members/export?${params.toString()}`);
    setBusy(false);
    if (!res.ok) {
      setError(await res.text());
      return;
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `uyeler-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
    setExportOpen(false);
  }

  return (
    <div>
      {canExport ? (
        <div className="mb-3 flex justify-end">
          <Tooltip label="CSV indir. Gerekçe zorunludur ve denetim kaydına yazılır.">
            <button
              type="button"
              onClick={() => setExportOpen(true)}
              className="inline-flex min-h-11 items-center gap-2 rounded-md border border-slate-300 bg-white px-4 text-sm text-slate-700 transition hover:border-slate-500 hover:bg-slate-50"
            >
              <Download size={15} aria-hidden /> Dışa aktar
            </button>
          </Tooltip>
        </div>
      ) : null}

      <DataTable
        rows={rows}
        columns={columns}
        searchKeys={["fullName", "email", "roleLabel", "orgName"]}
        rowKey={(row) => row.id}
        onRowClick={(row) => router.push(`/admin/uyeler/${row.id}`)}
        emptyText="Filtreye uyan üye yok."
        initialSort={{ key: "lastLoginAt", dir: "desc" }}
      />

      {!canSeeSensitive ? (
        <p className="mt-3 text-[11px] text-slate-500">
          E-posta ve telefon maskeli gösteriliyor: hassas alan iznin yok. Tam değer için yetki gerekir ve erişim
          denetime yazılır.
        </p>
      ) : null}

      <ConfirmDialog
        open={exportOpen}
        title="Üyeleri dışa aktar"
        body="CSV dosyası indirilecek. Bu işlem kişisel veri içerir; gerekçe zorunludur ve denetim kaydına yazılır. Parola, erişim kodu ve MFA sırrı dosyaya dahil edilmez."
        confirmLabel="CSV indir"
        tone="warning"
        requireReason
        reasonLabel="Dışa aktarma gerekçesi"
        busy={busy}
        onConfirm={(reasonText) => runExport(canSeeSensitive, reasonText)}
        onCancel={() => setExportOpen(false)}
      />
      {error ? (
        <p role="alert" className="mt-2 text-sm text-st-risk">
          {error}
        </p>
      ) : null}
      <p className="mt-3 text-[11px] text-slate-500">
        Hassas alan dahil export: {canSeeSensitive ? "açık (e-posta/telefon açık yazılır)" : "kapalı (maskeli)"}
      </p>
    </div>
  );
}
