"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Tabs from "@/components/ui/Tabs";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import StickyFormBar from "@/components/ui/StickyFormBar";
import Tooltip from "@/components/ui/Tooltip";

type Pending = { action: string; title: string; body: string; label: string; tone: "danger" | "warning" | "neutral"; value?: string } | null;

export type MemberDetail = {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  role: string;
  roleLabel: string;
  permissions: number;
  orgId: number | null;
  isActive: boolean;
  isBanned: boolean;
  archived: boolean;
  mustChangePassword: boolean;
  mfaEnabled: boolean;
  marketingConsent: boolean;
  kvkkConsentAt: string | Date | null;
  lastLoginAt: string | Date | null;
  createdAt: string | Date;
};

const ROLES = [
  ["musteri", "Müşteri"],
  ["kurye", "Kurye"],
  ["surucu", "Sürücü"],
  ["surucu_adayi", "Sürücü adayı"],
  ["ops", "Operasyon"],
  ["finance", "Finans"],
  ["support", "Destek"],
  ["guvenlik", "Güvenlik"],
  ["editor", "İçerik editörü"],
  ["isletme_sahibi", "İşletme sahibi"],
  ["isletme_calisani", "İşletme çalışanı"],
  ["admin", "Yönetici"],
  ["super_admin", "Platform yöneticisi"],
];

/** Üye profili: sekmeler, düzenleme, durum işlemleri, notlar, denetim. */
export default function MemberProfile({
  member,
  canManage,
  canSensitive,
  canResetPassword,
  notes,
  audit,
  tickets,
  shipments,
  orders,
  courier,
  courierId,
}: {
  member: MemberDetail;
  canManage: boolean;
  canSensitive: boolean;
  canResetPassword: boolean;
  notes: { id: number; body: string; createdAt: Date | string; authorId: number | null }[];
  audit: { id: number; action: string; entity: string; entityId: string; reason: string; createdAt: Date | string }[];
  tickets: { id: number; code: string; subject: string; status: string; createdAt: Date | string }[];
  shipments: { id: number; code: string; status: string; priceKurus: number; createdAt: Date | string }[];
  orders: { id: number; code: string; status: string; totalKurus: number; createdAt: Date | string }[];
  courier: { id: number; status: string; city: string; vehicle: string } | null;
  courierId: number | null;
}) {
  const router = useRouter();
  const [form, setForm] = useState({ fullName: member.fullName, email: member.email, phone: member.phone });
  const [draft, setDraft] = useState({ ...form });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [pending, setPending] = useState<Pending>(null);
  const [note, setNote] = useState("");
  const [resetLink, setResetLink] = useState("");

  const dirty = JSON.stringify(form) !== JSON.stringify(draft);

  async function save() {
    setSaving(true);
    setError("");
    const res = await fetch(`/api/admin/members/${member.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string; reverifyRequired?: boolean };
    setSaving(false);
    if (!res.ok) {
      setError(data.error ?? "Kaydedilemedi.");
      return;
    }
    setDraft({ ...form });
    setSaved(true);
    if (data.reverifyRequired) {
      setError("İletişim bilgisi değişti: üyeden yeniden doğrulama istenecek ve ilk girişte şifre değişimi zorunlu.");
    }
    router.refresh();
  }

  async function runAction(action: string, reason: string, value?: string) {
    setSaving(true);
    setError("");
    const res = await fetch(`/api/admin/members/${member.id}/actions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, reason, value }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string; resetLink?: string };
    setSaving(false);
    setPending(null);
    if (!res.ok) {
      setError(data.error ?? "İşlem başarısız.");
      return;
    }
    if (data.resetLink) {
      setResetLink(data.resetLink);
    }
    router.refresh();
  }

  function tl(kurus: number) {
    return new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(kurus / 100);
  }

  const items = [
    {
      key: "genel",
      label: "Genel bakış",
      content: (
        <div className="grid gap-4 md:grid-cols-3">
          <InfoCard label="Durum">
            {member.isBanned ? "Banlı" : member.archived ? "Arşivde" : member.isActive ? "Aktif" : "Pasif"}
          </InfoCard>
          <InfoCard label="Rol">{member.roleLabel}</InfoCard>
          <InfoCard label="İzin sayısı">{member.permissions}</InfoCard>
          <InfoCard label="İki aşamalı doğrulama">{member.mfaEnabled ? "Etkin" : "Kapalı"}</InfoCard>
          <InfoCard label="Şifre değişimi zorunlu">{member.mustChangePassword ? "Evet" : "Hayır"}</InfoCard>
          <InfoCard label="KVKK onayı">{member.kvkkConsentAt ? new Date(member.kvkkConsentAt).toLocaleDateString("tr-TR") : "yok"}</InfoCard>
          <InfoCard label="Pazarlama izni">{member.marketingConsent ? "Verilmiş" : "Verilmemiş"}</InfoCard>
          <InfoCard label="Son giriş">{member.lastLoginAt ? new Date(member.lastLoginAt).toLocaleString("tr-TR") : "hiç"}</InfoCard>
          <InfoCard label="Kayıt">{new Date(member.createdAt).toLocaleDateString("tr-TR")}</InfoCard>
        </div>
      ),
    },
    {
      key: "profil",
      label: "Profil ve iletişim",
      content: (
        <div>
          {!canSensitive ? (
            <p className="mb-3 rounded-md border border-amber-300 bg-amber-50 p-3 text-xs text-amber-900">
              İletişim bilgilerini değiştirmek için hassas alan izni gerekir. Değerler maskeli gösteriliyor.
            </p>
          ) : null}
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="m-name" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Ad soyad</label>
              <input id="m-name" className="input-light mt-2" value={form.fullName} disabled={!canManage}
                onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))} />
            </div>
            <div>
              <label htmlFor="m-email" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">E-posta</label>
              <input id="m-email" className="input-light mt-2" value={form.email} disabled={!canManage || !canSensitive}
                onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
              <p className="mt-1 text-[11px] text-slate-500">Değişirse doğrulama düşer ve şifre değişimi zorunlu olur.</p>
            </div>
            <div>
              <label htmlFor="m-phone" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Telefon</label>
              <input id="m-phone" className="input-light mt-2" value={form.phone} disabled={!canManage || !canSensitive}
                onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
            </div>
            <div>
              <label htmlFor="m-role" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Rol</label>
              <select id="m-role" className="input-light mt-2" value={member.role} disabled={!canManage}
                onChange={(e) =>
                  setPending({
                    action: "change_role",
                    title: "Rolü değiştir",
                    body: `Yeni rol: ${ROLES.find((r) => r[0] === e.target.value)?.[1] ?? e.target.value}. Rol değişikliği yetki tırmanması riski taşır; gerekçe denetim kaydına yazılır.`,
                    label: "Rolü değiştir",
                    tone: "warning",
                    value: e.target.value,
                  })
                }>
                {ROLES.map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>
          </div>
          <StickyFormBar dirty={dirty} saving={saving} saved={saved} error={error} onSave={save} onReset={() => setForm({ ...draft })}>
            {canManage ? "" : "salt okunur"}
          </StickyFormBar>
        </div>
      ),
    },
    ...(courierId
      ? [
          {
            key: "cv",
            label: "CV / kurye profili",
            content: (
              <div className="rounded-lg border border-slate-200 bg-white p-5">
                <p className="text-sm text-slate-600">
                  Bu üye kurye kaydı. CV düzenleme ekranı: kurye #{courierId}
                  {courier ? ` · ${courier.city} · ${courier.vehicle} · ${courier.status}` : ""}
                </p>
                <a href={`/admin/kurye-cv/${courierId}`} className="mt-3 inline-block rounded-md bg-accent px-4 py-2 text-sm font-semibold text-[#0B1220]">
                  CV&apos;yi aç
                </a>
              </div>
            ),
          },
        ]
      : []),
    {
      key: "islem",
      label: "Hesap durumu",
      content: (
        <div className="grid gap-3 md:grid-cols-2">
          <ActionCard
            title="Pasife al / aktifleştir"
            body="Üye giriş yapamaz ama kayıtları korunur. Gerekçe zorunlu."
            disabled={!canManage}
            onAct={() =>
              setPending({
                action: member.isActive ? "deactivate" : "activate",
                title: member.isActive ? "Üyeyi pasife al" : "Üyeyi aktifleştir",
                body: member.isActive
                  ? "Üye giriş yapamayacak. Gerekçe denetim kaydına yazılır."
                  : "Üye yeniden giriş yapabilecek.",
                label: member.isActive ? "Pasife al" : "Aktifleştir",
                tone: member.isActive ? "warning" : "neutral",
              })
            }
            label={member.isActive ? "Pasife al" : "Aktifleştir"}
          />
          <ActionCard
            title={member.isBanned ? "Banı kaldır" : "Banla"}
            body="Ban kalıcı bir güvenlik önlemidir; gerekçe ve denetim kaydı zorunludur."
            disabled={!canManage}
            onAct={() =>
              setPending({
                action: member.isBanned ? "unban" : "ban",
                title: member.isBanned ? "Banı kaldır" : "Üyeyi banla",
                body: "Bu işlem hesabı kilitler. Gerekçe denetim kaydına yazılır.",
                label: member.isBanned ? "Banı kaldır" : "Banla",
                tone: member.isBanned ? "neutral" : "danger",
              })
            }
            label={member.isBanned ? "Banı kaldır" : "Banla"}
          />
          <ActionCard
            title="Arşivle"
            body="Kalıcı silme yoktur. Arşivlenen üye listelerde görünmez, kayıtları saklanır."
            disabled={!canManage || member.archived}
            onAct={() =>
              setPending({
                action: "archive",
                title: "Üyeyi arşivle",
                body: "Üye listelerden kalkar; gönderi, mali ve denetim kayıtları korunur. KVKK silme talebi ayrıca işlenir.",
                label: "Arşivle",
                tone: "danger",
              })
            }
            label="Arşivle"
          />
          <ActionCard
            title="Parola sıfırlama başlat"
            body="Yönetici parolayı GÖREMEZ. Bağlantı bir kez üretilir, 30 dakika geçerlidir."
            disabled={!canResetPassword}
            onAct={() =>
              setPending({
                action: "reset_password",
                title: "Parola sıfırlama bağlantısı üret",
                body: "Bağlantı bir kez gösterilir ve üyenin ilk girişte şifresini değiştirmesi zorunlu olur. Parola yöneticiye gösterilmez.",
                label: "Bağlantı üret",
                tone: "warning",
              })
            }
            label="Bağlantı üret"
          />
          {resetLink ? (
            <p className="rounded-md border border-green-300 bg-green-50 p-3 font-mono text-xs text-green-900 md:col-span-2">
              Sıfırlama bağlantısı (yalnızca bir kez gösterilir): {resetLink}
            </p>
          ) : null}
        </div>
      ),
    },
    {
      key: "notlar",
      label: "Yönetici notları",
      badge: notes.length,
      content: (
        <div>
          {canManage ? (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                void runAction("add_note", note);
                setNote("");
              }}
              className="rounded-lg border border-slate-200 bg-white p-4"
            >
              <label htmlFor="note-body" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Yeni not</label>
              <textarea id="note-body" rows={3} className="input-light mt-2" value={note} onChange={(e) => setNote(e.target.value)} minLength={5} maxLength={300} />
              <button type="submit" disabled={note.trim().length < 5} className="mt-3 rounded-md bg-accent px-4 py-2 text-sm font-semibold text-[#0B1220] disabled:opacity-50">
                Not ekle
              </button>
            </form>
          ) : null}
          <ul className="mt-4 space-y-2">
            {notes.map((item) => (
              <li key={item.id} className="rounded-lg border border-slate-200 bg-white p-4 text-sm">
                <p className="text-slate-700">{item.body}</p>
                <p className="mt-1 text-[11px] text-slate-500">{new Date(item.createdAt).toLocaleString("tr-TR")}</p>
              </li>
            ))}
            {notes.length === 0 ? <li className="text-sm text-slate-500">Not yok.</li> : null}
          </ul>
        </div>
      ),
    },
    {
      key: "islemler",
      label: "İşlemler",
      badge: shipments.length + orders.length,
      content: (
        <div className="grid gap-5 md:grid-cols-2">
          <ListCard title="Gönderiler" rows={shipments.map((s) => ({ id: s.id, main: s.code, sub: `${s.status} · ${tl(s.priceKurus)}`, date: s.createdAt }))} />
          <ListCard title="Siparişler" rows={orders.map((o) => ({ id: o.id, main: o.code, sub: `${o.status} · ${tl(o.totalKurus)}`, date: o.createdAt }))} />
        </div>
      ),
    },
    {
      key: "destek",
      label: "Destek talepleri",
      badge: tickets.length,
      content: <ListCard title="Talepler" rows={tickets.map((t) => ({ id: t.id, main: `${t.code} · ${t.subject}`, sub: t.status, date: t.createdAt }))} />,
    },
    {
      key: "denetim",
      label: "Denetim kaydı",
      badge: audit.length,
      content: (
        <ul className="divide-y divide-slate-100 rounded-lg border border-slate-200 bg-white text-sm">
          {audit.map((log) => (
            <li key={log.id} className="p-3">
              <p className="font-medium text-slate-800">{log.action}</p>
              <p className="text-xs text-slate-500">
                {log.entity}#{log.entityId} · {new Date(log.createdAt).toLocaleString("tr-TR")}
                {log.reason ? ` · gerekçe: ${log.reason}` : ""}
              </p>
            </li>
          ))}
          {audit.length === 0 ? <li className="p-4 text-slate-500">Kayıt yok.</li> : null}
        </ul>
      ),
    },
  ];

  return (
    <div>
      <Tabs items={items} />
      <ConfirmDialog
        open={pending !== null}
        title={pending?.title ?? ""}
        body={pending?.body ?? ""}
        confirmLabel={pending?.label ?? "Onayla"}
        tone={pending?.tone ?? "danger"}
        requireReason
        busy={saving}
        onConfirm={(reason) => pending && runAction(pending.action, reason, pending.value)}
        onCancel={() => setPending(null)}
      />
      {error && !dirty ? (
        <p role="status" className="mt-3 text-sm text-amber-700">
          {error}
        </p>
      ) : null}
    </div>
  );
}

function InfoCard({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4">
      <p className="text-[11px] uppercase tracking-[0.12em] text-slate-500">{label}</p>
      <p className="mt-1 text-sm font-semibold text-[#0B1220]">{children}</p>
    </div>
  );
}

function ActionCard({
  title,
  body,
  label,
  onAct,
  disabled,
}: {
  title: string;
  body: string;
  label: string;
  onAct: () => void;
  disabled?: boolean;
}) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4">
      <p className="text-sm font-semibold text-[#0B1220]">{title}</p>
      <p className="mt-1 text-xs text-slate-500">{body}</p>
      <Tooltip label={disabled ? "Bu işlem için yetkin yok" : "Onay penceresi açılır, gerekçe istenir"}>
        <button
          type="button"
          onClick={onAct}
          disabled={disabled}
          className="mt-3 min-h-11 rounded-md border border-slate-300 px-4 text-sm text-slate-700 transition hover:border-slate-500 hover:bg-slate-50 disabled:opacity-40"
        >
          {label}
        </button>
      </Tooltip>
    </div>
  );
}

function ListCard({ title, rows }: { title: string; rows: { id: number; main: string; sub: string; date: Date | string }[] }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4">
      <p className="text-sm font-semibold text-[#0B1220]">{title}</p>
      {rows.length === 0 ? (
        <p className="mt-2 text-sm text-slate-500">Kayıt yok.</p>
      ) : (
        <ul className="mt-3 divide-y divide-slate-100 text-sm">
          {rows.map((row) => (
            <li key={row.id} className="py-2">
              <p className="font-medium text-slate-800">{row.main}</p>
              <p className="text-xs text-slate-500">
                {row.sub} · {new Date(row.date).toLocaleDateString("tr-TR")}
              </p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
