"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import StickyFormBar from "@/components/ui/StickyFormBar";
import ConfirmDialog from "@/components/ui/ConfirmDialog";

export type TemplateRow = {
  id: number;
  key: string;
  name: string;
  channel: string;
  subject: string;
  body: string;
  isActive: boolean;
};

/**
 * Platform ayarları, bildirim şablonları ve iki aşamalı doğrulama.
 * Gizli anahtarlar (API secret, parola) bu ekranda tutulmaz ve gösterilmez.
 */
export default function SettingsPanel({
  settings,
  templates,
  mfaEnabled,
  canManage,
}: {
  settings: { key: string; value: unknown; updatedAt: Date | string }[];
  templates: TemplateRow[];
  mfaEnabled: boolean;
  canManage: boolean;
}) {
  const router = useRouter();
  const [values, setValues] = useState<Record<string, string>>(
    Object.fromEntries(settings.map((row) => [row.key, JSON.stringify(row.value, null, 2)])),
  );
  const [draft] = useState({ ...values });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState<TemplateRow | null>(null);
  const [mfaStep, setMfaStep] = useState<"idle" | "enrolled" | "done">("idle");
  const [secret, setSecret] = useState("");
  const [otpauth, setOtpauth] = useState("");
  const [code, setCode] = useState("");
  const [disableOpen, setDisableOpen] = useState(false);

  const dirty = JSON.stringify(values) !== JSON.stringify(draft);

  async function saveSetting(key: string) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(values[key]);
    } catch {
      setError(`${key}: geçerli JSON değil.`);
      return;
    }
    setSaving(true);
    setError("");
    const res = await fetch("/api/admin/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target: "setting", key, value: parsed, reason: "Panel üzerinden ayar güncellendi" }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Kaydedilemedi.");
      return;
    }
    setSaved(true);
    router.refresh();
  }

  async function saveTemplate() {
    if (!editing) return;
    setSaving(true);
    setError("");
    const res = await fetch("/api/admin/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target: "template",
        key: editing.key,
        subject: editing.subject,
        body: editing.body,
        isActive: editing.isActive,
        reason: "Bildirim şablonu güncellendi",
      }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Şablon kaydedilemedi.");
      return;
    }
    setEditing(null);
    router.refresh();
  }

  async function enroll() {
    setError("");
    const res = await fetch("/api/mfa", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "enroll" }),
    });
    const data = (await res.json().catch(() => ({}))) as { secret?: string; otpauth?: string; error?: string };
    if (!res.ok) {
      setError(data.error ?? "Kurulum başlatılamadı.");
      return;
    }
    setSecret(data.secret ?? "");
    setOtpauth(data.otpauth ?? "");
    setMfaStep("enrolled");
  }

  async function verify() {
    setError("");
    const res = await fetch("/api/mfa", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "verify", code }),
    });
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Kod doğrulanamadı.");
      return;
    }
    setMfaStep("done");
    setSecret("");
    router.refresh();
  }

  async function disable(reason: string) {
    setError("");
    const res = await fetch("/api/mfa", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "disable", reason }),
    });
    setDisableOpen(false);
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Kapatılamadı.");
      return;
    }
    setMfaStep("idle");
    router.refresh();
  }

  return (
    <div className="space-y-5">
      <section className="rounded-lg border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">İki aşamalı doğrulama</h2>
        <p className="mt-2 text-sm text-slate-600">
          Durum: <strong>{mfaEnabled || mfaStep === "done" ? "etkin" : "kapalı"}</strong>. TOTP sırrı kurulduktan sonra
          bir daha gösterilmez ve hiçbir listede yer almaz.
        </p>
        {mfaStep === "idle" && !mfaEnabled ? (
          <button type="button" onClick={enroll} className="mt-3 min-h-11 rounded-md bg-accent px-4 text-sm font-semibold text-[#0B1220]">
            Kurulumu başlat
          </button>
        ) : null}
        {mfaStep === "enrolled" ? (
          <div className="mt-3 rounded-md border border-amber-300 bg-amber-50 p-4">
            <p className="text-xs font-semibold text-amber-900">Bu sır yalnızca bir kez gösterilir:</p>
            <p className="mt-1 font-mono text-sm break-all text-amber-900">{secret}</p>
            <p className="mt-2 text-[11px] break-all text-amber-800">{otpauth}</p>
            <div className="mt-3 flex gap-2">
              <input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="6 haneli kod" aria-label="Doğrulama kodu" className="input-light w-40 font-mono" />
              <button type="button" onClick={verify} disabled={code.length !== 6} className="rounded-md bg-accent px-4 text-sm font-semibold text-[#0B1220] disabled:opacity-50">
                Etkinleştir
              </button>
            </div>
          </div>
        ) : null}
        {mfaEnabled || mfaStep === "done" ? (
          <button type="button" onClick={() => setDisableOpen(true)} className="mt-3 min-h-11 rounded-md border border-red-300 px-4 text-sm font-semibold text-red-700">
            İki aşamalı doğrulamayı kapat
          </button>
        ) : null}
      </section>

      {canManage ? (
        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Platform ayarları</h2>
          <div className="mt-4 space-y-4">
            {settings.map((setting) => (
              <div key={setting.key}>
                <label htmlFor={`set-${setting.key}`} className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
                  {setting.key}
                </label>
                <textarea id={`set-${setting.key}`} rows={4} className="input-light mt-2 font-mono text-xs"
                  value={values[setting.key] ?? ""}
                  onChange={(e) => setValues((v) => ({ ...v, [setting.key]: e.target.value }))} />
                <div className="mt-2 flex items-center gap-3">
                  <button type="button" onClick={() => saveSetting(setting.key)} disabled={saving}
                    className="min-h-11 rounded-md border border-slate-300 px-4 text-sm text-slate-700 transition hover:border-slate-500 disabled:opacity-50">
                    Kaydet
                  </button>
                  <span className="text-[11px] text-slate-500">son güncelleme: {new Date(setting.updatedAt).toLocaleString("tr-TR")}</span>
                </div>
              </div>
            ))}
          </div>
          <p className="mt-4 text-[11px] text-slate-500">
            API anahtarları ve parolalar burada TUTULMAZ; ortam değişkeni olarak kalır ve arayüzde gösterilmez.
          </p>
        </section>
      ) : null}

      <section className="rounded-lg border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Bildirim şablonları</h2>
        <ul className="mt-3 divide-y divide-slate-100">
          {templates.map((template) => (
            <li key={template.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div>
                <p className="text-sm font-medium text-[#0B1220]">{template.name}</p>
                <p className="text-xs text-slate-500">
                  {template.key} · {template.channel} · {template.isActive ? "etkin" : "pasif"}
                </p>
              </div>
              {canManage ? (
                <button type="button" onClick={() => setEditing({ ...template })}
                  className="min-h-11 rounded-md border border-slate-300 px-4 text-sm text-slate-700 transition hover:border-slate-500">
                  Düzenle
                </button>
              ) : null}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-[11px] text-slate-500">
          Gönderim sağlayıcısı bağlı değil: şablonlar saklanır ve durum geçişlerinde seçilir, ancak gerçek SMS/e-posta gönderilmez.
        </p>
      </section>

      {editing ? (
        <section className="rounded-lg border border-accent/40 bg-white p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Şablon düzenle · {editing.key}</h2>
          <div className="mt-3">
            <label htmlFor="tpl-subject" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Konu</label>
            <input id="tpl-subject" className="input-light mt-2" value={editing.subject}
              onChange={(e) => setEditing({ ...editing, subject: e.target.value })} />
          </div>
          <div className="mt-3">
            <label htmlFor="tpl-body" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Gövde</label>
            <textarea id="tpl-body" rows={5} className="input-light mt-2" value={editing.body}
              onChange={(e) => setEditing({ ...editing, body: e.target.value })} />
            <p className="mt-1 text-[11px] text-slate-500">Yer tutucular: {"{{code}} {{district}} {{amount}}"}</p>
          </div>
          <label className="mt-3 flex items-center gap-2 text-sm text-slate-700">
            <input type="checkbox" className="h-4 w-4 accent-[var(--accent)]" checked={editing.isActive}
              onChange={(e) => setEditing({ ...editing, isActive: e.target.checked })} />
            Etkin
          </label>
          <div className="mt-4 flex gap-2">
            <button type="button" onClick={saveTemplate} disabled={saving} className="rounded-md bg-accent px-4 py-2.5 text-sm font-semibold text-[#0B1220]">
              Kaydet
            </button>
            <button type="button" onClick={() => setEditing(null)} className="rounded-md border border-slate-300 px-4 py-2.5 text-sm text-slate-700">
              Vazgeç
            </button>
          </div>
        </section>
      ) : null}

      {error ? (
        <p role="alert" className="text-sm text-st-risk">{error}</p>
      ) : null}
      {saved && !dirty ? <p className="text-xs text-green-700">Son değişiklik kaydedildi.</p> : null}
      <StickyFormBar dirty={false} saving={saving} saved={saved} error="" onSave={() => undefined} saveLabel="—" />

      <ConfirmDialog
        open={disableOpen}
        title="İki aşamalı doğrulamayı kapat"
        body="Hesabın yalnızca parolayla korunacak. Gerekçe denetim kaydına yazılır."
        confirmLabel="Kapat"
        tone="danger"
        requireReason
        onConfirm={disable}
        onCancel={() => setDisableOpen(false)}
      />
    </div>
  );
}
