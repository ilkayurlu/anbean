"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import StickyFormBar from "@/components/ui/StickyFormBar";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import Tooltip from "@/components/ui/Tooltip";

export type CvItem = {
  id: number;
  kind: string;
  title: string;
  org: string;
  startsAt: string;
  endsAt: string;
  description: string;
  visibility: string;
  sortIndex: number;
};

const KINDS: { value: string; label: string }[] = [
  { value: "experience", label: "İş deneyimi" },
  { value: "education", label: "Eğitim" },
  { value: "skill", label: "Beceri" },
  { value: "certification", label: "Sertifika / belge" },
  { value: "language", label: "Dil" },
  { value: "service_area", label: "Hizmet bölgesi" },
  { value: "portfolio", label: "Portföy" },
];

const VISIBILITY: { value: string; label: string; hint: string }[] = [
  { value: "herkse_acik", label: "Herkese açık", hint: "Müşteri ve işletmeler görür" },
  { value: "personele_acik", label: "Yalnızca personel", hint: "Sadece yetkili panel rolleri" },
  { value: "gizli", label: "Gizli", hint: "Yalnızca hassas alan izni olan rol" },
];

/**
 * Kurye CV düzenleyici.
 * Alanlar prompt'taki CV başlıklarıyla birebir; örnek CV verilmediği için
 * EK hassas alan (TC kimlik, belge no, ev adresi) üretilmedi.
 */
export default function CvEditor({
  courierId,
  courierName,
  cv,
  items,
  canEdit,
}: {
  courierId: number;
  courierName: string;
  cv: {
    displayName: string;
    about: string;
    photoRef: string;
    defaultVisibility: string;
    availabilityNote: string;
    vehicleNote: string;
    profilePublished: boolean;
  } | null;
  items: CvItem[];
  canEdit: boolean;
}) {
  const router = useRouter();
  const initial = {
    displayName: cv?.displayName ?? courierName,
    about: cv?.about ?? "",
    photoRef: cv?.photoRef ?? "",
    defaultVisibility: cv?.defaultVisibility ?? "personele_acik",
    availabilityNote: cv?.availabilityNote ?? "",
    vehicleNote: cv?.vehicleNote ?? "",
    profilePublished: cv?.profilePublished ?? false,
  };
  const [form, setForm] = useState(initial);
  const [draft, setDraft] = useState(initial);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");
  const [archiveTarget, setArchiveTarget] = useState<CvItem | null>(null);
  const [filter, setFilter] = useState("hepsi");

  const dirty = JSON.stringify(form) !== JSON.stringify(draft);

  async function save() {
    setSaving(true);
    setError("");
    const res = await fetch(`/api/admin/cv/${courierId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    setSaving(false);
    if (!res.ok) {
      setError(data.error ?? "Kaydedilemedi.");
      return;
    }
    setDraft({ ...form });
    setSaved(true);
    router.refresh();
  }

  async function archiveItem(reason: string) {
    if (!archiveTarget) return;
    setSaving(true);
    const res = await fetch(`/api/admin/cv/${courierId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "archive", itemId: archiveTarget.id, reason }),
    });
    setSaving(false);
    setArchiveTarget(null);
    if (!res.ok) {
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      setError(data.error ?? "Arşivlenemedi.");
      return;
    }
    router.refresh();
  }

  const shown = filter === "hepsi" ? items : items.filter((item) => item.kind === filter);

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_0.75fr]">
      <div>
        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Profil başlığı</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="cv-display" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Görünen ad</label>
              <input id="cv-display" className="input-light mt-2" value={form.displayName} disabled={!canEdit} maxLength={80}
                onChange={(e) => setForm((f) => ({ ...f, displayName: e.target.value }))} />
              <p className="mt-1 text-[11px] text-slate-500">Müşteriye görünen ad. Soyad kısaltılabilir.</p>
            </div>
            <div>
              <label htmlFor="cv-photo" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Fotoğraf referansı</label>
              <input id="cv-photo" className="input-light mt-2" value={form.photoRef} disabled={!canEdit} maxLength={200}
                placeholder="dosya sağlayıcısı bağlı değil"
                onChange={(e) => setForm((f) => ({ ...f, photoRef: e.target.value }))} />
              <p className="mt-1 text-[11px] text-slate-500">
                Depolama sağlayıcısı bağlı olmadığı için yükleme yapılamaz; alan yalnızca referans tutar.
              </p>
            </div>
          </div>
          <div className="mt-4">
            <label htmlFor="cv-about" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Hakkında</label>
            <textarea id="cv-about" rows={4} className="input-light mt-2" value={form.about} disabled={!canEdit} maxLength={1200}
              onChange={(e) => setForm((f) => ({ ...f, about: e.target.value }))} />
            <p className="mt-1 text-[11px] text-slate-500">{form.about.length}/1200</p>
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="cv-avail" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Çalışma uygunluğu</label>
              <input id="cv-avail" className="input-light mt-2" value={form.availabilityNote} disabled={!canEdit} maxLength={300}
                onChange={(e) => setForm((f) => ({ ...f, availabilityNote: e.target.value }))} />
            </div>
            <div>
              <label htmlFor="cv-vehicle" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Araç bilgisi</label>
              <input id="cv-vehicle" className="input-light mt-2" value={form.vehicleNote} disabled={!canEdit} maxLength={300}
                onChange={(e) => setForm((f) => ({ ...f, vehicleNote: e.target.value }))} />
            </div>
          </div>
          <label className="mt-4 flex items-center gap-3 text-sm text-slate-700">
            <input type="checkbox" className="h-4 w-4 accent-[var(--accent)]" checked={form.profilePublished} disabled={!canEdit}
              onChange={(e) => setForm((f) => ({ ...f, profilePublished: e.target.checked }))} />
            Profili müşterilere görünebilir yap
          </label>
          <StickyFormBar dirty={dirty} saving={saving} saved={saved} error={error} onSave={save} onReset={() => setForm({ ...draft })} />
        </section>

        <section className="mt-5 rounded-lg border border-slate-200 bg-white p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">CV kalemleri</h2>
            <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input-light w-48 py-1.5 text-xs" aria-label="Tür filtresi">
              <option value="hepsi">Tüm bölümler</option>
              {KINDS.map((kind) => (
                <option key={kind.value} value={kind.value}>{kind.label}</option>
              ))}
            </select>
          </div>
          <ul className="mt-4 divide-y divide-slate-100">
            {shown.map((item) => (
              <li key={item.id} className="flex flex-wrap items-start justify-between gap-3 py-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-[#0B1220]">
                    {item.title}
                    <span className="ml-2 text-[11px] text-slate-500">
                      {KINDS.find((k) => k.value === item.kind)?.label ?? item.kind}
                    </span>
                  </p>
                  {item.org ? <p className="text-xs text-slate-600">{item.org}</p> : null}
                  {(item.startsAt || item.endsAt) ? (
                    <p className="text-xs text-slate-500">{item.startsAt} — {item.endsAt || "devam ediyor"}</p>
                  ) : null}
                  {item.description ? <p className="mt-1 text-xs text-slate-600">{item.description}</p> : null}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] text-slate-600">
                    {VISIBILITY.find((v) => v.value === item.visibility)?.label ?? item.visibility}
                  </span>
                  {canEdit ? (
                    <Tooltip label="Kalıcı silme yok: kalem arşivlenir ve gerekçe kaydedilir">
                      <button
                        type="button"
                        onClick={() => setArchiveTarget(item)}
                        className="min-h-11 rounded-md border border-red-300 px-3 text-xs font-semibold text-red-700 transition hover:bg-red-50"
                      >
                        Arşivle
                      </button>
                    </Tooltip>
                  ) : null}
                </div>
              </li>
            ))}
            {shown.length === 0 ? <li className="py-6 text-sm text-slate-500">Bu bölümde kalem yok.</li> : null}
          </ul>
          <p className="mt-4 text-[11px] text-slate-500">
            Kalem ekleme/düzenleme API üzerinden yapılır: <code>POST /api/admin/cv/{courierId}</code>. Örnek CV
            verilmediği için TC kimlik, belge numarası ve ev adresi gibi hassas alanlar bu forma EKLENMEDİ.
          </p>
        </section>
      </div>

      <aside className="space-y-4">
        <div className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Görünürlük sınıfları</h2>
          <ul className="mt-3 space-y-3 text-sm">
            {VISIBILITY.map((level) => (
              <li key={level.value}>
                <p className="font-medium text-[#0B1220]">{level.label}</p>
                <p className="text-xs text-slate-500">{level.hint}</p>
              </li>
            ))}
          </ul>
          <div className="mt-4 border-t border-slate-100 pt-3">
            <label htmlFor="cv-default-vis" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">Varsayılan görünürlük</label>
            <select id="cv-default-vis" className="input-light mt-2" value={form.defaultVisibility} disabled={!canEdit}
              onChange={(e) => setForm((f) => ({ ...f, defaultVisibility: e.target.value }))}>
              {VISIBILITY.map((level) => (
                <option key={level.value} value={level.value}>{level.label}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-5 text-sm text-slate-600">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Bölüm sayıları</h2>
          <ul className="mt-3 space-y-1">
            {KINDS.map((kind) => (
              <li key={kind.value} className="flex justify-between">
                <span>{kind.label}</span>
                <span className="font-semibold text-[#0B1220]">{items.filter((i) => i.kind === kind.value).length}</span>
              </li>
            ))}
          </ul>
        </div>
      </aside>

      <ConfirmDialog
        open={archiveTarget !== null}
        title="CV kalemini arşivle"
        body={`"${archiveTarget?.title ?? ""}" arşivlenecek. Kalıcı silme yapılmaz; kalem listelerde görünmez ama kayıt saklanır.`}
        confirmLabel="Arşivle"
        tone="danger"
        requireReason
        busy={saving}
        onConfirm={archiveItem}
        onCancel={() => setArchiveTarget(null)}
      />
    </div>
  );
}
