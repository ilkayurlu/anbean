"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export type TrustedContact = { id: number; name: string; phoneMasked: string; createdAt: Date | string };

/** Güvenilen kişiler. Telefon düz metin gösterilmez, yalnızca maske. */
export default function TrustedContactsManager({ contacts }: { contacts: TrustedContact[] }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const res = await fetch("/api/trusted-contacts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone }),
    });
    const data = (await res.json().catch(() => ({}))) as { error?: string };
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Kişi eklenemedi.");
      return;
    }
    setName("");
    setPhone("");
    router.refresh();
  }

  async function remove(id: number) {
    setError("");
    await fetch(`/api/trusted-contacts?id=${id}`, { method: "DELETE" });
    router.refresh();
  }

  return (
    <div className="space-y-5">
      <form onSubmit={add} className="rounded-lg border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Kişi ekle</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="tc-name" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
              Ad
            </label>
            <input id="tc-name" value={name} onChange={(e) => setName(e.target.value)} className="input-light mt-2" required minLength={2} />
          </div>
          <div>
            <label htmlFor="tc-phone" className="text-[11px] uppercase tracking-[0.12em] text-slate-500">
              Telefon
            </label>
            <input id="tc-phone" value={phone} onChange={(e) => setPhone(e.target.value)} className="input-light mt-2" inputMode="tel" required />
          </div>
        </div>
        {error ? (
          <p role="alert" className="mt-3 text-sm text-st-risk">
            {error}
          </p>
        ) : null}
        <button type="submit" disabled={busy} className="mt-4 rounded-md bg-accent px-5 py-2.5 text-sm font-semibold text-[#0B1220] disabled:opacity-60">
          {busy ? "Ekleniyor…" : "Ekle"}
        </button>
        <p className="mt-3 text-[11px] text-slate-500">
          En fazla 5 kişi. Telefon numarası düz metin saklanmaz; yalnızca özeti ve maskesi tutulur.
        </p>
      </form>

      <div className="rounded-lg border border-slate-200 bg-white p-5">
        <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Kayıtlı kişiler</h2>
        {contacts.length === 0 ? (
          <p className="py-6 text-center text-sm text-slate-500">Henüz güvenilen kişi eklemedin.</p>
        ) : (
          <ul className="mt-3 divide-y divide-slate-100 text-sm">
            {contacts.map((contact) => (
              <li key={contact.id} className="flex items-center justify-between py-3">
                <div>
                  <p className="font-medium text-slate-800">{contact.name}</p>
                  <p className="font-mono text-xs text-slate-500">{contact.phoneMasked}</p>
                </div>
                <button type="button" onClick={() => remove(contact.id)} className="rounded-md border border-st-risk/40 px-3 py-1.5 text-xs text-st-risk">
                  Sil
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
