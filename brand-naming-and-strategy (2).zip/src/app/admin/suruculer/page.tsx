import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chauffeurApplications, chauffeurDocuments, chauffeurProfiles, chauffeurVehicles } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { REQUIRED_COMMERCIAL_DOCS } from "@/lib/hail";
import PanelShell, { Card, Metric } from "@/components/PanelShell";
import DocumentVerify from "@/components/DocumentVerify";
import { STATUS_COLOR } from "@/lib/status";
import { nowMillis } from "@/lib/clock";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sürücüler — Anbean" };

const AVAILABILITY_LABEL: Record<string, string> = {
  offline: "Çevrimdışı",
  online_idle: "Çevrimiçi · boşta",
  on_trip: "Yolculukta",
};

export default async function AdminSuruculerPage() {
  const user = await requirePermission("chauffeur:verify");
  if (!user) redirect("/giris");

  const [profiles, documents, vehicles, applications] = await Promise.all([
    db.select().from(chauffeurProfiles).orderBy(desc(chauffeurProfiles.createdAt)).limit(100),
    db.select().from(chauffeurDocuments),
    db.select().from(chauffeurVehicles),
    db.select().from(chauffeurApplications).orderBy(desc(chauffeurApplications.createdAt)).limit(20),
  ]);

  const verified = profiles.filter((p) => p.isVerified && p.commercialDocsVerified).length;
  const online = profiles.filter((p) => p.availability !== "offline").length;
  const suspended = profiles.filter((p) => p.suspendedUntil && p.suspendedUntil.getTime() > nowMillis()).length;

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Sürücüler"
      subtitle="Belge doğrulama, çevrimiçi durum ve askıya almalar. Her işlem denetim kaydına yazılır."
      nav={[
        { href: "/admin", label: "Yönetim" },
        { href: "/admin/suruculer", label: "Sürücüler" },
        { href: "/ops/guvenlik-olaylari", label: "Güvenlik" },
        { href: "/admin/finans", label: "Finans" },
      ]}
    >
      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="Sürücü" value={String(profiles.length)} />
        <Metric label="Doğrulanmış" value={String(verified)} tone={STATUS_COLOR.delivered} />
        <Metric label="Çevrimiçi" value={String(online)} tone={STATUS_COLOR.transit} />
        <Metric label="Askıda" value={String(suspended)} tone={STATUS_COLOR.risk} />
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Card title="Sürücü kayıtları">
          <ul className="divide-y divide-slate-100">
            {profiles.map((profile) => {
              const docs = documents.filter((d) => d.chauffeurId === profile.id);
              const approvedCount = (REQUIRED_COMMERCIAL_DOCS as readonly string[]).filter((type) =>
                docs.some((d) => d.docType === type && d.status === "approved"),
              ).length;
              const plates = vehicles.filter((v) => v.chauffeurId === profile.id).map((v) => v.plate);
              const suspended = profile.suspendedUntil !== null && profile.suspendedUntil.getTime() > nowMillis();
              return (
                <li key={profile.id} className="py-4">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="font-display text-sm font-bold text-[#0B1220]">
                        {profile.fullName}
                        {profile.isDemo ? <span className="ml-2 text-[11px] font-normal text-slate-500">demo</span> : null}
                      </p>
                      <p className="text-xs text-slate-500">
                        {profile.city} · {AVAILABILITY_LABEL[profile.availability] ?? profile.availability} ·{" "}
                        {profile.status}
                      </p>
                      <p className="mt-1 text-xs text-slate-500">
                        belge {approvedCount}/{REQUIRED_COMMERCIAL_DOCS.length} · yolculuk {profile.totalTrips} · puan{" "}
                        {profile.ratingCount > 0 ? (profile.ratingSum / profile.ratingCount).toFixed(1) : "—"}
                      </p>
                      {suspended ? (
                        <p className="mt-1 text-xs font-semibold text-st-risk">
                          Askıda: {profile.suspensionReason} ({new Date(profile.suspendedUntil!).toLocaleString("tr-TR")} kadar)
                        </p>
                      ) : null}
                    </div>
                    <span
                      className="rounded-full px-2.5 py-1 text-[11px] font-semibold"
                      style={{
                        color: profile.commercialDocsVerified ? STATUS_COLOR.delivered : STATUS_COLOR.waiting,
                        backgroundColor: `${profile.commercialDocsVerified ? STATUS_COLOR.delivered : STATUS_COLOR.waiting}1f`,
                      }}
                    >
                      {profile.commercialDocsVerified ? "ticari doğrulandı" : "doğrulanmadı"}
                    </span>
                  </div>
                  <DocumentVerify
                    chauffeurId={profile.id}
                    documents={docs.map((d) => ({ docType: d.docType, status: d.status }))}
                    plates={plates}
                  />
                </li>
              );
            })}
            {profiles.length === 0 ? <li className="py-8 text-sm text-slate-500">Sürücü kaydı yok.</li> : null}
          </ul>
        </Card>

        <Card title="Başvurular">
          {applications.length === 0 ? (
            <p className="py-6 text-sm text-slate-500">Başvuru yok.</p>
          ) : (
            <ul className="divide-y divide-slate-100 text-sm">
              {applications.map((application) => (
                <li key={application.id} className="py-3">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="font-medium text-slate-800">{application.fullName}</p>
                      <p className="text-xs text-slate-500">
                        {application.city} · {application.vehicleType} · {application.ownership} ·{" "}
                        {application.experienceYears} yıl
                      </p>
                      <p className="text-xs text-slate-500">
                        telefon: <span className="font-mono">{application.phoneMasked}</span>
                      </p>
                    </div>
                    <span className="shrink-0 rounded-full bg-slate-100 px-2.5 py-1 text-[11px] text-slate-600">
                      {application.status}
                    </span>
                  </div>
                  <p className="mt-1.5 text-[11px] text-slate-500">
                    ticari belge beyanı: {application.hasCommercialLicense ? "var" : "yok"}
                  </p>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <p className="mt-6 text-xs text-slate-500">
        Rol yükseltmesi yalnızca belge onayından sonra, sunucu tarafında yapılır. Kullanıcı kendi rolünü
        değiştiremez; her yükseltme denetim kaydına yazılır.
      </p>
    </PanelShell>
  );
}
