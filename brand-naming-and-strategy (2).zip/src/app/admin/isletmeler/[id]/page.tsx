import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { invoices, orgMembers, organizations, plans, shipments, subscriptions, users } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import { nowMillis } from "@/lib/clock";
import PanelShell from "@/components/PanelShell";
import OrgPanel from "@/components/admin/OrgPanel";
import { ADMIN_NAV } from "../../uyeler/page";

export const dynamic = "force-dynamic";

export default async function IsletmeDetayPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await requirePermission("org:read");
  if (!session) redirect("/giris");

  const id = Number((await params).id);
  if (!Number.isFinite(id)) notFound();

  const [org] = await db.select().from(organizations).where(eq(organizations.id, id)).limit(1);
  if (!org || org.archivedAt) notFound();

  if ((session.role === "isletme_sahibi" || session.role === "isletme_calisani") && session.orgId !== org.id) {
    redirect("/admin/isletmeler");
  }

  const [memberRows, subscriptionRows, invoiceRows, planRows, orgUsers] = await Promise.all([
    db.select().from(orgMembers).where(eq(orgMembers.orgId, id)),
    db.select().from(subscriptions).where(eq(subscriptions.orgId, id)).orderBy(desc(subscriptions.createdAt)).limit(1),
    db.select().from(invoices).where(eq(invoices.orgId, id)).orderBy(desc(invoices.createdAt)).limit(20),
    db.select().from(plans),
    db.select().from(users).where(eq(users.orgId, id)),
  ]);

  const subscription = subscriptionRows[0] ?? null;
  const plan = subscription ? (planRows.find((p) => p.id === subscription.planId) ?? null) : null;
  const periodStart = subscription?.currentPeriodEnd
    ? new Date(new Date(subscription.currentPeriodEnd).getTime() - 30 * 86_400_000)
    : new Date(nowMillis() - 30 * 86_400_000);
  const orgShipments = await db.select({ createdAt: shipments.createdAt }).from(shipments).where(eq(shipments.orgId, id));
  const usedShipments = orgShipments.filter((row) => row.createdAt >= periodStart).length;

  return (
    <PanelShell
      role={session.role}
      userName={session.fullName}
      title={org.name}
      subtitle={`${org.type}${org.category ? ` · ${org.category}` : ""} · ${org.city || "şehir belirtilmemiş"}`}
      nav={ADMIN_NAV}
    >
      <p className="mb-4 text-xs text-slate-500">
        <Link href="/admin/isletmeler" className="text-accent underline-offset-4 hover:underline">
          ← İşletmeler
        </Link>
      </p>

      <OrgPanel
        org={{
          id: org.id,
          name: org.name,
          slug: org.slug,
          type: org.type,
          category: org.category,
          description: org.description,
          contactEmail: org.contactEmail,
          contactPhone: org.contactPhone,
          city: org.city,
          district: org.district,
          verificationStatus: org.verificationStatus,
          archivedAt: org.archivedAt,
        }}
        members={memberRows.map((m) => {
          const account = orgUsers.find((u) => u.id === m.userId);
          return {
            id: m.id,
            userId: m.userId,
            orgRole: m.orgRole,
            fullName: account?.fullName ?? "—",
            email: account ? `${account.email.slice(0, 2)}***@${account.email.split("@")[1] ?? ""}` : "",
            isActive: m.isActive,
          };
        })}
        subscription={subscription ? { ...subscription, plan } : null}
        usage={{
          shipmentsUsed: usedShipments,
          shipmentLimit: plan?.shipmentLimit ?? null,
          seatsUsed: orgUsers.length,
          seatLimit: plan?.seatLimit ?? null,
          overLimit: plan ? usedShipments > plan.shipmentLimit : false,
        }}
        invoices={invoiceRows}
        plans={planRows.map((p) => ({ code: p.code, name: p.name, monthlyKurus: p.monthlyKurus, shipmentLimit: p.shipmentLimit, seatLimit: p.seatLimit }))}
        canManage={hasPermission(session.role, "org:manage")}
        canSeeVerification={session.role === "admin" || session.role === "super_admin" || session.role === "ops"}
      />
    </PanelShell>
  );
}
