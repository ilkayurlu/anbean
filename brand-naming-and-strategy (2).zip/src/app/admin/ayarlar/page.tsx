import { redirect } from "next/navigation";
import { db } from "@/db";
import { emailTemplates, platformSettings, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requireAuth } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import PanelShell, { Card, Metric } from "@/components/PanelShell";
import SettingsPanel from "@/components/admin/SettingsPanel";
import { ADMIN_NAV } from "../uyeler/page";

export const dynamic = "force-dynamic";
export const metadata = { title: "Ayarlar — Anbean Yönetim" };

export default async function AyarlarPage() {
  const user = await requireAuth();
  if (!user) redirect("/giris");
  // Ayarlar ekranı herkese açık değil: en az settings:read gerekir.
  if (!hasPermission(user.role, "settings:read") && user.role !== "admin" && user.role !== "super_admin") {
    redirect("/giris");
  }

  const [settings, templates, me] = await Promise.all([
    db.select().from(platformSettings),
    db.select().from(emailTemplates),
    db.select().from(users).where(eq(users.id, user.id)).limit(1),
  ]);

  const canManage = hasPermission(user.role, "settings:manage") || user.role === "admin" || user.role === "super_admin";

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Ayarlar ve güvenlik"
      subtitle="Platform ayarları, bildirim şablonları ve iki aşamalı doğrulama. Gizli anahtarlar bu ekranda tutulmaz."
      nav={ADMIN_NAV}
    >
      <div className="grid gap-4 sm:grid-cols-3">
        <Metric label="Ayar anahtarı" value={String(settings.length)} />
        <Metric label="Bildirim şablonu" value={String(templates.length)} />
        <Metric
          label="Hesabında MFA"
          value={me[0]?.totpEnabled ? "etkin" : "kapalı"}
          tone={me[0]?.totpEnabled ? "#16A34A" : "#F59E0B"}
        />
      </div>

      <div className="mt-6">
        <SettingsPanel
          settings={settings}
          templates={templates}
          mfaEnabled={Boolean(me[0]?.totpEnabled)}
          canManage={canManage}
        />
      </div>

      <div className="mt-6">
        <Card title="Güvenlik notları">
          <ul className="space-y-2 text-sm text-slate-600">
            <li>· Parolalar scrypt ile hash&apos;lenir; yönetici parolayı göremez, yalnızca sıfırlama başlatabilir.</li>
            <li>· MFA sırrı kurulumda bir kez gösterilir, sonrasında hiçbir listede yer almaz.</li>
            <li>· Denetim kaydına gerekçe, eski/yeni değer, IP ve ajan yazılır; parola ve anahtarlar otomatik maskelenir.</li>
            <li>· Silme yerine arşivleme vardır; kalıcı silme arayüzden sunulmaz.</li>
            <li>· API anahtarları ortam değişkeninde kalır, veritabanına yazılmaz.</li>
          </ul>
        </Card>
      </div>
    </PanelShell>
  );
}
