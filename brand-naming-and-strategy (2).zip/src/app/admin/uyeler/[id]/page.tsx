import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { desc, eq, or } from "drizzle-orm";
import { db } from "@/db";
import { adminNotes, auditLog, couriers, orders, shipments, supportTickets, users } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import { ROLE_LABEL, type Role } from "@/lib/auth";
import PanelShell from "@/components/PanelShell";
import MemberProfile from "@/components/admin/MemberProfile";
import { ADMIN_NAV } from "../page";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return { title: `Üye #${id} — Anbean Yönetim` };
}

export default async function UyeDetayPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await requirePermission("member:read");
  if (!session) redirect("/giris");

  const id = Number((await params).id);
  if (!Number.isFinite(id)) notFound();

  const [member] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!member) notFound();

  // Tenant izolasyonu: işletme rolü kendi üyesi dışında kimseyi açamaz.
  if ((session.role === "isletme_sahibi" || session.role === "isletme_calisani") && member.orgId !== session.orgId && member.id !== session.id) {
    redirect("/admin/uyeler");
  }

  const [courier] = await db.select().from(couriers).where(eq(couriers.userId, id)).limit(1);
  const [notes, logs, tickets, shipmentRows, orderRows] = await Promise.all([
    db.select().from(adminNotes).where(eq(adminNotes.entityId, id)).orderBy(desc(adminNotes.createdAt)).limit(50),
    db.select().from(auditLog).where(eq(auditLog.actorId, id)).orderBy(desc(auditLog.createdAt)).limit(30),
    db.select().from(supportTickets).where(eq(supportTickets.userId, id)).orderBy(desc(supportTickets.createdAt)).limit(20),
    db
      .select()
      .from(shipments)
      .where(or(eq(shipments.createdByUserId, id), eq(shipments.assignedCourierId, courier?.id ?? -1)))
      .orderBy(desc(shipments.createdAt))
      .limit(20),
    db.select().from(orders).where(eq(orders.userId, id)).orderBy(desc(orders.createdAt)).limit(20),
  ]);

  const canSensitive = hasPermission(session.role, "member:sensitive");

  return (
    <PanelShell
      role={session.role}
      userName={session.fullName}
      title={member.fullName}
      subtitle={`${ROLE_LABEL[member.role as Role] ?? member.role} · ${
        member.archivedAt ? "arşivde" : member.isBanned ? "banlı" : member.isActive ? "aktif" : "pasif"
      } · kayıt ${new Date(member.createdAt).toLocaleDateString("tr-TR")}`}
      nav={ADMIN_NAV}
    >
      <p className="mb-4 text-xs text-slate-500">
        <Link href="/admin/uyeler" className="text-accent underline-offset-4 hover:underline">
          ← Üye listesi
        </Link>
        {canSensitive ? "" : " · iletişim bilgileri maskeli (hassas alan iznin yok)"}
      </p>

      <MemberProfile
        member={{
          id: member.id,
          fullName: member.fullName,
          email: canSensitive ? member.email : `${member.email.slice(0, 2)}***@${member.email.split("@")[1] ?? ""}`,
          phone: canSensitive ? (member.phone ?? "") : (member.phone ?? "").replace(/\D/g, "").slice(0, 3) + "*****",
          role: member.role,
          roleLabel: ROLE_LABEL[member.role as Role] ?? member.role,
          permissions: 0,
          orgId: member.orgId,
          isActive: member.isActive,
          isBanned: member.isBanned,
          archived: member.archivedAt !== null,
          mustChangePassword: member.mustChangePassword,
          mfaEnabled: member.totpEnabled,
          marketingConsent: member.marketingConsent,
          kvkkConsentAt: member.kvkkConsentAt,
          lastLoginAt: member.lastLoginAt,
          createdAt: member.createdAt,
        }}
        canManage={hasPermission(session.role, "member:manage")}
        canSensitive={canSensitive}
        canResetPassword={hasPermission(session.role, "member:reset_password")}
        notes={notes}
        audit={logs}
        tickets={tickets}
        shipments={shipmentRows}
        orders={orderRows}
        courier={courier ? { id: courier.id, status: courier.status, city: courier.city, vehicle: courier.vehicle } : null}
        courierId={courier?.id ?? null}
      />
    </PanelShell>
  );
}
