import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, isNull } from "drizzle-orm";
import { db } from "@/db";
import { couriers, organizations, users } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { hasPermission, ROLE_PERMISSIONS } from "@/lib/permissions";
import { ROLE_LABEL, type Role } from "@/lib/auth";
import PanelShell, { Metric } from "@/components/PanelShell";
import MembersTable, { type MemberRow } from "@/components/admin/MembersTable";

export const dynamic = "force-dynamic";
export const metadata = { title: "Üyeler — Anbean Yönetim" };

export const ADMIN_NAV = [
  { href: "/admin", label: "Özet" },
  { href: "/admin/uyeler", label: "Üyeler" },
  { href: "/admin/isletmeler", label: "İşletmeler" },
  { href: "/admin/suruculer", label: "Sürücüler" },
  { href: "/admin/cms", label: "İçerik" },
  { href: "/admin/finans", label: "Finans" },
  { href: "/admin/destek", label: "Destek" },
  { href: "/admin/ayarlar", label: "Ayarlar" },
];

function maskEmail(value: string) {
  const [name, domain] = value.split("@");
  return `${name?.slice(0, 2) ?? ""}***@${domain ?? ""}`;
}

function maskPhone(value: string | null) {
  const digits = (value ?? "").replace(/\D/g, "");
  return digits.length < 6 ? "" : `${digits.slice(0, 3)}*****`;
}

export default async function UyelerPage() {
  const user = await requirePermission("member:read");
  if (!user) redirect("/giris");

  const canSensitive = hasPermission(user.role, "member:sensitive");
  const canExport = hasPermission(user.role, "member:export");
  const scoped = user.role === "isletme_sahibi" || user.role === "isletme_calisani";

  const [allUsers, orgRows, courierRows] = await Promise.all([
    db.select().from(users).orderBy(desc(users.createdAt)).limit(2000),
    db.select().from(organizations),
    db.select().from(couriers),
  ]);

  const orgById = new Map(orgRows.map((o) => [o.id, o.name]));
  const courierByUser = new Map(courierRows.map((c) => [c.userId, c]));

  // Tenant izolasyonu: işletme rolü yalnızca kendi üyelerini görür.
  const visible = scoped
    ? allUsers.filter((row) => row.orgId === user.orgId || row.id === user.id)
    : allUsers;

  const rows: MemberRow[] = visible.map((row) => {
    const courier = courierByUser.get(row.id);
    return {
      id: row.id,
      fullName: row.fullName,
      email: canSensitive ? row.email : maskEmail(row.email),
      phone: canSensitive ? (row.phone ?? "") : maskPhone(row.phone),
      role: row.role,
      roleLabel: ROLE_LABEL[row.role as Role] ?? row.role,
      orgName: row.orgId ? (orgById.get(row.orgId) ?? "") : "",
      isActive: row.isActive,
      isBanned: row.isBanned,
      archived: row.archivedAt !== null,
      mfaEnabled: row.totpEnabled,
      mustChangePassword: row.mustChangePassword,
      verified: row.kvkkConsentAt !== null,
      lastLoginAt: row.lastLoginAt,
      createdAt: row.createdAt,
      courierStatus: courier?.status ?? null,
      courierCity: courier?.city ?? null,
    };
  });

  const active = rows.filter((r) => r.isActive && !r.isBanned && !r.archived).length;
  const banned = rows.filter((r) => r.isBanned).length;
  const archived = rows.filter((r) => r.archived).length;
  const mfaOn = rows.filter((r) => r.mfaEnabled).length;

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Üye yönetimi"
      subtitle={
        scoped
          ? "Yalnızca kendi işletmenin üyeleri listelenir (sunucu tarafı tenant filtresi)."
          : "Arama, sıralama ve sayfalama istemcide; yetki ve tenant filtreleri sunucuda uygulanır."
      }
      nav={ADMIN_NAV}
    >
      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="Görünen üye" value={String(rows.length)} />
        <Metric label="Aktif" value={String(active)} tone="#16A34A" />
        <Metric label="Banlı / arşiv" value={`${banned} / ${archived}`} tone="#DC2626" />
        <Metric label="MFA etkin" value={String(mfaOn)} tone="#2563EB" />
      </div>

      <div className="mt-6 rounded-lg border border-slate-200 bg-white p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Üyeler</h2>
          <p className="text-xs text-slate-500">
            İzin sayın: {ROLE_PERMISSIONS[user.role]?.length ?? 0} · hassas alan: {canSensitive ? "açık" : "kapalı"}
          </p>
        </div>
        <MembersTable rows={rows} canExport={canExport} canSeeSensitive={canSensitive} />
      </div>

      <p className="mt-4 text-xs text-slate-500">
        Parola, erişim kodu ve MFA sırrı hiçbir yanıtta dönmez. Kalıcı silme yoktur; arşivleme kullanılır. Bir üyeyi
        açmak için satıra tıkla: <Link href="/admin/uyeler" className="text-accent">profil sekmeleri</Link>.
      </p>
    </PanelShell>
  );
}

