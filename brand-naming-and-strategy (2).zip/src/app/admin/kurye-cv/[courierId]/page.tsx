import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { and, asc, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { courierCv, courierCvItems, couriers } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import PanelShell from "@/components/PanelShell";
import CvEditor, { type CvItem } from "@/components/admin/CvEditor";
import { ADMIN_NAV } from "../../uyeler/page";

export const dynamic = "force-dynamic";

export default async function KuryeCvPage({ params }: { params: Promise<{ courierId: string }> }) {
  const user = await requirePermission("cv:read");
  if (!user) redirect("/giris");

  const courierId = Number((await params).courierId);
  if (!Number.isFinite(courierId)) notFound();

  const [courier] = await db.select().from(couriers).where(eq(couriers.id, courierId)).limit(1);
  if (!courier) notFound();

  const canSensitive = hasPermission(user.role, "member:sensitive");
  const [cv] = await db.select().from(courierCv).where(eq(courierCv.courierId, courierId)).limit(1);
  const items = cv
    ? await db
        .select()
        .from(courierCvItems)
        .where(and(eq(courierCvItems.cvId, cv.id), isNull(courierCvItems.archivedAt)))
        .orderBy(asc(courierCvItems.sortIndex))
    : [];

  // Gizli görünürlüklü kalemler yalnızca hassas alan izni olan role gösterilir.
  const visibleItems = canSensitive ? items : items.filter((item) => item.visibility !== "gizli");

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title={`CV · ${courier.fullName}`}
      subtitle={`${courier.city} · ${courier.vehicle} · ${courier.status}`}
      nav={ADMIN_NAV}
    >
      <p className="mb-4 text-xs text-slate-500">
        <Link href={courier.userId ? `/admin/uyeler/${courier.userId}` : "/admin/uyeler"} className="text-accent underline-offset-4 hover:underline">
          ← Üye profili
        </Link>
        {canSensitive ? "" : " · gizli işaretli kalemler sana gösterilmiyor"}
      </p>

      <CvEditor
        courierId={courierId}
        courierName={courier.fullName}
        cv={
          cv
            ? {
                displayName: cv.displayName,
                about: cv.about,
                photoRef: cv.photoRef,
                defaultVisibility: cv.defaultVisibility,
                availabilityNote: cv.availabilityNote,
                vehicleNote: cv.vehicleNote,
                profilePublished: cv.profilePublished,
              }
            : null
        }
        items={visibleItems as CvItem[]}
        canEdit={hasPermission(user.role, "cv:manage")}
      />
    </PanelShell>
  );
}
