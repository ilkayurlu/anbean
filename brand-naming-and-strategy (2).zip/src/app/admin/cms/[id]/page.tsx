import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { cmsPages, cmsVersions } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import PanelShell from "@/components/PanelShell";
import CmsEditor from "@/components/admin/CmsEditor";
import { ADMIN_NAV } from "../../uyeler/page";

export const dynamic = "force-dynamic";

export default async function CmsSayfaPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("cms:read");
  if (!user) redirect("/giris");

  const id = Number((await params).id);
  if (!Number.isFinite(id)) notFound();

  const [page] = await db.select().from(cmsPages).where(eq(cmsPages.id, id)).limit(1);
  if (!page) notFound();

  const versions = await db
    .select()
    .from(cmsVersions)
    .where(eq(cmsVersions.pageId, id))
    .orderBy(desc(cmsVersions.version));

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title={page.title}
      subtitle={`/${page.slug} · sürüm ${page.version} · ${versions.length} kayıtlı sürüm`}
      nav={ADMIN_NAV}
    >
      <p className="mb-4 text-xs text-slate-500">
        <Link href="/admin/cms" className="text-accent underline-offset-4 hover:underline">
          ← İçerik listesi
        </Link>
      </p>
      <CmsEditor
        page={page}
        versions={versions}
        canPublish={hasPermission(user.role, "cms:publish")}
        canRestore={hasPermission(user.role, "cms:restore")}
      />
    </PanelShell>
  );
}
