import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, isNull } from "drizzle-orm";
import { db } from "@/db";
import { blogPosts, cmsPages, cmsVersions } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import PanelShell, { Metric } from "@/components/PanelShell";
import { ADMIN_NAV } from "../uyeler/page";

export const dynamic = "force-dynamic";
export const metadata = { title: "İçerik — Anbean Yönetim" };

const STATUS_LABEL: Record<string, string> = {
  taslak: "Taslak",
  incelemede: "İncelemede",
  yayinda: "Yayında",
  arsiv: "Arşiv",
};

function tone(status: string) {
  if (status === "yayinda") return { color: "#15803d", bg: "#dcfce7" };
  if (status === "taslak") return { color: "#B45309", bg: "#fef3c7" };
  return { color: "#334155", bg: "#e2e8f0" };
}

export default async function CmsPage() {
  const user = await requirePermission("cms:read");
  if (!user) redirect("/giris");

  const [pages, versions, posts] = await Promise.all([
    db.select().from(cmsPages).where(isNull(cmsPages.archivedAt)).orderBy(desc(cmsPages.updatedAt)),
    db.select().from(cmsVersions),
    db.select().from(blogPosts).orderBy(desc(blogPosts.updatedAt)).limit(50),
  ]);

  const latestVersion = new Map<number, number>();
  for (const version of versions) {
    latestVersion.set(version.pageId, Math.max(latestVersion.get(version.pageId) ?? 0, version.version));
  }

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="İçerik yönetimi"
      subtitle="Sayfalar ve blog. Her kayıt sürümlenir; yayınlanmış içerik değiştiğinde önceki sürüm saklanır."
      nav={ADMIN_NAV}
    >
      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="Sayfa" value={String(pages.length)} />
        <Metric label="Yayında" value={String(pages.filter((p) => p.status === "yayinda").length)} tone="#16A34A" />
        <Metric label="Blog yazısı" value={String(posts.length)} />
        <Metric label="Taslak" value={String(posts.filter((p) => p.status === "taslak").length + pages.filter((p) => p.status === "taslak").length)} tone="#F59E0B" />
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Sayfalar</h2>
            <span className="text-xs text-slate-500">yeni sayfa: POST /api/admin/cms</span>
          </div>
          <ul className="mt-3 divide-y divide-slate-100">
            {pages.map((page) => {
              const t = tone(page.status);
              return (
                <li key={page.id} className="py-3">
                  <div className="flex items-center justify-between gap-3">
                    <Link href={`/admin/cms/${page.id}`} className="min-w-0">
                      <p className="truncate font-medium text-[#0B1220] hover:text-accent">{page.title}</p>
                      <p className="font-mono text-xs text-slate-500">/{page.slug}</p>
                    </Link>
                    <div className="flex shrink-0 items-center gap-2">
                      <span className="text-[11px] text-slate-500">
                        v{latestVersion.get(page.id) ?? page.version}
                      </span>
                      <span className="rounded-full px-2.5 py-1 text-[11px] font-semibold" style={{ color: t.color, backgroundColor: t.bg }}>
                        {STATUS_LABEL[page.status] ?? page.status}
                      </span>
                    </div>
                  </div>
                  {page.scheduledFor ? (
                    <p className="mt-1 text-[11px] text-amber-700">
                      zamanlandı: {new Date(page.scheduledFor).toLocaleString("tr-TR")}
                    </p>
                  ) : null}
                </li>
              );
            })}
            {pages.length === 0 ? <li className="py-6 text-sm text-slate-500">Sayfa yok.</li> : null}
          </ul>
        </section>

        <section className="rounded-lg border border-slate-200 bg-white p-5">
          <h2 className="text-sm font-semibold uppercase tracking-[0.1em] text-slate-500">Blog</h2>
          <ul className="mt-3 divide-y divide-slate-100">
            {posts.map((post) => {
              const t = tone(post.status);
              return (
                <li key={post.id} className="py-3">
                  <div className="flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate font-medium text-[#0B1220]">{post.title}</p>
                      <p className="font-mono text-xs text-slate-500">/blog/{post.slug}</p>
                    </div>
                    <span className="shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold" style={{ color: t.color, backgroundColor: t.bg }}>
                      {STATUS_LABEL[post.status] ?? post.status}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-slate-500">
                    {post.category} · {new Date(post.updatedAt).toLocaleDateString("tr-TR")}
                  </p>
                </li>
              );
            })}
            {posts.length === 0 ? <li className="py-6 text-sm text-slate-500">Blog yazısı yok.</li> : null}
          </ul>
          <p className="mt-3 text-[11px] text-slate-500">
            Blog düzenleme uç noktası bu sürümde bağlanmadı; içerik seed ile oluşturuluyor. İşlevsiz buton
            bırakmamak için düzenleme düğmesi eklenmedi.
          </p>
        </section>
      </div>
    </PanelShell>
  );
}
