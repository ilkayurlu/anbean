import Link from "next/link";
import { db } from "@/db";
import { chauffeurProfiles, iotVehicles } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import PageShell from "@/components/PageShell";
import Reveal from "@/components/Reveal";
import { CHAUFFEUR_SERVICE_GATE } from "@/lib/hail";
import { formatTry } from "@/lib/pricing";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Yolculuk — Anbean",
  description:
    "İki yolculuk seçeneği: elektrikli araç kirala (kullanıma açık) veya sürücülü yolculuk çağır (pilot, hukuk onayı bekliyor).",
};

export default async function YolculukPage() {
  const [vehicles, drivers] = await Promise.all([
    db.select().from(iotVehicles).catch(() => []),
    db
      .select()
      .from(chauffeurProfiles)
      .where(and(eq(chauffeurProfiles.commercialDocsVerified, true), eq(chauffeurProfiles.availability, "online_idle")))
      .catch(() => []),
  ]);

  const readyVehicles = vehicles.filter((v) => v.status === "available" && v.batteryPercent >= 20);
  const minVehiclePrice = readyVehicles.length ? Math.min(...readyVehicles.map((v) => v.perMinuteKurus)) : null;

  return (
    <PageShell
      eyebrow="Yolculuk"
      title="Nereye gidiyorsun?"
      lead="İki seçenek var: aracı kendin kullan ya da sürücülü yolculuk çağır. İkisi de tek hesap ve tek bakiye ile."
    >
      <div className="grid gap-5 lg:grid-cols-[1.2fr_1fr]">
        <Reveal>
          <Link
            href="/yolculuk/kiralik"
            className="block h-full rounded-lg border border-sur/35 bg-sur/8 p-8 transition hover:border-sur/60"
          >
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="font-display text-2xl font-bold text-white">Kiralık · kendin sür</h2>
              <span className="rounded-full bg-st-delivered/15 px-3 py-1 text-[11px] font-semibold text-[#86EFAC]">
                Kullanıma açık
              </span>
            </div>
            <p className="mt-3 max-w-xl text-sm text-slate-300">
              Scooter, e-bisiklet ve moped. Haritadan seç, kilidi sunucuda açılsın, dakika bazlı öde.
            </p>
            <dl className="mt-6 grid grid-cols-3 gap-3 text-sm">
              <div>
                <dt className="text-[11px] uppercase tracking-[0.1em] text-slate-500">Hazır araç</dt>
                <dd className="font-display text-xl font-bold text-white">{readyVehicles.length}</dd>
              </div>
              <div>
                <dt className="text-[11px] uppercase tracking-[0.1em] text-slate-500">Dakika</dt>
                <dd className="font-display text-xl font-bold text-white">
                  {minVehiclePrice === null ? "—" : formatTry(minVehiclePrice)}
                </dd>
              </div>
              <div>
                <dt className="text-[11px] uppercase tracking-[0.1em] text-slate-500">Emisyon</dt>
                <dd className="font-display text-xl font-bold text-white">sıfır</dd>
              </div>
            </dl>
            <p className="mt-6 text-sm font-semibold text-sur">Araç bul →</p>
          </Link>
        </Reveal>

        <Reveal delay={0.05}>
          <Link
            href="/yolculuk/suruculu"
            className="block h-full rounded-lg border border-white/10 bg-white/3 p-8 transition hover:border-accent/50"
          >
            <div className="flex flex-wrap items-center gap-3">
              <h2 className="font-display text-2xl font-bold text-white">Sürücülü · seni götürsün</h2>
              <span className="rounded-full bg-st-waiting/15 px-3 py-1 text-[11px] font-semibold text-st-waiting">
                {CHAUFFEUR_SERVICE_GATE.live ? "Açık" : "Pilot"}
              </span>
            </div>
            <p className="mt-3 text-sm text-slate-300">
              Talep oluştur, yakındaki doğrulanmış sürücülere teklif gitsin, buluşma koduyla araca bin.
            </p>
            <p className="mt-4 rounded-md border border-st-waiting/35 bg-st-waiting/8 p-3 text-xs text-slate-300">
              {CHAUFFEUR_SERVICE_GATE.live
                ? "Hizmet açık."
                : `Bu modül ${CHAUFFEUR_SERVICE_GATE.label}. Ticari yolcu taşımacılığı belge rejimine tabi; hukuk onayı olmadan canlı hizmet olarak açılmıyor. Akış pilot modda uçtan uca çalışır.`}
            </p>
            <p className="mt-6 text-sm font-semibold text-accent">
              {drivers.length} doğrulanmış sürücü çevrimiçi →
            </p>
          </Link>
        </Reveal>
      </div>

      <Reveal delay={0.1} className="mt-10">
        <div className="rounded-lg border border-white/10 bg-white/3 p-6">
          <h2 className="font-display text-lg font-semibold text-white">İkisi de aynı hesapta</h2>
          <ul className="mt-4 grid gap-3 text-sm text-slate-300 md:grid-cols-3">
            <li>· Tek bakiye: kiralama ve sürücülü yolculuk aynı platform bakiyesinden ödenir.</li>
            <li>· Tek geçmiş: /app/yolculuk altında ikisi birlikte, filtreli.</li>
            <li>· Tek güvenlik akışı: acil durum, güvenilen kişiyle paylaşım ve olay bildirimi ortak.</li>
          </ul>
        </div>
      </Reveal>
    </PageShell>
  );
}
