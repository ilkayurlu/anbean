import Link from "next/link";
import { db } from "@/db";
import { chauffeurProfiles, chauffeurTariffs } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import PageShell from "@/components/PageShell";
import Reveal from "@/components/Reveal";
import StatusStrip from "@/components/StatusStrip";
import { CHAUFFEUR_SERVICE_GATE } from "@/lib/hail";
import { formatTry } from "@/lib/pricing";

export const dynamic = "force-dynamic";
export const metadata = {
  title: "Sürücülü yolculuk — Anbean",
  description:
    "Belgesi doğrulanmış sürücülerle yolculuk talebi. Tahmini ücret önceden, kesin tutar yolculuk sonunda hesaplanır.",
};

const SAFETY = [
  "Sürücü belgeleri doğrulanmadan teklif alamaz: kimlik, ehliyet, ruhsat, sigorta, adli sicil ve ticari taşıma belgesi.",
  "Buluşma kodu (OTP) doğrulanmadan yolculuk başlatılamaz. Yanlış araca binme riskini keser.",
  "Yolculuk sırasında tek dokunuşla acil durum: 112 yönlendirmesi ve platforma olay kaydı.",
  "Güvendiğin kişiyle canlı paylaşım: plaka, sürücünün adı, yaklaşık konum. Telefonun ve adresin paylaşılmaz.",
  "Kritik güvenlik olayında sürücü inceleme süresince otomatik askıya alınır.",
  "Sürücü konumu yalnızca aktif yolculukta toplanır; yolculuk bitince ham konum alınmaz.",
];

export default async function SuruculuPage() {
  const [drivers, tariffs] = await Promise.all([
    db
      .select()
      .from(chauffeurProfiles)
      .where(and(eq(chauffeurProfiles.commercialDocsVerified, true), eq(chauffeurProfiles.availability, "online_idle")))
      .catch(() => []),
    db.select().from(chauffeurTariffs).catch(() => []),
  ]);

  return (
    <PageShell
      eyebrow={`Sürücülü yolculuk · ${CHAUFFEUR_SERVICE_GATE.live ? "açık" : CHAUFFEUR_SERVICE_GATE.label}`}
      title="Seni götürsün"
      lead="Talep oluştur, yakındaki doğrulanmış sürücülere teklif gitsin. Tahmini ücreti önceden görürsün; kesin tutar yolculuk sonunda gerçek mesafe ve süreyle hesaplanır."
    >
      {!CHAUFFEUR_SERVICE_GATE.live ? (
        <div className="rounded-lg border border-st-waiting/40 bg-st-waiting/10 p-5">
          <p className="text-sm font-semibold text-white">Bu modül pilot aşamasında</p>
          <p className="mt-2 text-sm text-slate-300">
            Türkiye&apos;de ticari yolcu taşımacılığı ayrı belge ve ruhsat rejimine tabidir. Özel araçla ücretli
            yolcu taşımanın hukuki statüsü ayrıca değerlendirilmelidir. Bu yüzden akış uçtan uca çalışır ama{" "}
            <strong className="text-white">canlı ticari hizmet olarak açılmaz</strong>: sürücüler ve araçlar demo
            verisidir, gerçek yolcu alınmaz.
          </p>
          <p className="mt-2 text-xs text-slate-400">
            Canlıya geçiş kapıları: hukuk danışmanı onayı, vergi/mali müşavir görüşü, ticari taşıma belgelerinin
            gerçek doğrulaması, ödeme kuruluşu entegrasyonu.
          </p>
        </div>
      ) : null}

      <Reveal className="mt-8">
        <div className="grid gap-4 sm:grid-cols-3">
          <Stat label="Çevrimiçi doğrulanmış sürücü" value={String(drivers.length)} />
          {tariffs.slice(0, 2).map((tariff) => (
            <Stat
              key={tariff.code}
              label={`${tariff.name} · açılış`}
              value={formatTry(tariff.baseKurus)}
              note={`${formatTry(tariff.perKmKurus)}/km + ${formatTry(tariff.perMinKurus)}/dk · komisyon %${tariff.commissionPercent}`}
            />
          ))}
        </div>
      </Reveal>

      <Reveal delay={0.05} className="mt-10">
        <h2 className="font-display text-2xl font-bold text-white">Nasıl çalışır?</h2>
        <ol className="mt-6 grid gap-3 md:grid-cols-5">
          {[
            { t: "Talep oluştur", d: "Alım/varış, mesafe ve hizmet tipi. Ücret sunucuda kilitlenir.", status: "alim_planlandi" },
            { t: "Sürücü aranır", d: "Yakındaki, belgesi doğrulanmış sürücülere sıralı teklif gider.", status: "kurye_atamasi_bekliyor" },
            { t: "Kabul ve atama", d: "Kabul eden ilk sürücü atanır; plaka ve araç bilgisi görünür.", status: "kurye_atandi" },
            { t: "Buluşma kodu", d: "OTP doğrulanmadan yolculuk başlamaz.", status: "gonderi_alindi" },
            { t: "Yolculuk ve kapanış", d: "Kesin tutar gerçek mesafe/süreyle hesaplanır, fark gösterilir.", status: "teslim_edildi" },
          ].map((step, index) => (
            <li key={step.t} className="rounded-lg border border-white/10 bg-white/3 p-5">
              <span className="font-display text-2xl font-bold text-accent">{index + 1}</span>
              <p className="mt-2 text-sm font-semibold text-white">{step.t}</p>
              <p className="mt-1 text-xs text-slate-400">{step.d}</p>
              <StatusStrip status={step.status} size="sm" className="mt-4" />
            </li>
          ))}
        </ol>
      </Reveal>

      <Reveal delay={0.1} className="mt-10">
        <h2 className="font-display text-2xl font-bold text-white">Güvenlik</h2>
        <ul className="mt-5 grid gap-3 md:grid-cols-2">
          {SAFETY.map((item) => (
            <li key={item} className="flex gap-3 rounded-lg border border-white/10 bg-white/3 p-4 text-sm text-slate-300">
              <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
              {item}
            </li>
          ))}
        </ul>
        <p className="mt-4 text-xs text-slate-500">
          Ses kaydı, biyometrik doğrulama ve cinsiyet bazlı eşleştirme bilinçli olarak sunulmuyor: hukuki risk ve
          ayrımcılık mevzuatı açısından onay gerektirir.
        </p>
      </Reveal>

      <Reveal delay={0.15} className="mt-10">
        <div className="flex flex-wrap gap-3">
          <Link href="/app/yolculuk/yeni" className="rounded-md bg-accent px-6 py-3 text-sm font-semibold text-[#0B1220]">
            Yolculuk talep et
          </Link>
          <Link href="/surucu-ol" className="rounded-md border border-white/15 px-6 py-3 text-sm text-slate-200">
            Sürücü ol
          </Link>
          <Link href="/yolculuk/kiralik" className="rounded-md border border-white/15 px-6 py-3 text-sm text-slate-200">
            Kiralık araçlara bak
          </Link>
        </div>
        <p className="mt-4 text-xs text-slate-500">
          Sürücü başvurusu kurye başvurusundan ayrıdır: belgeler ve sorumluluk farklıdır. Aynı kişi ikisine de
          başvurabilir.
        </p>
      </Reveal>
    </PageShell>
  );
}

function Stat({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="rounded-lg border border-white/10 bg-white/3 p-5">
      <p className="text-[11px] uppercase tracking-[0.12em] text-slate-500">{label}</p>
      <p className="mt-2 font-display text-2xl font-bold text-white">{value}</p>
      {note ? <p className="mt-1 text-[11px] text-slate-500">{note}</p> : null}
    </div>
  );
}
