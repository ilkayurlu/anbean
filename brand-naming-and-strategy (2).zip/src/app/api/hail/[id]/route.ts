import { db } from "@/db";
import {
  chauffeurProfiles,
  chauffeurVehicles,
  passengerRideEvents,
  passengerRideRequests,
  passengerRides,
} from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { requirePermission } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import { expireStaleOffers, RIDE_STATUS_LABEL, type RideStatus } from "@/lib/hail";
import { maskName } from "@/lib/status";

export const dynamic = "force-dynamic";

/**
 * Yolculuk detayı — rol bazlı alan filtreleme.
 *  - Yolcu: kendi yolculuğu, tam bilgi (ödeme dahil).
 *  - Sürücü: yalnızca kendisine atanan; yolcu telefonu/adı MASKELİ.
 *  - Güvenlik: yolculuk ve olay detayı, AMA ödeme alanları YOK.
 *  - Ops/admin: tamamı.
 */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("hail:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) return Response.json({ error: "Geçersiz yolculuk" }, { status: 400 });

  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, id)).limit(1);
  if (!ride) return Response.json({ error: "Yolculuk bulunamadı" }, { status: 404 });

  const [request] = await db
    .select()
    .from(passengerRideRequests)
    .where(eq(passengerRideRequests.id, ride.requestId))
    .limit(1);
  if (!request) return Response.json({ error: "Talep bulunamadı" }, { status: 404 });

  const isOwner = request.customerId === user.id;
  const [profile] = ride.chauffeurId
    ? await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.id, ride.chauffeurId)).limit(1)
    : [];
  const isAssignedDriver = Boolean(profile && profile.userId === user.id);
  const isOps = hasPermission(user.role, "chauffeur:manage");
  const isSafety = user.role === "guvenlik";

  if (!isOwner && !isAssignedDriver && !isOps && !isSafety) {
    return Response.json({ error: "Yetkisiz" }, { status: 403 });
  }

  // Teklif zaman aşımı: okuma anında bayat teklifler kapatılır.
  if (ride.status === "MATCHING") await expireStaleOffers(ride.id);

  const [vehicle] = ride.vehicleId
    ? await db.select().from(chauffeurVehicles).where(eq(chauffeurVehicles.id, ride.vehicleId)).limit(1)
    : [];
  const events = await db
    .select()
    .from(passengerRideEvents)
    .where(eq(passengerRideEvents.rideId, ride.id))
    .orderBy(asc(passengerRideEvents.createdAt));

  const canSeePayment = isOwner || isOps;
  const canSeeExactAddress = isOwner || isAssignedDriver || isOps;

  return Response.json({
    ride: {
      id: ride.id,
      code: ride.code,
      status: ride.status,
      statusLabel: RIDE_STATUS_LABEL[ride.status as RideStatus] ?? ride.status,
      quotedFareKurus: canSeePayment ? ride.quotedFareKurus : null,
      finalFareKurus: canSeePayment ? ride.finalFareKurus : null,
      commissionKurus: canSeePayment || isAssignedDriver ? ride.commissionKurus : null,
      paymentStatus: canSeePayment ? ride.paymentStatus : null,
      tariffCode: canSeePayment ? ride.tariffCode : null,
      otpVerified: Boolean(ride.otpVerifiedAt),
      createdAt: ride.createdAt,
      pickupAt: ride.pickupAt,
      dropoffAt: ride.dropoffAt,
      distanceKm: ride.distanceKm,
      durationMin: ride.durationMin,
      isDemo: ride.isDemo,
      cancelReason: ride.cancelReason || null,
    },
    route: {
      pickupDistrict: request.pickupDistrict,
      dropDistrict: request.dropDistrict,
      pickupAddress: canSeeExactAddress ? request.pickupAddress : `${request.pickupDistrict} (adres gizli)`,
      dropAddress: canSeeExactAddress ? request.dropAddress : `${request.dropDistrict} (adres gizli)`,
      pickupLat: request.pickupLat,
      pickupLng: request.pickupLng,
    },
    passenger: isOwner
      ? { name: "Sen" }
      : { name: maskName(user.fullName === profile?.fullName ? request.pickupDistrict : "Yolcu") },
    chauffeur: profile
      ? {
          // Sürücü soyadı ve telefonu yolcuya verilmez.
          firstName: profile.fullName.split(" ")[0],
          rating: profile.ratingCount > 0 ? Math.round((profile.ratingSum / profile.ratingCount) * 10) / 10 : null,
          ratingCount: profile.ratingCount,
          totalTrips: profile.totalTrips,
          isDemo: profile.isDemo,
        }
      : null,
    vehicle: vehicle
      ? {
          plate: vehicle.plate,
          make: vehicle.make,
          model: vehicle.model,
          color: vehicle.color,
          seatCount: vehicle.seatCount,
          vehicleType: vehicle.vehicleType,
        }
      : null,
    events: events.map((event) => ({
      id: event.id,
      eventType: event.eventType,
      actor: event.actor,
      note: event.note,
      createdAt: event.createdAt,
    })),
    capabilities: {
      canCancel: isOwner && ["REQUESTED", "MATCHING", "DRIVER_ASSIGNED", "DRIVER_EN_ROUTE", "DRIVER_ARRIVED"].includes(ride.status),
      canRequestOtp: isOwner && ["DRIVER_ASSIGNED", "DRIVER_EN_ROUTE", "DRIVER_ARRIVED"].includes(ride.status),
      canDrive: isAssignedDriver,
      canReportSafety: isOwner || isAssignedDriver,
      canSeePayment,
    },
  });
}
