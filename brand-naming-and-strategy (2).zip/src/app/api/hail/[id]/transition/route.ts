import { z } from "zod";
import { db } from "@/db";
import { chauffeurProfiles, passengerRides } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { canTransitionRide, completeRide, logRideEvent, RIDE_STATUS_LABEL, type RideStatus } from "@/lib/hail";
import { verifyPickupOtp } from "@/lib/hail";

export const dynamic = "force-dynamic";

const schema = z.object({
  action: z.enum(["en_route", "arrived", "start", "complete", "otp_issue", "otp_verify", "driver_cancel"]),
  otp: z.string().trim().max(10).optional(),
  actualDistanceKm: z.number().min(0.1).max(300).optional(),
  actualDurationMin: z.number().int().min(1).max(600).optional(),
  reason: z.string().trim().max(200).optional(),
});

/**
 * Sürücü tarafı durum geçişleri.
 *  - Yalnızca ATANMIŞ sürücü işlem yapabilir (IDOR koruması).
 *  - OTP doğrulanmadan IN_PROGRESS'e geçilemez.
 *  - Tamamlamada ücret sunucuda YENİDEN hesaplanır.
 */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("hail:drive");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) return Response.json({ error: "Geçersiz yolculuk" }, { status: 400 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Geçersiz işlem" }, { status: 400 });
  const { action } = parsed.data;

  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, id)).limit(1);
  if (!ride) return Response.json({ error: "Yolculuk bulunamadı" }, { status: 404 });

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);
  if (!profile) return Response.json({ error: "Sürücü profili bulunamadı" }, { status: 403 });
  if (ride.chauffeurId !== profile.id) {
    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: "yetkisiz_yolculuk_erisim_denemesi",
      entity: "passenger_ride",
      entityId: String(id),
    });
    return Response.json({ error: "Bu yolculuk size atanmamış" }, { status: 403 });
  }
  if (profile.suspendedUntil && profile.suspendedUntil.getTime() > Date.now()) {
    return Response.json({ error: `Hesabınız askıda: ${profile.suspensionReason}` }, { status: 403 });
  }

  // OTP işlemleri
  if (action === "otp_verify") {
    const ok = await verifyPickupOtp(id, parsed.data.otp ?? "");
    if (!ok) {
      await logRideEvent({ rideId: id, eventType: "OTP_FAILED", actor: "chauffeur" });
      return Response.json({ error: "Buluşma kodu hatalı." }, { status: 401 });
    }
    await logRideEvent({ rideId: id, eventType: "OTP_VERIFIED", actor: "chauffeur" });
    return Response.json({ ok: true, otpVerified: true });
  }
  if (action === "otp_issue") {
    // OTP'yi yolcu üretir/görür; sürücü yalnızca doğrular.
    return Response.json({ error: "Buluşma kodunu yolcu tarafı üretir." }, { status: 403 });
  }

  const target: RideStatus | null =
    action === "en_route"
      ? "DRIVER_EN_ROUTE"
      : action === "arrived"
        ? "DRIVER_ARRIVED"
        : action === "start"
          ? "IN_PROGRESS"
          : action === "complete"
            ? "COMPLETED"
            : action === "driver_cancel"
              ? "CANCELLED_BY_DRIVER"
              : null;

  if (!target) return Response.json({ error: "Geçersiz işlem" }, { status: 400 });

  if (action === "start" && !ride.otpVerifiedAt) {
    return Response.json(
      { error: "Buluşma kodu doğrulanmadan yolculuk başlatılamaz." },
      { status: 409 },
    );
  }
  // Sürücü iptali yalnızca buluşma noktasına varana kadar.
  if (action === "driver_cancel" && ["DRIVER_ARRIVED", "IN_PROGRESS"].includes(ride.status)) {
    return Response.json({ error: "Bu aşamadan sonra sürücü iptal edemez." }, { status: 409 });
  }

  if (!canTransitionRide(ride.status, target)) {
    return Response.json(
      {
        error: `Geçersiz geçiş: ${RIDE_STATUS_LABEL[ride.status as RideStatus]} → ${RIDE_STATUS_LABEL[target]}`,
      },
      { status: 409 },
    );
  }

  if (action === "complete") {
    const distance = Number(parsed.data.actualDistanceKm ?? ride.distanceKm);
    const duration = Number(parsed.data.actualDurationMin ?? Math.max(1, Math.round((Date.now() - new Date(ride.pickupAt ?? ride.createdAt).getTime()) / 60_000)));
    const result = await completeRide({
      rideId: id,
      actualDistanceKm: distance,
      actualDurationMin: duration,
      actorId: user.id,
      actorRole: user.role,
    });
    if (!result.ok) return Response.json({ error: result.error }, { status: 409 });

    return Response.json({
      ok: true,
      status: "COMPLETED",
      quotedKurus: result.quotedKurus,
      finalKurus: result.finalKurus,
      differenceKurus: result.differenceKurus,
      commissionKurus: result.commissionKurus,
      driverNetKurus: result.driverNetKurus,
      breakdown: result.breakdown,
    });
  }

  const now = new Date();
  await db
    .update(passengerRides)
    .set({
      status: target,
      pickupAt: target === "IN_PROGRESS" ? (ride.pickupAt ?? now) : ride.pickupAt,
      cancelReason: action === "driver_cancel" ? (parsed.data.reason ?? "") : ride.cancelReason,
    })
    .where(eq(passengerRides.id, id));

  await db
    .update(chauffeurProfiles)
    .set({
      availability:
        target === "CANCELLED_BY_DRIVER"
          ? "online_idle"
          : target === "COMPLETED"
            ? "online_idle"
            : "on_trip",
      cancelCount: action === "driver_cancel" ? profile.cancelCount + 1 : profile.cancelCount,
    })
    .where(eq(chauffeurProfiles.id, profile.id));

  await logRideEvent({
    rideId: id,
    eventType: target,
    actor: "chauffeur",
    lat: profile.lastLat,
    lng: profile.lastLng,
    note: parsed.data.reason ?? "",
  });

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: `suruculu_yolculuk_${action}`,
    entity: "passenger_ride",
    entityId: String(id),
    meta: { status: target },
  });

  return Response.json({ ok: true, status: target });
}

