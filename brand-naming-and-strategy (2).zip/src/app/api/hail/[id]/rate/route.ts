import { z } from "zod";
import { db } from "@/db";
import { chauffeurProfiles, passengerRideRequests, passengerRides } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { logRideEvent } from "@/lib/hail";

export const dynamic = "force-dynamic";

const schema = z.object({ score: z.number().int().min(1).max(5), comment: z.string().trim().max(300).optional() });

/** Yolculuk sonrası değerlendirme — yalnızca tamamlanmış yolculukta ve yalnızca yolcu. */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("hail:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Puan 1-5 arasında olmalı" }, { status: 400 });

  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, id)).limit(1);
  if (!ride) return Response.json({ error: "Yolculuk bulunamadı" }, { status: 404 });
  const [request] = await db
    .select()
    .from(passengerRideRequests)
    .where(eq(passengerRideRequests.id, ride.requestId))
    .limit(1);
  if (!request || request.customerId !== user.id) {
    return Response.json({ error: "Bu yolculuk size ait değil" }, { status: 403 });
  }
  if (ride.status !== "COMPLETED") {
    return Response.json({ error: "Yalnızca tamamlanan yolculuk değerlendirilebilir." }, { status: 409 });
  }
  if (ride.customerRating !== null) {
    return Response.json({ error: "Bu yolculuk zaten değerlendirildi." }, { status: 409 });
  }
  if (!ride.chauffeurId) return Response.json({ error: "Sürücü kaydı yok" }, { status: 409 });

  await db.update(passengerRides).set({ customerRating: parsed.data.score }).where(eq(passengerRides.id, id));
  // Sahte puan yok: ortalama yalnızca gerçek değerlendirmelerden hesaplanır.
  await db
    .update(chauffeurProfiles)
    .set({
      ratingSum: sql`${chauffeurProfiles.ratingSum} + ${parsed.data.score}`,
      ratingCount: sql`${chauffeurProfiles.ratingCount} + 1`,
    })
    .where(eq(chauffeurProfiles.id, ride.chauffeurId));

  await logRideEvent({ rideId: id, eventType: "RATED", actor: "user", note: `${parsed.data.score}/5` });
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "suruculu_yolculuk_degerlendirildi",
    entity: "passenger_ride",
    entityId: String(id),
    meta: { score: parsed.data.score },
  });

  return Response.json({ ok: true });
}
