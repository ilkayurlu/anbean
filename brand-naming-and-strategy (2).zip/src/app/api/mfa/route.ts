import { headers } from "next/headers";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { rateLimit, requireAuth, writeAudit } from "@/lib/auth";
import { generateSecret, otpauthUrl, verifyTotp } from "@/lib/totp";

export const dynamic = "force-dynamic";

const schema = z.object({
  action: z.enum(["enroll", "verify", "disable"]),
  code: z.string().trim().max(10).optional(),
  reason: z.string().trim().max(200).optional(),
});

/**
 * İki aşamalı doğrulama (TOTP).
 * - enroll: sır üretir, QR/otpauth bağlantısı BİR KEZ döner.
 * - verify: kodu doğrular, totpEnabled=true yapar (doğrulamadan etkinleşmez).
 * - disable: gerekçe ister, denetime yazılır.
 * Sır hiçbir listeleme yanıtında dönmez.
 */
export async function POST(req: Request) {
  const user = await requireAuth();
  if (!user) return Response.json({ error: "Oturum gerekli" }, { status: 401 });

  const head = await headers();
  const ip = head.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (!rateLimit(`mfa:${user.id}`, 20, 10 * 60_000)) {
    return Response.json({ error: "Çok fazla deneme. 10 dakika bekleyin." }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Geçersiz istek" }, { status: 400 });
  const { action, code, reason } = parsed.data;

  const [row] = await db.select().from(users).where(eq(users.id, user.id)).limit(1);
  if (!row) return Response.json({ error: "Kullanıcı bulunamadı" }, { status: 404 });

  if (action === "enroll") {
    const secret = generateSecret();
    await db.update(users).set({ totpSecret: secret, totpEnabled: false }).where(eq(users.id, user.id));
    await writeAudit({ actorId: user.id, actorRole: user.role, action: "mfa_kurulum_basladi", entity: "user", entityId: String(user.id), ip });
    return Response.json({
      ok: true,
      secret,
      otpauth: otpauthUrl({ secret, account: row.email }),
      notice: "Bu sır yalnızca bir kez gösterilir. Uygulamaya ekledikten sonra kodu girerek etkinleştirin.",
    });
  }

  if (action === "verify") {
    if (!row.totpSecret) return Response.json({ error: "Önce kurulum başlatın." }, { status: 409 });
    if (!code || !verifyTotp(row.totpSecret, code)) {
      await writeAudit({ actorId: user.id, actorRole: user.role, action: "mfa_dogrulama_basarisiz", entity: "user", entityId: String(user.id), ip });
      return Response.json({ error: "Kod hatalı veya süresi geçmiş." }, { status: 401 });
    }
    await db.update(users).set({ totpEnabled: true }).where(eq(users.id, user.id));
    await writeAudit({ actorId: user.id, actorRole: user.role, action: "mfa_etkinlestirildi", entity: "user", entityId: String(user.id), ip });
    return Response.json({ ok: true, enabled: true });
  }

  // disable
  if (!reason || reason.trim().length < 5) {
    return Response.json({ error: "MFA kapatmak için gerekçe zorunlu." }, { status: 400 });
  }
  await db.update(users).set({ totpEnabled: false, totpSecret: null }).where(eq(users.id, user.id));
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "mfa_kapatildi",
    entity: "user",
    entityId: String(user.id),
    reason,
    ip,
  });
  return Response.json({ ok: true, enabled: false });
}
