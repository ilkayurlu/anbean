import { z } from "zod";
import { db } from "@/db";
import { chauffeurDocuments, chauffeurProfiles, chauffeurVehicles, users } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { REQUIRED_COMMERCIAL_DOCS } from "@/lib/hail";

export const dynamic = "force-dynamic";

const schema = z.object({
  docType: z.string().trim().min(2).max(40),
  decision: z.enum(["approved", "rejected"]),
  reason: z.string().trim().max(200).optional(),
  expiresAt: z.string().trim().optional(),
  vehiclePlate: z.string().trim().max(20).optional(),
});

/**
 * Belge inceleme ve onay.
 * Tüm ticari belgeler onaylandığında sürücü doğrulanmış sayılır ve rolü
 * "surucu"ya yükseltilir. Rol yükseltmesi yalnızca bu uçtan yapılır;
 * kullanıcı kendi rolünü değiştiremez.
 */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("chauffeur:verify");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const chauffeurId = Number((await ctx.params).id);
  if (!Number.isFinite(chauffeurId)) return Response.json({ error: "Geçersiz sürücü" }, { status: 400 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Geçersiz karar" }, { status: 400 });
  const input = parsed.data;

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.id, chauffeurId)).limit(1);
  if (!profile) return Response.json({ error: "Sürücü bulunamadı" }, { status: 404 });

  const [doc] = await db
    .select()
    .from(chauffeurDocuments)
    .where(and(eq(chauffeurDocuments.chauffeurId, chauffeurId), eq(chauffeurDocuments.docType, input.docType)))
    .limit(1);
  if (!doc) return Response.json({ error: "Belge kaydı yok" }, { status: 404 });

  await db
    .update(chauffeurDocuments)
    .set({
      status: input.decision,
      reviewedBy: user.id,
      reviewedAt: new Date(),
      rejectionReason: input.decision === "rejected" ? (input.reason ?? "") : "",
      expiresAt: input.expiresAt ? new Date(input.expiresAt) : doc.expiresAt,
      // Dosya sağlayıcısı yok: onay, meta veri üzerinden verilir.
      storageRef: doc.storageRef || `metadata-only:${input.docType}`,
    })
    .where(eq(chauffeurDocuments.id, doc.id));

  if (input.vehiclePlate) {
    await db
      .update(chauffeurVehicles)
      .set({ documentsVerified: input.decision === "approved", isActive: input.decision === "approved" })
      .where(and(eq(chauffeurVehicles.chauffeurId, chauffeurId), eq(chauffeurVehicles.plate, input.vehiclePlate.toUpperCase())));
  }

  // Tüm ticari belgeler onaylı mı?
  const docs = await db.select().from(chauffeurDocuments).where(eq(chauffeurDocuments.chauffeurId, chauffeurId));
  const approvedRequired = (REQUIRED_COMMERCIAL_DOCS as readonly string[]).filter((type) =>
    docs.some((d) => d.docType === type && d.status === "approved"),
  );
  const fullyVerified = approvedRequired.length === REQUIRED_COMMERCIAL_DOCS.length;
  const vehicleOk = await db
    .select({ id: chauffeurVehicles.id })
    .from(chauffeurVehicles)
    .where(and(eq(chauffeurVehicles.chauffeurId, chauffeurId), eq(chauffeurVehicles.documentsVerified, true)))
    .limit(1);

  await db
    .update(chauffeurProfiles)
    .set({
      isVerified: fullyVerified,
      commercialDocsVerified: fullyVerified && vehicleOk.length > 0,
      verificationLevel: fullyVerified ? "ileri" : "temel",
      status: fullyVerified && vehicleOk.length > 0 ? "aktif" : input.decision === "rejected" ? "pasif" : "belge_bekliyor",
    })
    .where(eq(chauffeurProfiles.id, chauffeurId));

  if (fullyVerified && vehicleOk.length > 0 && profile.userId) {
    const [account] = await db.select().from(users).where(eq(users.id, profile.userId)).limit(1);
    if (account && account.role !== "surucu" && account.role !== "admin") {
      await db.update(users).set({ role: "surucu" }).where(eq(users.id, account.id));
      await writeAudit({
        actorId: user.id,
        actorRole: user.role,
        action: "rol_yukseltildi",
        entity: "user",
        entityId: String(account.id),
        meta: { from: account.role, to: "surucu", reason: "ticari belgeler doğrulandı" },
      });
    }
  }

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: `belge_${input.decision}`,
    entity: "chauffeur_document",
    entityId: String(doc.id),
    meta: { docType: input.docType, chauffeurId },
  });

  return Response.json({
    ok: true,
    fullyVerified,
    approvedRequired: approvedRequired.length,
    requiredTotal: REQUIRED_COMMERCIAL_DOCS.length,
    missing: (REQUIRED_COMMERCIAL_DOCS as readonly string[]).filter((type) => !approvedRequired.includes(type)),
  });
}
