import { db } from "@/db";
import { organizations, users } from "@/db/schema";
import { desc, eq, isNull } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { csvResponse, requestContext, toCsv } from "@/lib/auditContext";
import { ROLE_LABEL, type Role } from "@/lib/auth";

export const dynamic = "force-dynamic";

/**
 * CSV dışa aktarma.
 * - `member:export` izni ZORUNLU.
 * - GEREKÇE zorunlu (denetim kaydına yazılır).
 * - Hassas alanlar (parola, erişim kodu, TOTP) dışa aktarılmaz; e-posta ve
 *   telefon yalnızca `member:sensitive` izni varsa açık, yoksa maskeli.
 */
export async function GET(req: Request) {
  const user = await requirePermission("member:export");
  if (!user) return new Response("Yetkisiz", { status: 403 });

  const url = new URL(req.url);
  const reason = (url.searchParams.get("reason") ?? "").trim();
  if (reason.length < 5) {
    return new Response("Dışa aktarma için gerekçe zorunlu (en az 5 karakter)", { status: 400 });
  }

  const sensitive = url.searchParams.get("sensitive") === "1";
  const rows = await db.select().from(users).where(isNull(users.archivedAt)).orderBy(desc(users.createdAt)).limit(5000);
  const orgRows = await db.select().from(organizations);
  const orgById = new Map(orgRows.map((o) => [o.id, o.name]));

  const mask = (value: string, keep: number) => `${value.slice(0, keep)}***`;

  const csv = toCsv(
    rows.map((row) => ({
      id: row.id,
      ad_soyad: row.fullName,
      eposta: sensitive ? row.email : mask(row.email, 2),
      telefon: sensitive ? (row.phone ?? "") : mask((row.phone ?? "").replace(/\D/g, ""), 3),
      rol: ROLE_LABEL[row.role as Role] ?? row.role,
      isletme: row.orgId ? (orgById.get(row.orgId) ?? "") : "",
      aktif: row.isActive ? "evet" : "hayir",
      banli: row.isBanned ? "evet" : "hayir",
      mfa: row.totpEnabled ? "evet" : "hayir",
      son_giris: row.lastLoginAt ? new Date(row.lastLoginAt).toISOString() : "",
      kayit: new Date(row.createdAt).toISOString(),
    })),
  );

  const context = await requestContext();
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "uye_disa_aktarma",
    entity: "user",
    entityId: `${rows.length} kayit`,
    reason,
    meta: { sensitive, count: rows.length },
    ip: context.ip,
    userAgent: context.userAgent,
  });

  return csvResponse(`uyeler-${new Date().toISOString().slice(0, 10)}.csv`, csv);
}

