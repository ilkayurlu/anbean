import { z } from "zod";
import { db } from "@/db";
import { adminNotes, auditLog, couriers, orders, shipments, supportTickets, users } from "@/db/schema";
import { and, desc, eq, or, sql } from "drizzle-orm";
import { requirePermission, writeAudit, type Role } from "@/lib/auth";
import { hasPermission, ROLE_PERMISSIONS } from "@/lib/permissions";
import { ROLE_LABEL } from "@/lib/auth";
import { requestContext } from "@/lib/auditContext";

export const dynamic = "force-dynamic";

const patchSchema = z.object({
  fullName: z.string().trim().min(3).max(120).optional(),
  phone: z.string().trim().max(20).optional(),
  email: z
    .string()
    .trim()
    .toLowerCase()
    .regex(/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, "Geçerli bir e-posta girin")
    .optional(),
});

/**
 * Üye detayı.
 * Parola/erişim kodu/TOTP sırrı dönmez. E-posta ve telefon `member:sensitive`
 * iznine bağlıdır; izin yoksa maskeli gelir ve değişiklik de yapılamaz.
 */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("member:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  if (!Number.isFinite(id)) return Response.json({ error: "Geçersiz üye" }, { status: 400 });

  // Tenant izolasyonu: işletme rolü yalnızca kendi üyesini açabilir.
  if (user.role === "isletme_sahibi" || user.role === "isletme_calisani") {
    if (id !== user.id && user.orgId === null) return Response.json({ error: "Yetkisiz" }, { status: 403 });
  }

  const [member] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!member || member.archivedAt) {
    if (!member) return Response.json({ error: "Üye bulunamadı" }, { status: 404 });
  }

  const canSensitive = hasPermission(user.role, "member:sensitive");
  const [courier] = await db.select().from(couriers).where(eq(couriers.userId, id)).limit(1);
  const [notes, logs, tickets, shipmentRows, orderRows] = await Promise.all([
    db.select().from(adminNotes).where(and(eq(adminNotes.entityKind, "user"), eq(adminNotes.entityId, id))).orderBy(desc(adminNotes.createdAt)).limit(50),
    db.select().from(auditLog).where(eq(auditLog.actorId, id)).orderBy(desc(auditLog.createdAt)).limit(30),
    db.select().from(supportTickets).where(eq(supportTickets.userId, id)).orderBy(desc(supportTickets.createdAt)).limit(20),
    db
      .select()
      .from(shipments)
      .where(or(eq(shipments.createdByUserId, id), eq(shipments.assignedCourierId, courier?.id ?? -1)))
      .orderBy(desc(shipments.createdAt))
      .limit(20),
    db.select().from(orders).where(eq(orders.userId, id)).orderBy(desc(orders.createdAt)).limit(20),
  ]);

  return Response.json({
    member: {
      id: member.id,
      fullName: member.fullName,
      email: canSensitive ? member.email : `${member.email.slice(0, 2)}***@${member.email.split("@")[1] ?? ""}`,
      phone: canSensitive ? (member.phone ?? "") : (member.phone ?? "").replace(/\D/g, "").slice(0, 3) + "*****",
      role: member.role,
      roleLabel: ROLE_LABEL[member.role as Role] ?? member.role,
      permissions: ROLE_PERMISSIONS[member.role as Role]?.length ?? 0,
      orgId: member.orgId,
      isActive: member.isActive,
      isBanned: member.isBanned,
      archived: member.archivedAt !== null,
      mustChangePassword: member.mustChangePassword,
      mfaEnabled: member.totpEnabled,
      marketingConsent: member.marketingConsent,
      kvkkConsentAt: member.kvkkConsentAt,
      lastLoginAt: member.lastLoginAt,
      createdAt: member.createdAt,
      // Güvenlik alanları asla dönmez: passwordHash, passcode, totpSecret
    },
    courier: courier
      ? { id: courier.id, status: courier.status, city: courier.city, vehicle: courier.vehicle, activeLoad: courier.activeLoad }
      : null,
    notes,
    audit: logs.map((log) => ({
      id: log.id,
      action: log.action,
      entity: log.entity,
      entityId: log.entityId,
      reason: log.reason,
      createdAt: log.createdAt,
    })),
    tickets: tickets.map((t) => ({ id: t.id, code: t.code, subject: t.subject, status: t.status, createdAt: t.createdAt })),
    shipments: shipmentRows.map((s) => ({ id: s.id, code: s.code, status: s.status, priceKurus: s.priceKurus, createdAt: s.createdAt })),
    orders: orderRows.map((o) => ({ id: o.id, code: o.code, status: o.status, totalKurus: o.totalKurus, createdAt: o.createdAt })),
  });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("member:manage");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const [member] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!member) return Response.json({ error: "Üye bulunamadı" }, { status: 404 });

  const parsed = patchSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz alan" }, { status: 400 });
  }
  const input = parsed.data;

  // E-posta/telefon değişikliği güvenlik açısından önemli: hassas alan izni
  // ve yeniden doğrulama gereksinimi (mustChangePassword benzeri işaret).
  const touchesSensitive = Boolean(input.email && input.email !== member.email) || Boolean(input.phone && input.phone !== member.phone);
  if (touchesSensitive && !hasPermission(user.role, "member:sensitive")) {
    return Response.json({ error: "İletişim bilgisi değişikliği için hassas alan izni gerekir." }, { status: 403 });
  }

  const updates: Record<string, unknown> = {};
  if (input.fullName) updates.fullName = input.fullName;
  if (input.phone !== undefined) updates.phone = input.phone || null;
  if (input.email) updates.email = input.email;
  // E-posta değiştiyse doğrulama düşer ve yeniden doğrulama istenir.
  if (input.email && input.email !== member.email) {
    updates.kvkkConsentAt = null;
    updates.mustChangePassword = true;
  }
  if (Object.keys(updates).length === 0) {
    return Response.json({ error: "Değiştirilecek alan yok" }, { status: 400 });
  }

  const ctxInfo = await requestContext();
  const [updated] = await db.update(users).set(updates).where(eq(users.id, id)).returning();

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "uye_guncellendi",
    entity: "user",
    entityId: String(id),
    reason: touchesSensitive ? "İletişim bilgisi düzeltmesi — yeniden doğrulama istendi" : "Profil düzeltmesi",
    oldData: { fullName: member.fullName, email: member.email, phone: member.phone },
    newData: { fullName: updated.fullName, email: updated.email, phone: updated.phone },
    ip: ctxInfo.ip,
    userAgent: ctxInfo.userAgent,
  });

  return Response.json({ ok: true, reverifyRequired: touchesSensitive });
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  // Kalıcı silme bilinçli olarak YOK: varsayılan arşivleme.
  return Response.json(
    {
      error: "Kalıcı silme desteklenmiyor. Üyeyi arşivleyin; KVKK silme talepleri veri saklama politikasına göre ayrıca işlenir.",
      hint: "POST /api/admin/members/[id]/actions {action:'archive', reason:'…'}",
    },
    { status: 405 },
  );
}

