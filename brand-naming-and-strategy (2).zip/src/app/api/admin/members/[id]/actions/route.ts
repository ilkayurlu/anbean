import crypto from "node:crypto";
import { z } from "zod";
import { db } from "@/db";
import { adminNotes, passwordResets, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { requirePermission, writeAudit, type Role } from "@/lib/auth";
import { ROLE_LABEL } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import { requestContext } from "@/lib/auditContext";
import { hashToken } from "@/lib/password";

export const dynamic = "force-dynamic";

const schema = z.object({
  action: z.enum(["activate", "deactivate", "ban", "unban", "archive", "unarchive", "change_role", "reset_password", "add_note"]),
  reason: z.string().trim().min(5, "Gerekçe en az 5 karakter").max(300),
  value: z.string().trim().max(120).optional(),
});

/** Yönetici parola sıfırlaması: bağlantı bir kez döner, ham token saklanmaz. */
function buildResetLink(userId: number): { token: string; link: string } {
  const token = `${userId}.${crypto.randomBytes(24).toString("base64url")}`;
  return { token, link: `/sifremi-unuttum?token=${token}` };
}

/**
 * Hesap durumu işlemleri.
 * - Her işlem GEREKÇE ister ve denetim kaydına eski/yeni değerle yazılır.
 * - Rol değişikliği yalnızca `member:manage` ile; kullanıcı kendi rolünü değiştiremez.
 * - Arşivleme varsayılandır; kalıcı silme bu uçta yoktur.
 */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("member:manage");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz işlem" }, { status: 400 });
  }
  const { action, reason, value } = parsed.data;

  const [member] = await db.select().from(users).where(eq(users.id, id)).limit(1);
  if (!member) return Response.json({ error: "Üye bulunamadı" }, { status: 404 });

  if (id === user.id && ["ban", "deactivate", "archive", "change_role"].includes(action)) {
    return Response.json({ error: "Bu işlemi kendi hesabına uygulayamazsın." }, { status: 409 });
  }
  // Yetki tırmanması: kimse kendi rolünü veya daha yüksek rolü hedefleyemez.
  if (action === "change_role") {
    const target = value as Role;
    if (!(target in ROLE_LABEL)) return Response.json({ error: "Geçersiz rol" }, { status: 400 });
    if (member.role === "super_admin" && user.role !== "super_admin") {
      return Response.json({ error: "Platform yöneticisinin rolünü yalnızca platform yöneticisi değiştirebilir." }, { status: 403 });
    }
    if (target === "super_admin" && user.role !== "super_admin") {
      const ctxEscalation = await requestContext();
      await writeAudit({
        actorId: user.id,
        actorRole: user.role,
        action: "yetki_tirmanmasi_denemesi",
        entity: "user",
        entityId: String(id),
        reason,
        oldData: { role: member.role },
        newData: { attemptedRole: target },
        ip: ctxEscalation.ip,
        userAgent: ctxEscalation.userAgent,
      });
      return Response.json({ error: "Platform yöneticisi rolünü yalnızca platform yöneticisi verebilir." }, { status: 403 });
    }
  }
  if (action === "reset_password" && !hasPermission(user.role, "member:reset_password")) {
    return Response.json({ error: "Parola sıfırlama yetkin yok." }, { status: 403 });
  }

  const context = await requestContext();
  const base = { actorId: user.id, actorRole: user.role, entity: "user", entityId: String(id), reason, ip: context.ip, userAgent: context.userAgent };

  if (action === "add_note") {
    await db.insert(adminNotes).values({ entityKind: "user", entityId: id, authorId: user.id, body: reason });
    await writeAudit({ ...base, action: "uye_notu_eklendi" });
    return Response.json({ ok: true });
  }

  if (action === "reset_password") {
    const { token, link } = buildResetLink(id);
    await db.insert(passwordResets).values({
      userId: id,
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + 30 * 60_000),
    });
    await db.update(users).set({ mustChangePassword: true }).where(eq(users.id, id));
    await writeAudit({ ...base, action: "yonetici_parola_sifirlama", oldData: {}, newData: { mustChangePassword: true } });
    // Bağlantı YALNIZCA bu yanıtta bir kez döner; tekrar gösterilmez.
    return Response.json({ ok: true, resetLink: link, expiresMinutes: 30 });
  }

  const updates: Record<string, unknown> = {};
  const oldData: Record<string, unknown> = {};
  const newData: Record<string, unknown> = {};

  switch (action) {
    case "activate":
      oldData.isActive = member.isActive;
      updates.isActive = true;
      newData.isActive = true;
      break;
    case "deactivate":
      oldData.isActive = member.isActive;
      updates.isActive = false;
      newData.isActive = false;
      break;
    case "ban":
      oldData.isBanned = member.isBanned;
      updates.isBanned = true;
      updates.isActive = false;
      newData.isBanned = true;
      break;
    case "unban":
      oldData.isBanned = member.isBanned;
      updates.isBanned = false;
      updates.isActive = true;
      newData.isBanned = false;
      break;
    case "archive":
      oldData.archivedAt = member.archivedAt;
      updates.archivedAt = new Date();
      updates.isActive = false;
      newData.archivedAt = "now";
      break;
    case "unarchive":
      oldData.archivedAt = member.archivedAt;
      oldData.isActive = member.isActive;
      updates.archivedAt = null;
      // Arşivleme isActive=false yapar; geri alma üyeyi yeniden giriş
      // yapabilir duruma döndürmeli, yoksa sessizce kilitli kalır.
      updates.isActive = true;
      newData.archivedAt = null;
      newData.isActive = true;
      break;
    case "change_role":
      oldData.role = member.role;
      updates.role = value;
      newData.role = value;
      break;
  }

  await db.update(users).set(updates).where(eq(users.id, id));
  await writeAudit({ ...base, action: `uye_${action}`, oldData, newData });

  return Response.json({ ok: true, action, oldData, newData });
}
