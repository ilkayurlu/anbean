import { z } from "zod";
import { db } from "@/db";
import { organizations, subscriptions, users } from "@/db/schema";
import { and, desc, eq, isNull, like, sql } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { requestContext } from "@/lib/auditContext";

export const dynamic = "force-dynamic";

const createSchema = z.object({
  name: z.string().trim().min(2).max(120),
  category: z.string().trim().max(60).optional(),
  contactEmail: z.string().trim().max(160).optional(),
  city: z.string().trim().max(60).optional(),
  district: z.string().trim().max(60).optional(),
  planCode: z.string().trim().max(40).optional(),
});

function slugify(value: string): string {
  const map: Record<string, string> = { ç: "c", ğ: "g", ı: "i", İ: "i", ö: "o", ş: "s", ü: "u", Ç: "c", Ö: "o", Ş: "s", Ü: "u", Ğ: "g" };
  return value
    .split("")
    .map((c) => map[c] ?? c)
    .join("")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60);
}

/** İşletme listesi. İşletme rolü yalnızca kendi tenant'ını görür. */
export async function GET(req: Request) {
  const user = await requirePermission("org:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const url = new URL(req.url);
  const q = (url.searchParams.get("q") ?? "").trim();
  const verification = url.searchParams.get("verification") ?? "";

  const conditions = [isNull(organizations.archivedAt)];
  if (q) conditions.push(like(organizations.name, `%${q}%`));
  if (verification) conditions.push(eq(organizations.verificationStatus, verification));
  if (user.role === "isletme_sahibi" || user.role === "isletme_calisani") {
    if (!user.orgId) return Response.json({ rows: [], scoped: true });
    conditions.push(eq(organizations.id, user.orgId));
  }

  const rows = await db
    .select()
    .from(organizations)
    .where(and(...conditions))
    .orderBy(desc(organizations.createdAt))
    .limit(200);

  const subs = await db.select().from(subscriptions);
  const counts = await db
    .select({ orgId: users.orgId, n: sql<number>`count(*)` })
    .from(users)
    .groupBy(users.orgId);
  const countByOrg = new Map(counts.map((c) => [c.orgId, Number(c.n ?? 0)]));

  return Response.json({
    scoped: user.role === "isletme_sahibi" || user.role === "isletme_calisani",
    rows: rows.map((row) => ({
      id: row.id,
      name: row.name,
      slug: row.slug,
      type: row.type,
      category: row.category,
      city: row.city,
      district: row.district,
      verificationStatus: row.verificationStatus,
      memberCount: countByOrg.get(row.id) ?? 0,
      subscriptionStatus: subs.find((s) => s.orgId === row.id)?.status ?? null,
    })),
  });
}

/** Yeni işletme (tenant) açar ve başlangıç aboneliğini bağlar. */
export async function POST(req: Request) {
  const user = await requirePermission("org:manage");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const parsed = createSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz işletme" }, { status: 400 });
  }
  const input = parsed.data;
  const slug = `${slugify(input.name)}-${Date.now().toString(36).slice(-4)}`;

  const [org] = await db
    .insert(organizations)
    .values({
      name: input.name,
      slug,
      type: "kurumsal",
      category: input.category ?? "",
      contactEmail: input.contactEmail ?? "",
      city: input.city ?? "",
      district: input.district ?? "",
      verificationStatus: "incelemede",
    })
    .returning();

  if (input.planCode) {
    const { plans } = await import("@/db/schema");
    const [plan] = await db.select().from(plans).where(eq(plans.code, input.planCode)).limit(1);
    if (plan) {
      await db.insert(subscriptions).values({
        orgId: org.id,
        planId: plan.id,
        status: "deneme",
        trialEndsAt: new Date(Date.now() + 14 * 86_400_000),
      });
    }
  }

  const ctx = await requestContext();
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "isletme_olusturuldu",
    entity: "organization",
    entityId: String(org.id),
    reason: "Yeni tenant kaydı",
    newData: { name: org.name, slug: org.slug, plan: input.planCode ?? "" },
    ip: ctx.ip,
    userAgent: ctx.userAgent,
  });

  return Response.json({ ok: true, id: org.id, slug: org.slug });
}
