import { z } from "zod";
import { db } from "@/db";
import { invoices, orgMembers, organizations, plans, shipments, subscriptions, users } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { requestContext } from "@/lib/auditContext";

export const dynamic = "force-dynamic";

const patchSchema = z.object({
  name: z.string().trim().min(2).max(120).optional(),
  description: z.string().trim().max(1200).optional(),
  category: z.string().trim().max(60).optional(),
  contactEmail: z.string().trim().max(160).optional(),
  contactPhone: z.string().trim().max(20).optional(),
  city: z.string().trim().max(60).optional(),
  district: z.string().trim().max(60).optional(),
  workingHours: z.record(z.string(), z.string()).optional(),
  verificationStatus: z.enum(["dogrulanmadi", "incelemede", "dogrulandi", "reddedildi"]).optional(),
});

async function loadOrg(id: number) {
  const [org] = await db.select().from(organizations).where(eq(organizations.id, id)).limit(1);
  return org ?? null;
}

/** İşletme dosyası: profil + üyeler + abonelik + faturalar + kullanım. */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("org:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const org = await loadOrg(id);
  if (!org) return Response.json({ error: "İşletme bulunamadı" }, { status: 404 });
  if ((user.role === "isletme_sahibi" || user.role === "isletme_calisani") && user.orgId !== org.id) {
    return Response.json({ error: "Yalnızca kendi işletmeni görebilirsin." }, { status: 403 });
  }

  const [members, subscriptionRows, invoiceRows, planRows, memberUsers] = await Promise.all([
    db.select().from(orgMembers).where(eq(orgMembers.orgId, id)),
    db.select().from(subscriptions).where(eq(subscriptions.orgId, id)).orderBy(desc(subscriptions.createdAt)).limit(1),
    db.select().from(invoices).where(eq(invoices.orgId, id)).orderBy(desc(invoices.createdAt)).limit(20),
    db.select().from(plans),
    db.select().from(users).where(eq(users.orgId, id)),
  ]);

  const subscription = subscriptionRows[0] ?? null;
  const plan = subscription ? (planRows.find((p) => p.id === subscription.planId) ?? null) : null;

  // Kullanım: dönem içindeki gönderi sayısı (limit aşımı takibi).
  const periodStart = subscription?.currentPeriodEnd
    ? new Date(new Date(subscription.currentPeriodEnd).getTime() - 30 * 86_400_000)
    : new Date(Date.now() - 30 * 86_400_000);
  const orgShipments = await db
    .select({ id: shipments.id, createdAt: shipments.createdAt })
    .from(shipments)
    .where(eq(shipments.orgId, id));
  const usedShipments = orgShipments.filter((s) => s.createdAt >= periodStart).length;

  return Response.json({
    org,
    members: members.map((m) => {
      const account = memberUsers.find((u) => u.id === m.userId);
      return {
        id: m.id,
        userId: m.userId,
        orgRole: m.orgRole,
        isActive: m.isActive,
        fullName: account?.fullName ?? "—",
        email: account ? `${account.email.slice(0, 2)}***@${account.email.split("@")[1] ?? ""}` : "",
      };
    }),
    subscription: subscription ? { ...subscription, plan } : null,
    usage: {
      shipmentsUsed: usedShipments,
      shipmentLimit: plan?.shipmentLimit ?? null,
      seatsUsed: memberUsers.length,
      seatLimit: plan?.seatLimit ?? null,
      overLimit: plan ? usedShipments > plan.shipmentLimit : false,
    },
    invoices: invoiceRows.map((invoice) => ({
      id: invoice.id,
      number: invoice.number,
      totalKurus: invoice.totalKurus,
      status: invoice.status,
      dueDate: invoice.dueDate,
      paidAt: invoice.paidAt,
      providerRef: invoice.providerRef,
      note: invoice.note,
    })),
    canManage: user.role === "admin" || user.role === "super_admin" || user.role === "ops" || user.role === "isletme_sahibi",
  });
}

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("org:manage");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const org = await loadOrg(id);
  if (!org) return Response.json({ error: "İşletme bulunamadı" }, { status: 404 });

  const parsed = patchSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz alan" }, { status: 400 });
  }
  const input = { ...parsed.data };

  // İşletme sahibi yalnızca KENDİ işletmesini ve doğrulama alanı DIŞINDA düzenleyebilir.
  if (user.role === "isletme_sahibi") {
    if (user.orgId !== org.id) return Response.json({ error: "Yalnızca kendi işletmeni düzenleyebilirsin." }, { status: 403 });
    delete input.verificationStatus;
  }
  if (Object.keys(input).length === 0) return Response.json({ error: "Değiştirilecek alan yok" }, { status: 400 });

  const before = { ...org };
  const [updated] = await db.update(organizations).set({ ...input, archivedAt: org.archivedAt }).where(eq(organizations.id, id)).returning();
  const ctxInfo = await requestContext();
  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "isletme_guncellendi",
    entity: "organization",
    entityId: String(id),
    reason: "İşletme dosyası düzenlendi",
    oldData: { name: before.name, verificationStatus: before.verificationStatus, contactEmail: before.contactEmail },
    newData: { name: updated.name, verificationStatus: updated.verificationStatus, contactEmail: updated.contactEmail },
    ip: ctxInfo.ip,
    userAgent: ctxInfo.userAgent,
  });

  return Response.json({ ok: true, org: updated });
}

/** Üye ekleme/çıkarma, plan değişikliği, fatura oluşturma, arşivleme. */
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const user = await requirePermission("org:manage");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const id = Number((await ctx.params).id);
  const org = await loadOrg(id);
  if (!org) return Response.json({ error: "İşletme bulunamadı" }, { status: 404 });

  const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
  const action = String(body.action ?? "");
  const reason = String(body.reason ?? "").trim();

  if (user.role === "isletme_sahibi" && user.orgId !== org.id) {
    return Response.json({ error: "Yalnızca kendi işletmende işlem yapabilirsin." }, { status: 403 });
  }
  const needsReason = ["archive", "change_plan", "create_invoice", "remove_member"].includes(action);
  if (needsReason && reason.length < 5) {
    return Response.json({ error: "Bu işlem için gerekçe zorunlu (en az 5 karakter)." }, { status: 400 });
  }

  const ctxInfo = await requestContext();
  const audit = (act: string, oldData = {}, newData = {}) =>
    writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: act,
      entity: "organization",
      entityId: String(id),
      reason,
      oldData,
      newData,
      ip: ctxInfo.ip,
      userAgent: ctxInfo.userAgent,
    });

  if (action === "archive") {
    await db.update(organizations).set({ archivedAt: new Date() }).where(eq(organizations.id, id));
    await audit("isletme_arsivlendi", { archived: false }, { archived: true });
    return Response.json({ ok: true });
  }

  if (action === "add_member" || action === "remove_member") {
    const targetEmail = String(body.email ?? "").trim().toLowerCase();
    const [account] = await db.select().from(users).where(eq(users.email, targetEmail)).limit(1);
    if (!account) return Response.json({ error: "Bu e-postayla kayıtlı kullanıcı yok." }, { status: 404 });
    if (action === "add_member") {
      const orgRole = ["sahip", "yonetici", "calisan"].includes(String(body.orgRole)) ? String(body.orgRole) : "calisan";
      await db
        .insert(orgMembers)
        .values({ orgId: id, userId: account.id, orgRole })
        .onConflictDoNothing();
      await db.update(users).set({ orgId: id }).where(eq(users.id, account.id));
      await audit("isletme_uyesi_eklendi", {}, { email: targetEmail, orgRole });
      return Response.json({ ok: true });
    }
    // Yalnızca hedef üye çıkarılır; toplu silme yok.
    await db.delete(orgMembers).where(and(eq(orgMembers.orgId, id), eq(orgMembers.userId, account.id)));
    await audit("isletme_uyesi_cikarildi", { email: targetEmail }, {});
    return Response.json({ ok: true });
  }

  if (action === "change_plan") {
    const planCode = String(body.planCode ?? "");
    const [plan] = await db.select().from(plans).where(eq(plans.code, planCode)).limit(1);
    if (!plan) return Response.json({ error: "Plan bulunamadı" }, { status: 404 });
    const [current] = await db.select().from(subscriptions).where(eq(subscriptions.orgId, id)).orderBy(desc(subscriptions.createdAt)).limit(1);
    if (current) {
      await db
        .update(subscriptions)
        .set({ planId: plan.id, status: "aktif", currentPeriodEnd: new Date(Date.now() + 30 * 86_400_000) })
        .where(eq(subscriptions.id, current.id));
      await audit("abonelik_plani_degisti", { planId: current.planId }, { planId: plan.id, planCode });
    } else {
      await db.insert(subscriptions).values({ orgId: id, planId: plan.id, status: "aktif", currentPeriodEnd: new Date(Date.now() + 30 * 86_400_000) });
      await audit("abonelik_olusturuldu", {}, { planCode });
    }
    return Response.json({ ok: true });
  }

  if (action === "create_invoice") {
    const [subscription] = await db.select().from(subscriptions).where(eq(subscriptions.orgId, id)).orderBy(desc(subscriptions.createdAt)).limit(1);
    const [plan] = subscription ? await db.select().from(plans).where(eq(plans.id, subscription.planId)).limit(1) : [];
    if (!plan) return Response.json({ error: "Abonelik/plan bulunamadı" }, { status: 409 });
    const amount = plan.monthlyKurus;
    const tax = Math.round(amount * 0.2);
    const number = `FTR-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
    const [invoice] = await db
      .insert(invoices)
      .values({
        number,
        orgId: id,
        subscriptionId: subscription?.id ?? null,
        amountKurus: amount,
        taxKurus: tax,
        totalKurus: amount + tax,
        status: "gonderildi",
        dueDate: new Date(Date.now() + 7 * 86_400_000),
        note: reason,
      })
      .returning();
    await audit("fatura_olusturuldu", {}, { number, totalKurus: invoice.totalKurus });
    return Response.json({ ok: true, invoice });
  }

  return Response.json({ error: "Geçersiz işlem" }, { status: 400 });
}
