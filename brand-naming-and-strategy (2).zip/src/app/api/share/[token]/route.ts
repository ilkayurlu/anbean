import { headers } from "next/headers";
import { db } from "@/db";
import {
  chauffeurProfiles,
  chauffeurVehicles,
  passengerRideRequests,
  passengerRides,
  rideShareSessions,
} from "@/db/schema";
import { and, eq, isNull } from "drizzle-orm";
import { rateLimit } from "@/lib/auth";
import { RIDE_STATUS_LABEL, type RideStatus } from "@/lib/hail";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Yaklaşık konum: ~500 m ızgaraya yuvarlanır, kesin konum paylaşılmaz. */
function coarsen(value: number | null): number | null {
  if (value === null) return null;
  return Math.round(value * 200) / 200;
}

/**
 * Güvenilen kişi görünümü.
 * Paylaşılır: araç plakası, sürücünün adı (soyadsız), yaklaşık konum, durum,
 * acil durum bağlantısı.
 * Paylaşılmaz: yolcu telefonu, tam adres, ödeme bilgisi, ücret.
 */
export async function GET(_req: Request, ctx: { params: Promise<{ token: string }> }) {
  const { token } = await ctx.params;
  const head = await headers();
  const ip = head.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (!rateLimit(`share:${ip}`, 60, 60_000)) {
    return Response.json({ error: "Çok fazla istek" }, { status: 429 });
  }
  if (token.length < 20 || token.length > 64) {
    return Response.json({ error: "Geçersiz bağlantı" }, { status: 400 });
  }

  const [session] = await db
    .select()
    .from(rideShareSessions)
    .where(and(eq(rideShareSessions.token, token), isNull(rideShareSessions.revokedAt)))
    .limit(1);
  if (!session || session.expiresAt.getTime() < Date.now()) {
    return Response.json({ error: "Bağlantı geçersiz veya süresi dolmuş" }, { status: 404 });
  }

  const [ride] = await db.select().from(passengerRides).where(eq(passengerRides.id, session.rideId)).limit(1);
  if (!ride) return Response.json({ error: "Yolculuk bulunamadı" }, { status: 404 });

  await db
    .update(rideShareSessions)
    .set({ hitCount: sql`${rideShareSessions.hitCount} + 1`, lastHitAt: new Date() })
    .where(eq(rideShareSessions.id, session.id));

  // Yolculuk bittiyse paylaşım otomatik kapanır.
  const finished = ["COMPLETED", "CANCELLED_BY_PASSENGER", "CANCELLED_BY_DRIVER", "DRIVER_NO_SHOW"].includes(ride.status);
  if (finished && !session.revokedAt) {
    await db.update(rideShareSessions).set({ revokedAt: new Date() }).where(eq(rideShareSessions.id, session.id));
  }
  if (finished) {
    return Response.json({
      closed: true,
      message: "Yolculuk sona erdi; canlı paylaşım kapatıldı.",
      status: RIDE_STATUS_LABEL[ride.status as RideStatus] ?? ride.status,
    });
  }

  const [request] = await db
    .select()
    .from(passengerRideRequests)
    .where(eq(passengerRideRequests.id, ride.requestId))
    .limit(1);
  const [profile] = ride.chauffeurId
    ? await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.id, ride.chauffeurId)).limit(1)
    : [];
  const [vehicle] = ride.vehicleId
    ? await db.select().from(chauffeurVehicles).where(eq(chauffeurVehicles.id, ride.vehicleId)).limit(1)
    : [];

  return Response.json({
    closed: false,
    rideCode: ride.code,
    status: ride.status,
    statusLabel: RIDE_STATUS_LABEL[ride.status as RideStatus] ?? ride.status,
    chauffeur: profile ? { firstName: profile.fullName.split(" ")[0], isDemo: profile.isDemo } : null,
    vehicle: vehicle
      ? { plate: vehicle.plate, make: vehicle.make, model: vehicle.model, color: vehicle.color }
      : null,
    // Yalnızca ilçe + yaklaşık konum: tam adres ve telefon YOK.
    area: { pickupDistrict: request?.pickupDistrict ?? "", dropDistrict: request?.dropDistrict ?? "" },
    approximateLocation: {
      lat: coarsen(profile?.lastLat ?? null),
      lng: coarsen(profile?.lastLng ?? null),
      precision: "~500 m",
    },
    emergency: {
      police: "112",
      reportUrl: "/yardim",
      note: "Acil durumda önce 112'yi arayın, ardından platforma güvenlik olayı bildirin.",
    },
    expiresAt: session.expiresAt,
  });
}
