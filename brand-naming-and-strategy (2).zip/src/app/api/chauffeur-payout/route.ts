import { z } from "zod";
import { db } from "@/db";
import { chauffeurProfiles, chauffeurPayouts, wallets } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import { ensureWallet, postLedger } from "@/lib/ledger";

export const dynamic = "force-dynamic";

const MIN_KURUS = 10_000;
/** Bu tutarın üstündeki çıkışlar iki onay ister (maker-checker + eşik). */
export const DOUBLE_APPROVAL_THRESHOLD_KURUS = 500_000;

const schema = z.object({
  amountKurus: z.number().int().min(MIN_KURUS, "En az 100 TL talep edilebilir"),
  iban: z.string().trim().regex(/^TR\d{2}[\s\d]{16,22}$/, "Geçerli bir TR IBAN girin"),
});

function maskIban(iban: string) {
  const d = iban.replace(/\s/g, "");
  return `${d.slice(0, 6)}****${d.slice(-4)}`;
}

export async function GET() {
  const user = await requirePermission("chauffeur:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const canSeeAll = hasPermission(user.role, "finance:read");
  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);

  const rows = canSeeAll
    ? await db.select().from(chauffeurPayouts).orderBy(desc(chauffeurPayouts.createdAt)).limit(100)
    : profile
      ? await db
          .select()
          .from(chauffeurPayouts)
          .where(eq(chauffeurPayouts.chauffeurId, profile.id))
          .orderBy(desc(chauffeurPayouts.createdAt))
      : [];

  return Response.json({ requests: rows, doubleApprovalThresholdKurus: DOUBLE_APPROVAL_THRESHOLD_KURUS });
}

export async function POST(req: Request) {
  const user = await requirePermission("chauffeur:payout:request");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);
  if (!profile) return Response.json({ error: "Sürücü profili bulunamadı" }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz talep" }, { status: 400 });
  }

  const wallet = await ensureWallet("chauffeur", profile.id);
  if (wallet.balanceKurus < parsed.data.amountKurus) {
    return Response.json({ error: "Talep tutarı hakediş bakiyesinden yüksek." }, { status: 409 });
  }
  const pending = await db
    .select()
    .from(chauffeurPayouts)
    .where(and(eq(chauffeurPayouts.chauffeurId, profile.id), eq(chauffeurPayouts.status, "beklemede")));
  if (pending.length > 0) return Response.json({ error: "Bekleyen bir talebin zaten var." }, { status: 409 });

  const [row] = await db
    .insert(chauffeurPayouts)
    .values({
      code: `SPAY-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`,
      chauffeurId: profile.id,
      amountKurus: parsed.data.amountKurus,
      ibanMasked: maskIban(parsed.data.iban),
      requestedByUserId: user.id,
    })
    .returning();

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "surucu_hakedis_talebi",
    entity: "chauffeur_payout",
    entityId: String(row.id),
    meta: { amountKurus: row.amountKurus, needsDoubleApproval: row.amountKurus > DOUBLE_APPROVAL_THRESHOLD_KURUS },
  });

  return Response.json({
    ok: true,
    code: row.code,
    id: row.id,
    needsDoubleApproval: row.amountKurus > DOUBLE_APPROVAL_THRESHOLD_KURUS,
  });
}

/** Finans/admin ödemesi — maker-checker ve eşik üstü çift onay. */
export async function PATCH(req: Request) {
  const user = await requirePermission("finance:payout");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const body = (await req.json().catch(() => ({}))) as { id?: number; action?: string };
  const id = Number(body.id);
  const action = String(body.action ?? "");
  if (!Number.isFinite(id) || !["onayla", "reddet", "ode"].includes(action)) {
    return Response.json({ error: "Geçersiz işlem" }, { status: 400 });
  }

  const [request] = await db.select().from(chauffeurPayouts).where(eq(chauffeurPayouts.id, id)).limit(1);
  if (!request) return Response.json({ error: "Talep bulunamadı" }, { status: 404 });
  if (request.requestedByUserId === user.id) {
    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: "maker_checker_ihlali_denemesi",
      entity: "chauffeur_payout",
      entityId: String(id),
    });
    return Response.json({ error: "Kendi talebini onaylayamaz veya ödeyemezsin." }, { status: 403 });
  }

  if (action === "ode") {
    if (request.status !== "onaylandi") {
      return Response.json({ error: "Yalnızca onaylanmış talep ödenebilir." }, { status: 409 });
    }
    const driverWallet = await ensureWallet("chauffeur", request.chauffeurId);
    const [systemWallet] = await db.select().from(wallets).where(eq(wallets.ownerKind, "system")).limit(1);
    if (!systemWallet) return Response.json({ error: "Platform hesabı bulunamadı" }, { status: 500 });

    try {
      const { txId } = await postLedger({
        kind: "payout",
        idempotencyKey: `chauffeur_payout_${request.id}_ode`,
        refKind: "chauffeur_payout",
        refId: request.id,
        note: `${request.code} · sürücü hakediş çıkışı`,
        postings: [
          { walletId: driverWallet.id, side: "debit", amountKurus: request.amountKurus, reason: "surucu_hakedis_cikisi" },
          { walletId: systemWallet.id, side: "credit", amountKurus: request.amountKurus, reason: "surucu_hakedis_odendi" },
        ],
      });
      await db
        .update(chauffeurPayouts)
        .set({ status: "odendi", approvedByUserId: user.id, ledgerTxId: txId, decidedAt: new Date() })
        .where(eq(chauffeurPayouts.id, id));
    } catch (err) {
      return Response.json({ error: err instanceof Error ? err.message : "Ödeme yazılamadı" }, { status: 409 });
    }
  } else {
    const expected = action === "onayla" ? "beklemede" : "beklemede";
    if (request.status !== expected) {
      return Response.json({ error: `Bu talep ${request.status} durumunda.` }, { status: 409 });
    }
    await db
      .update(chauffeurPayouts)
      .set({
        status: action === "onayla" ? "onaylandi" : "reddedildi",
        approvedByUserId: user.id,
        decidedAt: new Date(),
      })
      .where(eq(chauffeurPayouts.id, id));
  }

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: `surucu_hakedis_${action}`,
    entity: "chauffeur_payout",
    entityId: String(id),
    meta: { amountKurus: request.amountKurus },
  });

  return Response.json({ ok: true });
}
