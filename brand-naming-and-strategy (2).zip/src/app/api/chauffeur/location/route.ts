import { headers } from "next/headers";
import { z } from "zod";
import { db } from "@/db";
import { chauffeurProfiles, passengerRides } from "@/db/schema";
import { and, eq, inArray } from "drizzle-orm";
import { rateLimit, requirePermission, writeAudit } from "@/lib/auth";

export const dynamic = "force-dynamic";

const schema = z.object({ lat: z.number().min(-90).max(90), lng: z.number().min(-180).max(180) });

/**
 * Sürücü konumu — KVKK sınırına uygun.
 * Konum YALNIZCA çevrimiçi ve atanmış aktif yolculuk varken kabul edilir.
 * Yolculuk bittiğinde ham konum toplanmaz (amaçla sınırlı saklama).
 */
export async function POST(req: Request) {
  const user = await requirePermission("hail:drive");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const head = await headers();
  const ip = head.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "local";
  if (!rateLimit(`chauffeur-loc:${user.id}`, 60, 60_000)) {
    return Response.json({ error: "Konum isteği sınırı aşıldı." }, { status: 429 });
  }

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Geçersiz koordinat" }, { status: 400 });

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);
  if (!profile) return Response.json({ error: "Sürücü profili bulunamadı" }, { status: 403 });

  const activeRides = await db
    .select({ id: passengerRides.id })
    .from(passengerRides)
    .where(
      and(
        eq(passengerRides.chauffeurId, profile.id),
        inArray(passengerRides.status, ["DRIVER_ASSIGNED", "DRIVER_EN_ROUTE", "DRIVER_ARRIVED", "IN_PROGRESS"]),
      ),
    )
    .limit(1);

  if (profile.availability === "offline" || activeRides.length === 0) {
    await writeAudit({
      actorId: user.id,
      actorRole: user.role,
      action: "surucu_konum_reddedildi",
      entity: "chauffeur_profile",
      entityId: String(profile.id),
      meta: { reason: activeRides.length === 0 ? "aktif_yolculuk_yok" : "cevrimdisi" },
    });
    return Response.json({ error: "Aktif yolculuğunuz yokken konum gönderilemez." }, { status: 403 });
  }

  await db
    .update(chauffeurProfiles)
    .set({ lastLat: parsed.data.lat, lastLng: parsed.data.lng, lastLocationAt: new Date() })
    .where(eq(chauffeurProfiles.id, profile.id));

  return Response.json({ ok: true });
}
