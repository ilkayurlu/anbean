import { z } from "zod";
import { db } from "@/db";
import { chauffeurDocuments, chauffeurProfiles } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { CHAUFFEUR_SERVICE_GATE, REQUIRED_COMMERCIAL_DOCS } from "@/lib/hail";

export const dynamic = "force-dynamic";

const schema = z.object({ availability: z.enum(["offline", "online_idle"]) });

/**
 * Çevrimiçi/çevrimdışı.
 * Belgesi eksik veya süresi dolmuş sürücü ÇEVRİMİÇİ OLAMAZ — teklif alamaz.
 */
export async function POST(req: Request) {
  const user = await requirePermission("hail:offer");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) return Response.json({ error: "Geçersiz durum" }, { status: 400 });

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);
  if (!profile) return Response.json({ error: "Sürücü profili bulunamadı" }, { status: 403 });

  if (parsed.data.availability === "online_idle") {
    if (!CHAUFFEUR_SERVICE_GATE.live) {
      return Response.json(
        {
          error: "Sürücülü yolculuk hizmeti henüz canlı değil (hukuk onayı bekliyor). Çevrimiçi durum pilot/demo modunda açılır.",
          pilotMode: true,
        },
        { status: 409 },
      );
    }
    if (profile.suspendedUntil && profile.suspendedUntil.getTime() > Date.now()) {
      return Response.json({ error: `Hesabınız askıda: ${profile.suspensionReason}` }, { status: 403 });
    }
    if (!profile.isVerified || !profile.commercialDocsVerified) {
      return Response.json({ error: "Ticari yolcu taşıma belgeleriniz doğrulanmadı." }, { status: 403 });
    }

    const docs = await db.select().from(chauffeurDocuments).where(eq(chauffeurDocuments.chauffeurId, profile.id));
    const expired = docs.filter(
      (d) => (REQUIRED_COMMERCIAL_DOCS as readonly string[]).includes(d.docType) && d.expiresAt !== null && d.expiresAt.getTime() < Date.now(),
    );
    if (expired.length > 0) {
      await db
        .update(chauffeurDocuments)
        .set({ status: "expired" })
        .where(and(eq(chauffeurDocuments.chauffeurId, profile.id), eq(chauffeurDocuments.id, expired[0].id)));
      return Response.json(
        { error: `Belgesi dolmuş: ${expired.map((d) => d.docType).join(", ")}. Çevrimiçi olamazsınız.` },
        { status: 409 },
      );
    }
  }

  await db
    .update(chauffeurProfiles)
    .set({
      availability: profile.availability === "on_trip" ? "on_trip" : parsed.data.availability,
      lastOnlineAt: parsed.data.availability === "online_idle" ? new Date() : profile.lastOnlineAt,
    })
    .where(eq(chauffeurProfiles.id, profile.id));

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "surucu_durum_degistirdi",
    entity: "chauffeur_profile",
    entityId: String(profile.id),
    meta: { availability: parsed.data.availability },
  });

  return Response.json({ ok: true, availability: parsed.data.availability });
}
