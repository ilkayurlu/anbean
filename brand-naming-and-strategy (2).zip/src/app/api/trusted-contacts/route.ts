import { z } from "zod";
import { db } from "@/db";
import { trustedContacts } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requireAuth, writeAudit } from "@/lib/auth";
import { hashToken } from "@/lib/password";

export const dynamic = "force-dynamic";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  phone: z
    .string()
    .trim()
    .regex(/^[\d+\s()-]{10,20}$/, "Geçerli bir telefon girin"),
});

function maskPhone(phone: string) {
  const d = phone.replace(/\D/g, "");
  return d.length < 6 ? "***" : `${d.slice(0, 3)}*****${d.slice(-2)}`;
}

/** Güvenilen kişi. Telefon düz metin saklanmaz; yalnızca özet ve maske. */
export async function POST(req: Request) {
  const user = await requireAuth();
  if (!user) return Response.json({ error: "Oturum gerekli" }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz kişi" }, { status: 400 });
  }

  const existing = await db.select().from(trustedContacts).where(eq(trustedContacts.userId, user.id));
  if (existing.length >= 5) {
    return Response.json({ error: "En fazla 5 güvenilen kişi ekleyebilirsin." }, { status: 409 });
  }
  const phoneHash = hashToken(parsed.data.phone.replace(/\D/g, ""));
  if (existing.some((c) => c.phoneHash === phoneHash)) {
    return Response.json({ error: "Bu telefon zaten kayıtlı." }, { status: 409 });
  }

  const [row] = await db
    .insert(trustedContacts)
    .values({
      userId: user.id,
      name: parsed.data.name,
      phoneHash,
      phoneMasked: maskPhone(parsed.data.phone),
    })
    .returning();

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "guvenilen_kisi_eklendi",
    entity: "trusted_contact",
    entityId: String(row.id),
  });

  return Response.json({ ok: true, id: row.id, name: row.name, phoneMasked: row.phoneMasked });
}

export async function GET() {
  const user = await requireAuth();
  if (!user) return Response.json({ error: "Oturum gerekli" }, { status: 401 });
  const rows = await db
    .select({
      id: trustedContacts.id,
      name: trustedContacts.name,
      phoneMasked: trustedContacts.phoneMasked,
      createdAt: trustedContacts.createdAt,
    })
    .from(trustedContacts)
    .where(eq(trustedContacts.userId, user.id))
    .orderBy(desc(trustedContacts.createdAt));
  return Response.json({ contacts: rows });
}

export async function DELETE(req: Request) {
  const user = await requireAuth();
  if (!user) return Response.json({ error: "Oturum gerekli" }, { status: 401 });
  const url = new URL(req.url);
  const id = Number(url.searchParams.get("id"));
  if (!Number.isFinite(id)) return Response.json({ error: "Geçersiz kayıt" }, { status: 400 });

  const deleted = await db
    .delete(trustedContacts)
    .where(eq(trustedContacts.id, id))
    .returning({ id: trustedContacts.id, userId: trustedContacts.userId });
  if (deleted.length === 0 || deleted[0].userId !== user.id) {
    return Response.json({ error: "Kayıt bulunamadı" }, { status: 404 });
  }

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "guvenilen_kisi_silindi",
    entity: "trusted_contact",
    entityId: String(id),
  });
  return Response.json({ ok: true });
}
