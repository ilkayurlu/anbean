import { z } from "zod";
import { db } from "@/db";
import { chauffeurProfiles, passengerRideRequests, passengerRides, safetyIncidents } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { requirePermission, writeAudit } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import { logRideEvent } from "@/lib/hail";

export const dynamic = "force-dynamic";

const INCIDENT_TYPES = ["harassment", "accident", "route_issue", "wrong_vehicle", "no_show", "other"] as const;

const createSchema = z.object({
  rideId: z.number().int().positive().optional(),
  incidentType: z.enum(INCIDENT_TYPES),
  description: z.string().trim().max(1000).optional(),
  severity: z.enum(["low", "medium", "high", "critical"]).optional(),
  emergencyCallMade: z.boolean().optional(),
});

/**
 * Güvenlik olayı.
 * Kritik olaylarda sürücü geçici olarak askıya alınır ve yolculuk
 * SAFETY_INCIDENT durumuna geçer. Kayıt append-only olay zincirine yazılır.
 */
export async function POST(req: Request) {
  const user = await requirePermission("safety:report");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const parsed = createSchema.safeParse(await req.json().catch(() => ({})));
  if (!parsed.success) {
    return Response.json({ error: parsed.error.issues[0]?.message ?? "Geçersiz bildirim" }, { status: 400 });
  }
  const input = parsed.data;

  let ride = null as (typeof passengerRides.$inferSelect) | null;
  if (input.rideId) {
    const [row] = await db.select().from(passengerRides).where(eq(passengerRides.id, input.rideId)).limit(1);
    if (!row) return Response.json({ error: "Yolculuk bulunamadı" }, { status: 404 });
    const [request] = await db
      .select()
      .from(passengerRideRequests)
      .where(eq(passengerRideRequests.id, row.requestId))
      .limit(1);
    const [profile] = row.chauffeurId
      ? await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.id, row.chauffeurId)).limit(1)
      : [];
    const isParty = request?.customerId === user.id || profile?.userId === user.id;
    if (!isParty && user.role !== "admin" && user.role !== "ops") {
      return Response.json({ error: "Bu yolculukla ilişkiniz yok" }, { status: 403 });
    }
    ride = row;
  }

  const severity =
    input.severity ?? (input.incidentType === "harassment" || input.incidentType === "accident" ? "critical" : "medium");

  const code = `GUV-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`;
  const [incident] = await db
    .insert(safetyIncidents)
    .values({
      code,
      rideId: ride?.id ?? null,
      reportedByUserId: user.id,
      reportedByRole: user.role,
      incidentType: input.incidentType,
      description: (input.description ?? "").slice(0, 1000),
      severity,
      emergencyCallMade: Boolean(input.emergencyCallMade),
      status: severity === "critical" ? "assigned" : "open",
    })
    .returning();

  if (ride) {
    await logRideEvent({
      rideId: ride.id,
      eventType: "SAFETY_INCIDENT",
      actor: user.role,
      note: `${input.incidentType} · ${severity}`,
    });
    if (!["COMPLETED", "CANCELLED_BY_PASSENGER", "CANCELLED_BY_DRIVER"].includes(ride.status)) {
      await db.update(passengerRides).set({ status: "SAFETY_INCIDENT" }).where(eq(passengerRides.id, ride.id));
    }

    // Kritik olay: sürücü inceleme süresince askıya alınır (24 saat).
    if (severity === "critical" && ride.chauffeurId) {
      await db
        .update(chauffeurProfiles)
        .set({
          availability: "offline",
          suspendedUntil: new Date(Date.now() + 24 * 60 * 60_000),
          suspensionReason: `Güvenlik olayı ${code} incelemesi`,
        })
        .where(eq(chauffeurProfiles.id, ride.chauffeurId));
    }
  }

  await writeAudit({
    actorId: user.id,
    actorRole: user.role,
    action: "guvenlik_olayi_bildirildi",
    entity: "safety_incident",
    entityId: String(incident.id),
    meta: { incidentType: input.incidentType, severity, emergencyCallMade: Boolean(input.emergencyCallMade) },
  });

  return Response.json({
    ok: true,
    code,
    severity,
    emergency: severity === "critical" || input.emergencyCallMade,
    message:
      severity === "critical"
        ? "Bildirim kritik olarak işlendi. Acil durumda 112'yi arayın; sürücü incelemeye alındı."
        : "Bildirim alındı. Güvenlik ekibi inceleyecek.",
  });
}

export async function GET() {
  const user = await requirePermission("safety:read");
  if (!user) return Response.json({ error: "Yetkisiz" }, { status: 403 });

  const canManage = hasPermission(user.role, "safety:manage");
  const rows = canManage
    ? await db.select().from(safetyIncidents).orderBy(desc(safetyIncidents.reportedAt)).limit(100)
    : await db
        .select()
        .from(safetyIncidents)
        .where(eq(safetyIncidents.reportedByUserId, user.id))
        .orderBy(desc(safetyIncidents.reportedAt));

  return Response.json({ canManage, incidents: rows });
}
