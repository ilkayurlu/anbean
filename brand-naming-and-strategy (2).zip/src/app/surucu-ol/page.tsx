import PageShell from "@/components/PageShell";
import ChauffeurApplyForm from "@/components/ChauffeurApplyForm";
import Reveal from "@/components/Reveal";
import { REQUIRED_COMMERCIAL_DOCS } from "@/lib/hail";

export const metadata = {
  title: "Sürücü ol — Anbean",
  description:
    "Sürücülü yolculuk için başvuru. Ticari yolcu taşıma belgeleri doğrulanmadan sürücü çevrimiçi olamaz.",
};

const DOC_LABEL: Record<string, string> = {
  identity: "Kimlik",
  driver_license: "Ehliyet",
  vehicle_registration: "Araç ruhsatı",
  insurance: "Sigorta",
  criminal_record: "Adli sicil kaydı",
  commercial_license: "Ticari yolcu taşıma belgesi",
};

export default function SurucuOlPage() {
  return (
    <PageShell
      eyebrow="Sürücü kazanımı"
      title="Şehrin yollarında kazan"
      lead="Sürücü başvurusu kurye başvurusundan ayrıdır: taşınan şey yolcudur, belge ve sorumluluk rejimi farklıdır. Aynı kişi ikisine de başvurabilir."
    >
      <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <ChauffeurApplyForm />

        <div className="space-y-5">
          <Reveal>
            <div className="rounded-lg border border-white/10 bg-white/3 p-6">
              <h2 className="font-display text-lg font-semibold text-white">Zorunlu belgeler</h2>
              <ul className="mt-4 space-y-2 text-sm text-slate-300">
                {(REQUIRED_COMMERCIAL_DOCS as readonly string[]).map((type) => (
                  <li key={type} className="flex gap-3">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-accent" />
                    {DOC_LABEL[type] ?? type}
                  </li>
                ))}
              </ul>
              <p className="mt-4 text-xs text-slate-500">
                Belgelerin TAMAMI doğrulanmadan çevrimiçi olamaz ve teklif alamazsın. Süresi dolan belge de aynı
                etkiyi yaratır.
              </p>
            </div>
          </Reveal>

          <Reveal delay={0.05}>
            <div className="rounded-lg border border-st-waiting/35 bg-st-waiting/8 p-6">
              <h2 className="font-display text-lg font-semibold text-white">Pilot durumu</h2>
              <p className="mt-2 text-sm text-slate-300">
                Sürücülü yolculuk hizmeti hukuk onayı bekliyor. Başvurular alınır ve değerlendirilir; canlı yolcu
                taşıma, ticari taşımacılık belge rejimi netleşmeden başlamaz.
              </p>
              <p className="mt-3 text-xs text-slate-400">
                Dosya depolama sağlayıcısı bağlı olmadığı için bu sürümde belge yüklenemez; başvuru kaydı açılır ve
                belge onayı operasyon tarafından meta veri üzerinden işlenir.
              </p>
            </div>
          </Reveal>

          <Reveal delay={0.1}>
            <div className="rounded-lg border border-white/10 bg-white/3 p-6">
              <h2 className="font-display text-lg font-semibold text-white">Kazanç nasıl işler?</h2>
              <ul className="mt-3 space-y-2 text-sm text-slate-400">
                <li>· Yolculuk kapanınca ücret sunucuda yeniden hesaplanır.</li>
                <li>· Komisyon düşülür, net tutar anında hakediş bakiyene geçer.</li>
                <li>· Para çekme talebi maker-checker ile onaylanır.</li>
                <li>· Kayıtlar çift taraflıdır ve silinemez.</li>
              </ul>
            </div>
          </Reveal>
        </div>
      </div>
    </PageShell>
  );
}
