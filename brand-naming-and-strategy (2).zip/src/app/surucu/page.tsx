import Link from "next/link";
import { redirect } from "next/navigation";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { chauffeurDocuments, chauffeurProfiles, chauffeurVehicles, ledgerEntries, passengerRides, wallets } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { CHAUFFEUR_SERVICE_GATE, REQUIRED_COMMERCIAL_DOCS } from "@/lib/hail";
import { ensureWallet } from "@/lib/ledger";
import { formatTry } from "@/lib/pricing";
import { STATUS_COLOR } from "@/lib/status";
import PanelShell, { Card, Metric } from "@/components/PanelShell";
import DriverActions from "@/components/DriverActions";

export const dynamic = "force-dynamic";
export const metadata = { title: "Sürücü paneli — Anbean" };

const DOC_LABEL: Record<string, string> = {
  identity: "Kimlik",
  driver_license: "Ehliyet",
  vehicle_registration: "Araç ruhsatı",
  insurance: "Sigorta",
  criminal_record: "Adli sicil",
  commercial_license: "Ticari taşıma belgesi",
};

export default async function SurucuPanel() {
  const user = await requirePermission("hail:offer");
  if (!user) redirect("/giris");

  const [profile] = await db.select().from(chauffeurProfiles).where(eq(chauffeurProfiles.userId, user.id)).limit(1);
  if (!profile) redirect("/surucu-ol");

  const [documents, vehicles, activeRides] = await Promise.all([
    db.select().from(chauffeurDocuments).where(eq(chauffeurDocuments.chauffeurId, profile.id)),
    db.select().from(chauffeurVehicles).where(eq(chauffeurVehicles.chauffeurId, profile.id)),
    db
      .select()
      .from(passengerRides)
      .where(
        and(
          eq(passengerRides.chauffeurId, profile.id),
          eq(passengerRides.status, "DRIVER_ASSIGNED"),
        ),
      )
      .limit(5),
  ]);

  const wallet = await ensureWallet("chauffeur", profile.id);
  const entries = await db
    .select()
    .from(ledgerEntries)
    .where(eq(ledgerEntries.walletId, wallet.id))
    .orderBy(desc(ledgerEntries.createdAt))
    .limit(15);

  const approvedDocs = (REQUIRED_COMMERCIAL_DOCS as readonly string[]).filter((type) =>
    documents.some((d) => d.docType === type && d.status === "approved"),
  );
  const rating = profile.ratingCount > 0 ? profile.ratingSum / profile.ratingCount : null;
  const totalOffers = profile.acceptedOffers + profile.declinedOffers;
  const acceptanceRate = totalOffers > 0 ? Math.round((profile.acceptedOffers / totalOffers) * 100) : null;
  const todayEarnings = entries
    .filter((e) => e.side === "credit" && new Date(e.createdAt).toDateString() === new Date().toDateString())
    .reduce((sum, e) => sum + e.amountKurus, 0);

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Sürücü paneli"
      subtitle={`${profile.city} · ${profile.status} · doğrulama: ${profile.verificationLevel}`}
      nav={[
        { href: "/surucu", label: "Panel" },
        { href: "/app/yolculuk", label: "Yolculuklar" },
        { href: "/app/cuzdan", label: "Hakediş" },
      ]}
    >
      {!CHAUFFEUR_SERVICE_GATE.live ? (
        <div className="mb-5 rounded-lg border border-st-waiting/40 bg-st-waiting/10 p-4 text-sm text-slate-700">
          <strong>Pilot mod:</strong> {CHAUFFEUR_SERVICE_GATE.label}. Talep ve teklif akışı çalışır; canlı ticari
          yolcu taşıma yapılmaz. Çevrimiçi olma isteği yayın kapısıyla reddedilir.
        </div>
      ) : null}

      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="Bugünkü hakediş" value={formatTry(todayEarnings)} tone={STATUS_COLOR.delivered} />
        <Metric label="Bakiye" value={formatTry(wallet.balanceKurus)} />
        <Metric label="Toplam yolculuk" value={String(profile.totalTrips)} />
        <Metric
          label="Kabul oranı"
          value={acceptanceRate === null ? "veri yok" : `%${acceptanceRate}`}
          tone={STATUS_COLOR.transit}
        />
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <DriverActions
          availability={profile.availability}
          verified={profile.isVerified && profile.commercialDocsVerified}
          pilotBlocked={!CHAUFFEUR_SERVICE_GATE.live}
        />

        <div className="space-y-5">
          <Card title={`Belgeler · ${approvedDocs.length}/${REQUIRED_COMMERCIAL_DOCS.length} onaylı`}>
            <ul className="divide-y divide-slate-100 text-sm">
              {(REQUIRED_COMMERCIAL_DOCS as readonly string[]).map((type) => {
                const doc = documents.find((d) => d.docType === type);
                const approved = doc?.status === "approved";
                return (
                  <li key={type} className="flex items-center justify-between py-2.5">
                    <span className="text-slate-700">{DOC_LABEL[type] ?? type}</span>
                    <span
                      className="rounded-full px-2.5 py-1 text-[11px] font-semibold"
                      style={{
                        color: approved ? STATUS_COLOR.delivered : STATUS_COLOR.waiting,
                        backgroundColor: `${approved ? STATUS_COLOR.delivered : STATUS_COLOR.waiting}1f`,
                      }}
                    >
                      {approved ? "onaylı" : (doc?.status ?? "yüklü değil")}
                    </span>
                  </li>
                );
              })}
            </ul>
            <p className="mt-3 text-[11px] text-slate-500">
              Dosya depolama sağlayıcısı bağlı değil: bu sürümde belge yüklenemez, onay meta veri üzerinden verilir.
              {rating ? ` Puanın: ${rating.toFixed(1)} / 5 (${profile.ratingCount} değerlendirme).` : ""}
            </p>
          </Card>

          <Card title="Araçlarım">
            {vehicles.length === 0 ? (
              <p className="py-4 text-sm text-slate-500">Kayıtlı araç yok.</p>
            ) : (
              <ul className="divide-y divide-slate-100 text-sm">
                {vehicles.map((vehicle) => (
                  <li key={vehicle.id} className="flex items-center justify-between py-2.5">
                    <div>
                      <p className="font-medium text-slate-800">{vehicle.plate}</p>
                      <p className="text-xs text-slate-500">
                        {vehicle.make} {vehicle.model} · {vehicle.color} · {vehicle.vehicleType}
                      </p>
                    </div>
                    <span
                      className="rounded-full px-2.5 py-1 text-[11px] font-semibold"
                      style={{
                        color: vehicle.documentsVerified ? STATUS_COLOR.delivered : STATUS_COLOR.waiting,
                        backgroundColor: `${vehicle.documentsVerified ? STATUS_COLOR.delivered : STATUS_COLOR.waiting}1f`,
                      }}
                    >
                      {vehicle.documentsVerified ? "doğrulandı" : "incelemede"}
                    </span>
                  </li>
                ))}
              </ul>
            )}
            {profile.isDemo ? (
              <p className="mt-3 text-[11px] text-slate-500">Bu kayıt demo verisidir; gerçek sürücü değildir.</p>
            ) : null}
          </Card>

          {activeRides.length > 0 ? (
            <Card title="Atanmış yolculuklar">
              <ul className="space-y-2 text-sm">
                {activeRides.map((ride) => (
                  <li key={ride.id}>
                    <Link href={`/app/yolculuk/${ride.id}`} className="text-accent underline-offset-4 hover:underline">
                      {ride.code} → yolculuk ekranı
                    </Link>
                  </li>
                ))}
              </ul>
            </Card>
          ) : null}
        </div>
      </div>

      <div className="mt-6">
        <Card title="Hakediş hareketleri">
          {entries.length === 0 ? (
            <p className="py-4 text-sm text-slate-500">Henüz hakediş yok.</p>
          ) : (
            <ul className="divide-y divide-slate-100 text-sm">
              {entries.map((entry) => (
                <li key={entry.id} className="flex items-center justify-between py-2.5">
                  <div>
                    <p className="text-slate-800">{entry.reason.replaceAll("_", " ")}</p>
                    <p className="text-xs text-slate-500">{new Date(entry.createdAt).toLocaleString("tr-TR")}</p>
                  </div>
                  <span
                    className="font-display text-sm font-bold tabular-nums"
                    style={{ color: entry.side === "credit" ? STATUS_COLOR.delivered : STATUS_COLOR.risk }}
                  >
                    {entry.side === "credit" ? "+" : "−"}
                    {formatTry(entry.amountKurus)}
                  </span>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-3 text-[11px] text-slate-500">
            Komisyon yolculuk kapanışında düşülür; net tutar anında bu cüzdana geçer. Kayıtlar silinemez.
          </p>
        </Card>
      </div>
    </PanelShell>
  );
}
