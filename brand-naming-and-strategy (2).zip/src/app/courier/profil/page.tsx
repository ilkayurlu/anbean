import { redirect } from "next/navigation";
import { and, asc, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { courierCv, courierCvItems, couriers } from "@/db/schema";
import { requireAuth } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import PanelShell from "@/components/PanelShell";
import CvEditor, { type CvItem } from "@/components/admin/CvEditor";

export const dynamic = "force-dynamic";
export const metadata = { title: "Profilim — Anbean Kurye" };

export default async function KuryeProfilPage() {
  const user = await requireAuth();
  if (!user) redirect("/giris");

  const [courier] = await db.select().from(couriers).where(eq(couriers.userId, user.id)).limit(1);
  if (!courier) redirect("/courier");

  const [cv] = await db.select().from(courierCv).where(eq(courierCv.courierId, courier.id)).limit(1);
  const items = cv
    ? await db
        .select()
        .from(courierCvItems)
        .where(and(eq(courierCvItems.cvId, cv.id), isNull(courierCvItems.archivedAt)))
        .orderBy(asc(courierCvItems.sortIndex))
    : [];

  // Kurye kendi CV'sini tüm görünürlük seviyeleriyle görür.
  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Profilim ve CV"
      subtitle={`${courier.city} · ${courier.vehicle} · ${courier.status}`}
      nav={[
        { href: "/courier", label: "Görevler" },
        { href: "/courier/kazanc", label: "Kazanç" },
        { href: "/courier/profil", label: "Profilim" },
      ]}
    >
      <CvEditor
        courierId={courier.id}
        courierName={courier.fullName}
        cv={
          cv
            ? {
                displayName: cv.displayName,
                about: cv.about,
                photoRef: cv.photoRef,
                defaultVisibility: cv.defaultVisibility,
                availabilityNote: cv.availabilityNote,
                vehicleNote: cv.vehicleNote,
                profilePublished: cv.profilePublished,
              }
            : null
        }
        items={items as CvItem[]}
        canEdit={hasPermission(user.role, "cv:manage") || courier.userId === user.id}
      />
    </PanelShell>
  );
}
