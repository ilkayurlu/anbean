import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { invoices, orgMembers, organizations, shipments, subscriptions, plans, supportTickets, users } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import PanelShell, { Card, Metric } from "@/components/PanelShell";
import StatusStrip, { StatusPill } from "@/components/StatusStrip";
import { formatTry } from "@/lib/pricing";
import { STATUS_COLOR } from "@/lib/status";

export const dynamic = "force-dynamic";
export const metadata = { title: "İşletme paneli — Anbean" };

const NAV = [
  { href: "/isletme", label: "Özet" },
  { href: "/app/yeni", label: "Gönderi oluştur" },
  { href: "/admin/isletmeler", label: "İşletme dosyası" },
  { href: "/app/destek", label: "Destek" },
];

/**
 * İşletme (tenant) paneli.
 * Tüm sorgular orgId ile filtrelenir: başka işletmenin verisi sorguya hiç girmez.
 */
export default async function IsletmePanel() {
  const user = await requirePermission("org:read");
  if (!user) redirect("/giris");
  if (!user.orgId) redirect("/app");

  const orgId = user.orgId;
  const [org, orgShipments, memberRows, subscriptionRows, invoiceRows, ticketRows] = await Promise.all([
    db.select().from(organizations).where(eq(organizations.id, orgId)).limit(1),
    db.select().from(shipments).where(eq(shipments.orgId, orgId)).orderBy(desc(shipments.createdAt)).limit(50),
    db.select().from(orgMembers).where(eq(orgMembers.orgId, orgId)),
    db.select().from(subscriptions).where(eq(subscriptions.orgId, orgId)).orderBy(desc(subscriptions.createdAt)).limit(1),
    db.select().from(invoices).where(eq(invoices.orgId, orgId)).orderBy(desc(invoices.createdAt)).limit(10),
    db.select().from(supportTickets).where(eq(supportTickets.orgId, orgId)).orderBy(desc(supportTickets.createdAt)).limit(10),
  ]);

  if (!org[0]) redirect("/app");
  const subscription = subscriptionRows[0] ?? null;
  const plan = subscription ? (await db.select().from(plans).where(eq(plans.id, subscription.planId)).limit(1))[0] ?? null : null;
  const orgUsers = await db.select({ id: users.id, fullName: users.fullName, role: users.role }).from(users).where(eq(users.orgId, orgId));

  const openShipments = orgShipments.filter((s) => !["teslim_edildi", "iptal", "arsivlendi", "iade_edildi"].includes(s.status));
  const spend = orgShipments.reduce((sum, s) => sum + s.priceKurus, 0);

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title={org[0].name}
      subtitle={`İşletme paneli · ${plan?.name ?? "abonelik yok"} · ${org[0].verificationStatus}`}
      nav={NAV}
    >
      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="Açık gönderi" value={String(openShipments.length)} tone={STATUS_COLOR.transit} />
        <Metric label="Toplam gönderi" value={String(orgShipments.length)} />
        <Metric label="Harcama" value={formatTry(spend)} />
        <Metric
          label="Plan limiti"
          value={plan ? `${orgShipments.length}/${plan.shipmentLimit}` : "—"}
          tone={plan && orgShipments.length > plan.shipmentLimit ? STATUS_COLOR.risk : STATUS_COLOR.delivered}
        />
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-[1.3fr_0.7fr]">
        <Card
          title="Gönderiler"
          action={
            <Link href="/app/yeni" className="rounded-md bg-accent px-3.5 py-2 text-xs font-semibold text-[#0B1220]">
              Yeni gönderi
            </Link>
          }
        >
          {orgShipments.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">Henüz gönderi yok.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {orgShipments.map((shipment) => (
                <li key={shipment.id} className="py-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <p className="font-display text-sm font-bold text-[#0B1220]">{shipment.code}</p>
                      <p className="text-xs text-slate-500">
                        {shipment.pickupDistrict} → {shipment.dropDistrict} · {formatTry(shipment.priceKurus)}
                      </p>
                    </div>
                    <StatusPill status={shipment.status} />
                  </div>
                  <StatusStrip status={shipment.status} size="sm" className="mt-2" />
                </li>
              ))}
            </ul>
          )}
        </Card>

        <div className="space-y-5">
          <Card title="Abonelik">
            {subscription && plan ? (
              <>
                <p className="font-display text-lg font-bold text-[#0B1220]">{plan.name}</p>
                <p className="text-xs text-slate-500">
                  {formatTry(plan.monthlyKurus)}/ay · {plan.shipmentLimit} gönderi · {plan.seatLimit} koltuk
                </p>
                <p className="mt-2 text-sm text-slate-600">
                  Durum: <strong>{subscription.status}</strong>
                  {subscription.currentPeriodEnd
                    ? ` · dönem sonu ${new Date(subscription.currentPeriodEnd).toLocaleDateString("tr-TR")}`
                    : ""}
                </p>
              </>
            ) : (
              <p className="text-sm text-slate-500">Abonelik kaydı yok.</p>
            )}
          </Card>

          <Card title="Çalışanlar">
            <ul className="divide-y divide-slate-100 text-sm">
              {memberRows.map((member) => {
                const account = orgUsers.find((u) => u.id === member.userId);
                return (
                  <li key={member.id} className="flex items-center justify-between py-2">
                    <span className="text-slate-700">{account?.fullName ?? `#${member.userId}`}</span>
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-[11px] text-slate-600">{member.orgRole}</span>
                  </li>
                );
              })}
              {memberRows.length === 0 ? <li className="py-3 text-slate-500">Kayıtlı çalışan yok.</li> : null}
            </ul>
          </Card>

          <Card title="Faturalar">
            {invoiceRows.length === 0 ? (
              <p className="text-sm text-slate-500">Fatura yok.</p>
            ) : (
              <ul className="divide-y divide-slate-100 text-sm">
                {invoiceRows.map((invoice) => (
                  <li key={invoice.id} className="flex items-center justify-between py-2">
                    <span className="font-mono text-xs text-slate-600">{invoice.number}</span>
                    <span className="font-semibold text-[#0B1220]">{formatTry(invoice.totalKurus)}</span>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-2 text-[11px] text-slate-500">
              Kart bilgisi saklanmaz; ödeme sağlayıcısı bağlı değil, tahsilat yapılmaz.
            </p>
          </Card>

          <Card title="Destek talepleri">
            {ticketRows.length === 0 ? (
              <p className="text-sm text-slate-500">Talep yok.</p>
            ) : (
              <ul className="divide-y divide-slate-100 text-sm">
                {ticketRows.map((ticket) => (
                  <li key={ticket.id} className="py-2">
                    <p className="text-slate-700">{ticket.subject}</p>
                    <p className="text-[11px] text-slate-500">{ticket.code} · {ticket.status}</p>
                  </li>
                ))}
              </ul>
            )}
            <Link href="/app/destek" className="mt-3 inline-block text-xs font-semibold text-accent">
              Talep aç →
            </Link>
          </Card>
        </div>
      </div>
    </PanelShell>
  );
}
