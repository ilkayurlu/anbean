import { notFound } from "next/navigation";
import { db } from "@/db";
import { passengerRides } from "@/db/schema";
import { eq } from "drizzle-orm";
import PageShell from "@/components/PageShell";
import HailLiveView from "@/components/HailLiveView";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return { title: `Yolculuk #${id} — Anbean` };
}

export default async function YolculukDetayPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const rideId = Number(id);
  if (!Number.isFinite(rideId)) notFound();

  const user = await getSessionUser();
  if (!user) notFound();

  const [ride] = await db.select({ code: passengerRides.code }).from(passengerRides).where(eq(passengerRides.id, rideId)).limit(1);
  if (!ride) notFound();

  return (
    <PageShell eyebrow="Canlı yolculuk" title={ride.code} lead="Durum, buluşma kodu, paylaşım ve acil durum tek ekranda.">
      <HailLiveView rideId={rideId} />
    </PageShell>
  );
}
