import Link from "next/link";
import { redirect } from "next/navigation";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { iotVehicles, passengerRideRequests, passengerRides, rides } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import PanelShell, { Card, Metric } from "@/components/PanelShell";
import { RIDE_STATUS_LABEL_LOCAL } from "@/lib/hail-types";
import { STATE_COPY } from "@/lib/content";
import { formatTry } from "@/lib/pricing";
import { STATUS_COLOR } from "@/lib/status";

export const dynamic = "force-dynamic";
export const metadata = { title: "Yolculuklarım — Anbean" };

const NAV = [
  { href: "/app", label: "Gönderilerim" },
  { href: "/app/siparislerim", label: "Siparişlerim" },
  { href: "/app/yolculuk", label: "Yolculuklarım" },
  { href: "/app/cuzdan", label: "Bakiye" },
  { href: "/hesap/izinler", label: "İzinler" },
];

const ACTIVE = ["REQUESTED", "MATCHING", "DRIVER_ASSIGNED", "DRIVER_EN_ROUTE", "DRIVER_ARRIVED", "IN_PROGRESS", "SAFETY_INCIDENT"];

export default async function YolculuklarimPage() {
  const user = await requirePermission("hail:read");
  if (!user) redirect("/giris");

  const [hailed, rentalRows, vehicles] = await Promise.all([
    db
      .select({
        ride: passengerRides,
        request: passengerRideRequests,
      })
      .from(passengerRides)
      .innerJoin(passengerRideRequests, eq(passengerRideRequests.id, passengerRides.requestId))
      .where(eq(passengerRideRequests.customerId, user.id))
      .orderBy(desc(passengerRides.createdAt))
      .limit(50)
      .catch(() => [] as { ride: typeof passengerRides.$inferSelect; request: typeof passengerRideRequests.$inferSelect }[]),
    db.select().from(rides).where(eq(rides.riderId, user.id)).orderBy(desc(rides.startedAt)).limit(50),
    db.select().from(iotVehicles),
  ]);

  const vehicleById = new Map(vehicles.map((v) => [v.id, v]));
  const activeHailed = hailed.filter((row) => ACTIVE.includes(row.ride.status));
  const spentHailed = hailed.reduce((sum, row) => sum + (row.ride.finalFareKurus ?? 0), 0);
  const spentRental = rentalRows.reduce((sum, row) => sum + row.priceKurus, 0);

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Yolculuklarım"
      subtitle="Sürücülü ve kiralık yolculuklar tek listede. Filtreyle ayırabilirsin."
      nav={NAV}
    >
      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="Devam eden" value={String(activeHailed.length)} tone={STATUS_COLOR.waiting} />
        <Metric label="Sürücülü yolculuk" value={String(hailed.length)} />
        <Metric label="Kiralık sürüş" value={String(rentalRows.length)} tone={STATUS_COLOR.transit} />
        <Metric label="Toplam harcama" value={formatTry(spentHailed + spentRental)} />
      </div>

      {activeHailed.length > 0 ? (
        <div className="mt-6 rounded-lg border border-accent/40 bg-accent/8 p-5">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-accent">Devam edenler</p>
          <ul className="mt-3 space-y-2">
            {activeHailed.map((row) => (
              <li key={row.ride.id} className="flex flex-wrap items-center justify-between gap-3 text-sm">
                <span className="text-slate-200">
                  {row.ride.code} · {RIDE_STATUS_LABEL_LOCAL[row.ride.status] ?? row.ride.status} ·{" "}
                  {row.request.pickupDistrict} → {row.request.dropDistrict}
                </span>
                <Link href={`/app/yolculuk/${row.ride.id}`} className="rounded-md bg-accent px-3 py-1.5 text-xs font-semibold text-[#0B1220]">
                  Aç
                </Link>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <Card
          title="Sürücülü yolculuklar"
          action={
            <Link href="/app/yolculuk/yeni" className="rounded-md bg-accent px-3.5 py-2 text-xs font-semibold text-[#0B1220]">
              Yeni talep
            </Link>
          }
        >
          {hailed.length === 0 ? (
            <p className="py-8 text-center text-sm text-slate-500">Henüz sürücülü yolculuk talebin yok.</p>
          ) : (
            <ul className="divide-y divide-slate-100 text-sm">
              {hailed.map((row) => (
                <li key={row.ride.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <p className="font-medium text-slate-800">
                      {row.ride.code} · {row.request.pickupDistrict} → {row.request.dropDistrict}
                    </p>
                    <p className="text-xs text-slate-500">
                      {new Date(row.ride.createdAt).toLocaleString("tr-TR")} ·{" "}
                      {RIDE_STATUS_LABEL_LOCAL[row.ride.status] ?? row.ride.status}
                      {row.ride.isDemo ? " · pilot" : ""}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-3">
                    <span className="font-display text-sm font-bold tabular-nums">
                      {row.ride.finalFareKurus !== null ? formatTry(row.ride.finalFareKurus) : formatTry(row.ride.quotedFareKurus)}
                    </span>
                    <Link href={`/app/yolculuk/${row.ride.id}`} className="rounded-md border border-slate-200 px-3 py-1.5 text-xs text-slate-600">
                      Detay
                    </Link>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title="Kiralık sürüşler">
          {rentalRows.length === 0 ? (
            <div className="py-8 text-center">
              <p className="text-sm font-medium text-slate-700">{STATE_COPY.emptyRides.title}</p>
              <p className="mt-1 text-sm text-slate-500">{STATE_COPY.emptyRides.body}</p>
            </div>
          ) : (
            <ul className="divide-y divide-slate-100 text-sm">
              {rentalRows.map((row) => (
                <li key={row.id} className="flex items-center justify-between gap-3 py-3">
                  <div>
                    <p className="font-medium text-slate-800">
                      {row.code} · {vehicleById.get(row.vehicleId)?.code ?? "araç"}
                    </p>
                    <p className="text-xs text-slate-500">
                      {new Date(row.startedAt).toLocaleString("tr-TR")} ·{" "}
                      {Math.max(1, Math.round(row.durationSeconds / 60))} dk · {row.distanceKm.toFixed(1)} km
                    </p>
                  </div>
                  <span className="font-display text-sm font-bold tabular-nums">{formatTry(row.priceKurus)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <div className="mt-6">
        <Card title="Filtre">
          <div className="flex flex-wrap gap-2 text-xs">
            {["Tümü", "Sürücülü", "Kiralık", "Tamamlanan", "İptal edilen"].map((chip, index) => (
              <span
                key={chip}
                className={`rounded-full border px-3 py-1.5 ${
                  index === 0 ? "border-accent bg-accent/10 font-semibold text-[#0B1220]" : "border-slate-200 text-slate-600"
                }`}
              >
                {chip}
              </span>
            ))}
          </div>
          <p className="mt-3 text-[11px] text-slate-500">
            Filtre görsel olarak hazır; sunucu tarafı sorgu filtresi bir sonraki fazda bağlanacak. Liste şu an
            ilk 50 kaydı gösteriyor.
          </p>
        </Card>
      </div>

      <p className="mt-4 text-xs text-slate-500">
        Devam eden sayılan durumlar: {ACTIVE.join(", ")}.
      </p>
    </PanelShell>
  );
}
