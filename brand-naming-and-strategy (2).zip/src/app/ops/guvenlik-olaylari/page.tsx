import { redirect } from "next/navigation";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { safetyIncidents, users } from "@/db/schema";
import { requirePermission } from "@/lib/auth";
import { hasPermission } from "@/lib/permissions";
import PanelShell, { Card, Metric } from "@/components/PanelShell";
import SafetyIncidentActions from "@/components/SafetyIncidentActions";
import { STATUS_COLOR } from "@/lib/status";

export const dynamic = "force-dynamic";
export const metadata = { title: "Güvenlik olayları — Anbean" };

const TYPE_LABEL: Record<string, string> = {
  harassment: "Taciz / rahatsızlık",
  accident: "Kaza",
  route_issue: "Rota sapması",
  wrong_vehicle: "Yanlış araç / plaka",
  no_show: "Sürücü gelmedi",
  other: "Diğer",
};
const STATUS_LABEL: Record<string, string> = {
  open: "Açık",
  assigned: "Üstlenildi",
  resolved: "Çözüldü",
  closed: "Kapatıldı",
};
const SEVERITY_COLOR: Record<string, string> = {
  low: STATUS_COLOR.transit,
  medium: STATUS_COLOR.waiting,
  high: "#EA580C",
  critical: STATUS_COLOR.risk,
};

export default async function GuvenlikOlaylariPage() {
  // Bu ekran bir OPERASYON yüzeyi ve filtrelenmemiş tüm olayları listeler.
  // Bu yüzden safety:read değil safety:manage ister: müşterinin kendi
  // bildirimlerini görmesi API üzerinden (kendi kayıtlarına filtreli) olur.
  const user = await requirePermission("safety:manage");
  if (!user) redirect("/giris");
  const canManage = hasPermission(user.role, "safety:manage");

  const incidents = await db.select().from(safetyIncidents).orderBy(desc(safetyIncidents.reportedAt)).limit(200);
  const people = await db.select({ id: users.id, fullName: users.fullName }).from(users);
  const nameById = new Map(people.map((p) => [p.id, p.fullName]));

  const open = incidents.filter((i) => i.status === "open").length;
  const critical = incidents.filter((i) => i.severity === "critical").length;
  const emergency = incidents.filter((i) => i.emergencyCallMade).length;

  return (
    <PanelShell
      role={user.role}
      userName={user.fullName}
      title="Güvenlik olayları"
      subtitle={
        canManage
          ? "Kritik olaylarda sürücü otomatik askıya alınır. Çözüm notları denetim kaydına işlenir."
          : "Okuma yetkin var; atama ve çözüm işlemi safety:manage yetkisi gerektirir."
      }
      nav={[
        { href: "/ops", label: "Dispatch" },
        { href: "/ops/guvenlik-olaylari", label: "Güvenlik" },
        { href: "/admin/suruculer", label: "Sürücüler" },
      ]}
    >
      <div className="grid gap-4 sm:grid-cols-4">
        <Metric label="Toplam olay" value={String(incidents.length)} />
        <Metric label="Açık" value={String(open)} tone={STATUS_COLOR.waiting} />
        <Metric label="Kritik" value={String(critical)} tone={STATUS_COLOR.risk} />
        <Metric label="112 araması" value={String(emergency)} tone={STATUS_COLOR.risk} />
      </div>

      <div className="mt-6">
        <Card title={`Olay akışı · ${incidents.length}`}>
          {incidents.length === 0 ? (
            <p className="py-10 text-center text-sm text-slate-500">Kayıtlı güvenlik olayı yok.</p>
          ) : (
            <ul className="divide-y divide-slate-100">
              {incidents.map((incident) => {
                const color = SEVERITY_COLOR[incident.severity] ?? STATUS_COLOR.neutral;
                return (
                  <li key={incident.id} className="py-4">
                    <div className="flex flex-wrap items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-display text-sm font-bold text-[#0B1220]">
                          {incident.code} · {TYPE_LABEL[incident.incidentType] ?? incident.incidentType}
                        </p>
                        <p className="mt-1 text-xs text-slate-500">
                          {nameById.get(incident.reportedByUserId ?? -1) ?? "bilinmeyen"} ({incident.reportedByRole}) ·{" "}
                          {new Date(incident.reportedAt).toLocaleString("tr-TR")}
                          {incident.rideId ? ` · yolculuk #${incident.rideId}` : ""}
                        </p>
                        {incident.description ? (
                          <p className="mt-2 text-sm text-slate-700">{incident.description}</p>
                        ) : null}
                        {incident.resolutionNote ? (
                          <p className="mt-2 rounded-md bg-slate-50 p-2 text-xs text-slate-600">
                            Çözüm: {incident.resolutionNote}
                          </p>
                        ) : null}
                      </div>
                      <div className="flex shrink-0 flex-col items-end gap-2">
                        <span
                          className="rounded-full px-2.5 py-1 text-[11px] font-semibold"
                          style={{ color, backgroundColor: `${color}1f` }}
                        >
                          {incident.severity}
                        </span>
                        <span className="rounded-full bg-slate-100 px-2.5 py-1 text-[11px] text-slate-600">
                          {STATUS_LABEL[incident.status] ?? incident.status}
                        </span>
                        {incident.emergencyCallMade ? (
                          <span className="rounded-full bg-st-risk/12 px-2.5 py-1 text-[11px] font-semibold text-st-risk">
                            112 arandı
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <SafetyIncidentActions incidentId={incident.id} status={incident.status} canManage={canManage} />
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      </div>

      <p className="mt-6 text-xs text-slate-500">
        Güvenlik rolü yolculuk detayına erişebilir ancak ödeme bilgisini GÖREMEZ; bu filtre API katmanında uygulanır.
      </p>
    </PanelShell>
  );
}
