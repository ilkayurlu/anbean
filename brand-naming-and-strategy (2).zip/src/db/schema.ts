import {
  pgTable,
  serial,
  text,
  timestamp,
  integer,
  boolean,
  jsonb,
  doublePrecision,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Faz 1 — Çekirdek                                                    */
/* ------------------------------------------------------------------ */

export const organizations = pgTable("organizations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  taxNumber: text("tax_number"),
  type: text("type").notNull().default("bireysel"), // bireysel | isletme | kurumsal
  category: text("category").notNull().default(""),
  description: text("description").notNull().default(""),
  logoRef: text("logo_ref").notNull().default(""),
  contactEmail: text("contact_email").notNull().default(""),
  contactPhone: text("contact_phone").notNull().default(""),
  city: text("city").notNull().default(""),
  district: text("district").notNull().default(""),
  workingHours: jsonb("working_hours").$type<Record<string, string>>().notNull().default({}),
  // dogrulanmadi | incelemede | dogrulandi | reddedildi
  verificationStatus: text("verification_status").notNull().default("dogrulanmadi"),
  archivedAt: timestamp("archived_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    fullName: text("full_name").notNull(),
    phone: text("phone"),
    // musteri | kurye | ops | finance | support | admin
    role: text("role").notNull().default("musteri"),
    orgId: integer("org_id").references(() => organizations.id),
    // scrypt hash'i. Doluysa giriş bununla doğrulanır.
    passwordHash: text("password_hash"),
    // Demo hesaplar için geçici erişim kodu; kayıt olan kullanıcılarda boş kalır.
    passcode: text("passcode").notNull().default(""),
    isActive: boolean("is_active").notNull().default(true),
    isBanned: boolean("is_banned").notNull().default(false),
    // Kalıcı silme yerine arşivleme. Listeler varsayılan olarak arşivi gizler.
    archivedAt: timestamp("archived_at", { withTimezone: true }),
    // Yönetici sıfırlamasından sonra ilk girişte şifre değişimi zorunlu.
    mustChangePassword: boolean("must_change_password").notNull().default(false),
    // TOTP sırrı: kurulduktan sonra arayüzde bir daha gösterilmez.
    totpSecret: text("totp_secret"),
    totpEnabled: boolean("totp_enabled").notNull().default(false),
    marketingConsent: boolean("marketing_consent").notNull().default(false),
    kvkkConsentAt: timestamp("kvkk_consent_at", { withTimezone: true }),
    lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("users_email_uq").on(t.email)],
);

export const serviceZones = pgTable("service_zones", {
  id: serial("id").primaryKey(),
  city: text("city").notNull(),
  district: text("district").notNull(),
  zoneCode: text("zone_code").notNull(),
  surchargeKurus: integer("surcharge_kurus").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
});

export const tariffs = pgTable("tariffs", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // sehir_ici | ekspres | kurumsal
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  baseKurus: integer("base_kurus").notNull(),
  perKmKurus: integer("per_km_kurus").notNull(),
  perKgKurus: integer("per_kg_kurus").notNull(),
  slaMinutes: integer("sla_minutes").notNull().default(240),
  accentStatus: text("accent_status").notNull().default("transit"),
  isActive: boolean("is_active").notNull().default(true),
});

export const shipments = pgTable(
  "shipments",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull().unique(), // AB-2026-000123
    orgId: integer("org_id").references(() => organizations.id),
    createdByUserId: integer("created_by_user_id").references(() => users.id),
    tariffCode: text("tariff_code").notNull().default("sehir_ici"),

    status: text("status").notNull().default("taslak"),
    financialStatus: text("financial_status").notNull().default("fatura_bekliyor"),

    senderName: text("sender_name").notNull(),
    senderPhone: text("sender_phone").notNull(),
    pickupCity: text("pickup_city").notNull(),
    pickupDistrict: text("pickup_district").notNull(),
    pickupAddress: text("pickup_address").notNull(),

    recipientName: text("recipient_name").notNull(),
    recipientPhone: text("recipient_phone").notNull(),
    dropCity: text("drop_city").notNull(),
    dropDistrict: text("drop_district").notNull(),
    dropAddress: text("drop_address").notNull(),

    weightGrams: integer("weight_grams").notNull().default(1000),
    distanceKm: doublePrecision("distance_km").notNull().default(5),
    priceKurus: integer("price_kurus").notNull().default(0),
    notes: text("notes").notNull().default(""),

    assignedCourierId: integer("assigned_courier_id"),
    preferredCourierId: integer("preferred_courier_id"),
    etaAt: timestamp("eta_at", { withTimezone: true }),
    deliveredAt: timestamp("delivered_at", { withTimezone: true }),
    // İstisna çözüm saati — rakipte 1 saat, bizde 5 dakika taahhüdü
    exceptionAt: timestamp("exception_at", { withTimezone: true }),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("shipments_status_idx").on(t.status), index("shipments_org_idx").on(t.orgId)],
);

export const shipmentEvents = pgTable(
  "shipment_events",
  {
    id: serial("id").primaryKey(),
    shipmentId: integer("shipment_id")
      .notNull()
      .references(() => shipments.id, { onDelete: "cascade" }),
    status: text("status").notNull(),
    note: text("note").notNull().default(""),
    district: text("district").notNull().default(""),
    actorRole: text("actor_role").notNull().default("sistem"),
    isPublic: boolean("is_public").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("shipment_events_shipment_idx").on(t.shipmentId)],
);

export const trackingTokens = pgTable(
  "tracking_tokens",
  {
    id: serial("id").primaryKey(),
    token: text("token").notNull().unique(),
    shipmentId: integer("shipment_id")
      .notNull()
      .references(() => shipments.id, { onDelete: "cascade" }),
    hitCount: integer("hit_count").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
);

export const auditLog = pgTable("audit_log", {
  id: serial("id").primaryKey(),
  actorId: integer("actor_id"),
  actorRole: text("actor_role").notNull().default("anonim"),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: text("entity_id").notNull().default(""),
  meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
  // Hassas işlemde gerekçe zorunlu (üye durumu, dışa aktarma, finans, askıya alma).
  reason: text("reason").notNull().default(""),
  oldData: jsonb("old_data").$type<Record<string, unknown>>().notNull().default({}),
  newData: jsonb("new_data").$type<Record<string, unknown>>().notNull().default({}),
  ip: text("ip").notNull().default(""),
  userAgent: text("user_agent").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Faz 5 — Operasyon                                                   */
/* ------------------------------------------------------------------ */

export const couriers = pgTable("couriers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  city: text("city").notNull().default("İstanbul"),
  vehicle: text("vehicle").notNull().default("motosiklet"),
  // basvuru | evrak_bekliyor | aktif | pasif
  status: text("status").notNull().default("basvuru"),
  shiftModel: text("shift_model").notNull().default("sozlesmeli"),
  activeLoad: integer("active_load").notNull().default(0),
  ratingSum: integer("rating_sum").notNull().default(0),
  ratingCount: integer("rating_count").notNull().default(0),
  lastLat: doublePrecision("last_lat"),
  lastLng: doublePrecision("last_lng"),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const assignments = pgTable("assignments", {
  id: serial("id").primaryKey(),
  shipmentId: integer("shipment_id")
    .notNull()
    .references(() => shipments.id, { onDelete: "cascade" }),
  courierId: integer("courier_id")
    .notNull()
    .references(() => couriers.id, { onDelete: "cascade" }),
  // beklemede | teklif_edildi | kabul | red | iptal | tamamlandi
  status: text("status").notNull().default("teklif_edildi"),
  offeredAt: timestamp("offered_at", { withTimezone: true }).notNull().defaultNow(),
  respondedAt: timestamp("responded_at", { withTimezone: true }),
});

export const proofOfDeliveries = pgTable("proof_of_deliveries", {
  id: serial("id").primaryKey(),
  shipmentId: integer("shipment_id")
    .notNull()
    .references(() => shipments.id, { onDelete: "cascade" }),
  receivedBy: text("received_by").notNull(),
  method: text("method").notNull().default("imza"), // imza | foto | kod
  code: text("code").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Destek — CMS, medya slotları, bildirim                              */
/* ------------------------------------------------------------------ */

export const mediaSlots = pgTable("media_slots", {
  id: serial("id").primaryKey(),
  slotKey: text("slot_key").notNull().unique(),
  query: text("query").notNull(),
  kind: text("kind").notNull().default("foto"),
  providerId: text("provider_id").notNull().default(""),
  url: text("url").notNull().default(""),
  // Video slotları için zorunlu poster — ilk kare ve "hareketi azalt" yedeği
  posterUrl: text("poster_url").notNull().default(""),
  credit: text("credit").notNull().default("Pexels"),
  fallbackCss: text("fallback_css").notNull().default(""),
  isActive: boolean("is_active").notNull().default(true),
});

export const cmsPages = pgTable("cms_pages", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  // taslak | incelemede | yayinda | arsiv
  status: text("status").notNull().default("yayinda"),
  metaTitle: text("meta_title").notNull().default(""),
  metaDescription: text("meta_description").notNull().default(""),
  authorId: integer("author_id").references(() => users.id),
  version: integer("version").notNull().default(1),
  scheduledFor: timestamp("scheduled_for", { withTimezone: true }),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  archivedAt: timestamp("archived_at", { withTimezone: true }),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  shipmentId: integer("shipment_id").references(() => shipments.id, { onDelete: "cascade" }),
  channel: text("channel").notNull().default("sms"),
  template: text("template").notNull(),
  maskedTarget: text("masked_target").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const courierApplications = pgTable("courier_applications", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  phone: text("phone").notNull(),
  city: text("city").notNull(),
  vehicle: text("vehicle").notNull(),
  experience: text("experience").notNull().default(""),
  status: text("status").notNull().default("yeni"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * Teslimat Güvencesi — SLA aşılırsa otomatik iade kredisi.
 * Rakipte böyle bir taahhüt yok; bizim agresif karşı hamlemiz.
 */
export const slaCredits = pgTable("sla_credits", {
  id: serial("id").primaryKey(),
  shipmentId: integer("shipment_id")
    .notNull()
    .references(() => shipments.id, { onDelete: "cascade" }),
  // gecikme | basarisiz_teslimat | manuel
  reason: text("reason").notNull(),
  amountKurus: integer("amount_kurus").notNull(),
  ratePercent: integer("rate_percent").notNull().default(0),
  // otomatik_onaylandi | odendi | reddedildi
  status: text("status").notNull().default("otomatik_onaylandi"),
  note: text("note").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Kurye şeffaflığı — teslim sonrası puan, kurye profilinde görünür. */
export const courierRatings = pgTable(
  "courier_ratings",
  {
    id: serial("id").primaryKey(),
    courierId: integer("courier_id")
      .notNull()
      .references(() => couriers.id, { onDelete: "cascade" }),
    shipmentId: integer("shipment_id")
      .notNull()
      .references(() => shipments.id, { onDelete: "cascade" }),
    score: integer("score").notNull(),
    comment: text("comment").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("courier_ratings_shipment_uq").on(t.shipmentId)],
);

export type Shipment = typeof shipments.$inferSelect;
export type SlaCredit = typeof slaCredits.$inferSelect;

/* ------------------------------------------------------------------ */
/* Faz 8 — Çift Taraflı Ledger & Cüzdan                                */
/*                                                                     */
/* Master prompt kuralı:                                               */
/*   - bigint kuruş hassasiyeti (kalan int32 ile ~20M TL — yeterli)    */
/*   - append-only, ters kayıt ile iptal, silme YOK                    */
/*   - her işlem dengeli: sum(debit_kurus) = sum(credit_kurus)         */
/* ------------------------------------------------------------------ */

export const wallets = pgTable(
  "wallets",
  {
    id: serial("id").primaryKey(),
    ownerKind: text("owner_kind").notNull(), // user | courier | org | system
    ownerId: integer("owner_id").notNull(),
    currency: text("currency").notNull().default("TRY"),
    balanceKurus: integer("balance_kurus").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("wallets_owner_uq").on(t.ownerKind, t.ownerId)],
);

export const ledgerEntries = pgTable(
  "ledger_entries",
  {
    id: serial("id").primaryKey(),
    walletId: integer("wallet_id")
      .notNull()
      .references(() => wallets.id),
    // debit | credit
    side: text("side").notNull(),
    amountKurus: integer("amount_kurus").notNull(),
    reason: text("reason").notNull(),
    // deposit | ride_charge | ride_payout | courier_payout | guarantee_refund | surge_credit | transfer_in | transfer_out | reversal
    kind: text("kind").notNull(),
    // Aynı işlemin iki bacağı aynı tx_id'yi taşır — denetimde dengeli doğrulanır.
    txId: text("tx_id").notNull(),
    // Webhook ve ödeme tekrarları için — aynı anahtar iki kez işlenemez.
    idempotencyKey: text("idempotency_key").notNull().default(""),
    refKind: text("ref_kind").notNull().default(""), // shipment | ride | field_task | topup
    refId: integer("ref_id"),
    note: text("note").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("ledger_entries_idem_uq").on(t.idempotencyKey),
    index("ledger_entries_tx_idx").on(t.txId),
    index("ledger_entries_wallet_idx").on(t.walletId),
  ],
);

/* ------------------------------------------------------------------ */
/* Faz 5 — Mikro-Mobilite IoT & Filo                                   */
/*                                                                     */
/* Gerçek BLE kilidi sandbox'ta simüle edilir. Şema, kilit aç/kapa     */
/* akışının tamamını sunucu tarafında doğrular (istemci asla tek       */
/* başına kilidi açamaz).                                              */
/* ------------------------------------------------------------------ */

export const iotVehicles = pgTable(
  "iot_vehicles",
  {
    id: serial("id").primaryKey(),
    // scooter | ebike | moped | cargo_bike
    kind: text("kind").notNull(),
    code: text("code").notNull().unique(), // ANB-E0012
    qr: text("qr").notNull().default(""),
    // available | in_use | reserved | maintenance | low_battery | disabled
    status: text("status").notNull().default("available"),
    batteryPercent: integer("battery_percent").notNull().default(85),
    rangeKm: doublePrecision("range_km").notNull().default(35),
    lastLat: doublePrecision("last_lat"),
    lastLng: doublePrecision("last_lng"),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
    city: text("city").notNull().default("İstanbul"),
    district: text("district").notNull().default(""),
    zoneCode: text("zone_code").notNull().default("IST-A"),
    // per_minute_kurus (dinamik surge uygulandığında güncellenir)
    perMinuteKurus: integer("per_minute_kurus").notNull().default(400),
    // Simüle edilmiş IoT kilit durumu — gerçek kilit için MQTT/HTTPS callback
    locked: boolean("locked").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("iot_vehicles_status_idx").on(t.status)],
);

export const vehicleTelemetry = pgTable(
  "vehicle_telemetry",
  {
    id: serial("id").primaryKey(),
    vehicleId: integer("vehicle_id")
      .notNull()
      .references(() => iotVehicles.id, { onDelete: "cascade" }),
    lat: doublePrecision("lat").notNull(),
    lng: doublePrecision("lng").notNull(),
    speedKph: doublePrecision("speed_kph").notNull().default(0),
    batteryPercent: integer("battery_percent").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("vehicle_telemetry_vehicle_idx").on(t.vehicleId)],
);

export const rides = pgTable(
  "rides",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull().unique(), // RIDE-2026-001001
    vehicleId: integer("vehicle_id")
      .notNull()
      .references(() => iotVehicles.id),
    riderId: integer("rider_id").notNull().references(() => users.id),
    // aktif | tamamlandi | iptal | sorunlu
    status: text("status").notNull().default("aktif"),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    endedAt: timestamp("ended_at", { withTimezone: true }),
    durationSeconds: integer("duration_seconds").notNull().default(0),
    distanceKm: doublePrecision("distance_km").notNull().default(0),
    priceKurus: integer("price_kurus").notNull().default(0),
    startLat: doublePrecision("start_lat"),
    startLng: doublePrecision("start_lng"),
    endLat: doublePrecision("end_lat"),
    endLng: doublePrecision("end_lng"),
    // AI doğrulamalı park kanıtı (küratörlü signed URL)
    parkProofUrl: text("park_proof_url").notNull().default(""),
    parkProofScore: doublePrecision("park_proof_score").notNull().default(0),
    surgeMultiplier: doublePrecision("surge_multiplier").notNull().default(1),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("rides_rider_idx").on(t.riderId), index("rides_vehicle_idx").on(t.vehicleId)],
);

/* ------------------------------------------------------------------ */
/* Faz 6 — Saha Görevleri (Hibrit Filo)                                */
/*                                                                     */
/* Master prompt Moat #2: kurye aktif teslimat yokken batarya          */
/* değişimi / arızalı araç toplama yaparak ölü saati sıfırlar.         */
/* ------------------------------------------------------------------ */

export const fieldTasks = pgTable(
  "field_tasks",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull().unique(), // TASK-2026-001001
    // batarya_degisimi | ariza_toplama | arac_yeniden_konumlandirma | kontrol
    kind: text("kind").notNull(),
    vehicleId: integer("vehicle_id").references(() => iotVehicles.id),
    assignedCourierId: integer("assigned_courier_id").references(() => couriers.id),
    // acik | atandi | baslandi | tamamlandi | iptal
    status: text("status").notNull().default("acik"),
    // acil | normal | planli
    priority: text("priority").notNull().default("normal"),
    lat: doublePrecision("lat").notNull(),
    lng: doublePrecision("lng").notNull(),
    district: text("district").notNull().default(""),
    rewardKurus: integer("reward_kurus").notNull().default(0),
    notes: text("notes").notNull().default(""),
    proofUrl: text("proof_url").notNull().default(""),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("field_tasks_status_idx").on(t.status)],
);

/* ------------------------------------------------------------------ */
/* Faz 5 — Dinamik Geo-Fence                                           */
/*                                                                     */
/* Polygon + etki alanı. Gerçek H3 indeksleme yerine basit polygon     */
/* kontrolü (MVP). H3 genişlemesi additive — tabloya hex kolonu eklenir. */
/* ------------------------------------------------------------------ */

export const geoFences = pgTable("geo_fences", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  // speed_limit | no_park | surge | promo | service
  kind: text("kind").notNull(),
  city: text("city").notNull().default("İstanbul"),
  // GeoJSON polygon koordinatları
  polygon: jsonb("polygon").$type<number[][][]>().notNull().default([[]]),
  speedKph: integer("speed_kph"),
  surgeMultiplier: doublePrecision("surge_multiplier"),
  activeFrom: timestamp("active_from", { withTimezone: true }),
  activeUntil: timestamp("active_until", { withTimezone: true }),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Wallet = typeof wallets.$inferSelect;
export type LedgerEntry = typeof ledgerEntries.$inferSelect;
export type IotVehicle = typeof iotVehicles.$inferSelect;
export type FieldTask = typeof fieldTasks.$inferSelect;
export type Ride = typeof rides.$inferSelect;
export type GeoFence = typeof geoFences.$inferSelect;

/* ------------------------------------------------------------------ */
/* Destek, hakediş çıkışı ve şifre sıfırlama                           */
/*                                                                     */
/* Tamamı additive: mevcut tabloların sütunları ve tip'leri değişmedi.  */
/* ------------------------------------------------------------------ */

export const supportTickets = pgTable(
  "support_tickets",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull().unique(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id),
    orgId: integer("org_id").references(() => organizations.id),
    shipmentId: integer("shipment_id").references(() => shipments.id),
    rideId: integer("ride_id").references(() => rides.id),
    // teslimat_sorunu | odeme | arac_sorunu | sikayet | diger
    category: text("category").notNull().default("diger"),
    subject: text("subject").notNull(),
    // acik | isleniyor | cozuldu | kapatildi
    status: text("status").notNull().default("acik"),
    priority: text("priority").notNull().default("normal"),
    assignedToUserId: integer("assigned_to_user_id").references(() => users.id),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("support_tickets_user_idx").on(t.userId), index("support_tickets_status_idx").on(t.status)],
);

export const ticketMessages = pgTable(
  "ticket_messages",
  {
    id: serial("id").primaryKey(),
    ticketId: integer("ticket_id")
      .notNull()
      .references(() => supportTickets.id, { onDelete: "cascade" }),
    authorId: integer("author_id").references(() => users.id),
    authorRole: text("author_role").notNull().default("musteri"),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ticket_messages_ticket_idx").on(t.ticketId)],
);

/**
 * Hakediş çıkışı — maker-checker.
 * Talebi açan ile onaylayan aynı kişi olamaz; onayda çift taraflı kayıt yazılır.
 */
export const payoutRequests = pgTable("payout_requests", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  courierId: integer("courier_id")
    .notNull()
    .references(() => couriers.id),
  amountKurus: integer("amount_kurus").notNull(),
  ibanMasked: text("iban_masked").notNull().default(""),
  // beklemede | onaylandi | odendi | reddedildi
  status: text("status").notNull().default("beklemede"),
  requestedByUserId: integer("requested_by_user_id").references(() => users.id),
  approvedByUserId: integer("approved_by_user_id").references(() => users.id),
  ledgerTxId: text("ledger_tx_id").notNull().default(""),
  note: text("note").notNull().default(""),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const passwordResets = pgTable("password_resets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  // Ham token saklanmaz, yalnızca sha256 özeti.
  tokenHash: text("token_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Yemek dikeyi — pilot katalog                                        */
/*                                                                     */
/* Gerçek restoran iş ortağı yok; katalog is_demo=true ile işaretli ve  */
/* arayüzde her yerde "pilot/demo" olarak etiketlenir. Sahte puan ve    */
/* yorum alanı bilinçli olarak YOKTUR.                                  */
/* ------------------------------------------------------------------ */

export const restaurants = pgTable(
  "restaurants",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull().unique(),
    name: text("name").notNull(),
    cuisine: text("cuisine").notNull().default(""),
    city: text("city").notNull().default("İstanbul"),
    district: text("district").notNull().default(""),
    isOpen: boolean("is_open").notNull().default(true),
    minBasketKurus: integer("min_basket_kurus").notNull().default(0),
    deliveryFeeKurus: integer("delivery_fee_kurus").notNull().default(0),
    serviceFeeKurus: integer("service_fee_kurus").notNull().default(0),
    smallBasketFeeKurus: integer("small_basket_fee_kurus").notNull().default(0),
    prepMinutes: integer("prep_minutes").notNull().default(25),
    // Pilot katalog: arayüzde "demo" rozeti zorunlu, structured data üretilmez.
    isDemo: boolean("is_demo").notNull().default(true),
    note: text("note").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("restaurants_district_idx").on(t.district)],
);

export const menuItems = pgTable(
  "menu_items",
  {
    id: serial("id").primaryKey(),
    restaurantId: integer("restaurant_id")
      .notNull()
      .references(() => restaurants.id, { onDelete: "cascade" }),
    category: text("category").notNull().default(""),
    name: text("name").notNull(),
    description: text("description").notNull().default(""),
    priceKurus: integer("price_kurus").notNull(),
    isAvailable: boolean("is_available").notNull().default(true),
    allergens: text("allergens").notNull().default(""),
    sortIndex: integer("sort_index").notNull().default(0),
  },
  (t) => [index("menu_items_restaurant_idx").on(t.restaurantId)],
);

export const coupons = pgTable("coupons", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  // yuzde | tutar
  kind: text("kind").notNull().default("tutar"),
  value: integer("value").notNull().default(0),
  minBasketKurus: integer("min_basket_kurus").notNull().default(0),
  restaurantId: integer("restaurant_id").references(() => restaurants.id),
  validFrom: timestamp("valid_from", { withTimezone: true }).notNull().defaultNow(),
  validUntil: timestamp("valid_until", { withTimezone: true }),
  usageLimit: integer("usage_limit").notNull().default(0),
  usedCount: integer("used_count").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
});

export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull().unique(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id),
    orgId: integer("org_id").references(() => organizations.id),
    restaurantId: integer("restaurant_id")
      .notNull()
      .references(() => restaurants.id),
    // Sipariş teslimatı mevcut gönderi altyapısına bağlanır: şerit ve takip ortak.
    shipmentId: integer("shipment_id").references(() => shipments.id),
    trackingToken: text("tracking_token").notNull().default(""),
    status: text("status").notNull().default("olusturuldu"),
    subtotalKurus: integer("subtotal_kurus").notNull().default(0),
    deliveryFeeKurus: integer("delivery_fee_kurus").notNull().default(0),
    serviceFeeKurus: integer("service_fee_kurus").notNull().default(0),
    smallBasketFeeKurus: integer("small_basket_fee_kurus").notNull().default(0),
    discountKurus: integer("discount_kurus").notNull().default(0),
    totalKurus: integer("total_kurus").notNull().default(0),
    couponCode: text("coupon_code").notNull().default(""),
    addressText: text("address_text").notNull().default(""),
    district: text("district").notNull().default(""),
    note: text("note").notNull().default(""),
    paymentMethod: text("payment_method").notNull().default("bakiye"),
    financialStatus: text("financial_status").notNull().default("odeme_bekliyor"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    deliveredAt: timestamp("delivered_at", { withTimezone: true }),
  },
  (t) => [index("orders_user_idx").on(t.userId)],
);

export const orderItems = pgTable(
  "order_items",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    menuItemId: integer("menu_item_id").references(() => menuItems.id),
    name: text("name").notNull(),
    unitPriceKurus: integer("unit_price_kurus").notNull(),
    quantity: integer("quantity").notNull().default(1),
  },
  (t) => [index("order_items_order_idx").on(t.orderId)],
);

/** İzin/rıza kayıtları — append-only, sürüm ve kaynak bilgisiyle. */
export const consents = pgTable(
  "consents",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    // aydinlatma | ticari_iletisim | konum | bildirim | cerez_analitik
    category: text("category").notNull(),
    granted: boolean("granted").notNull(),
    policyVersion: text("policy_version").notNull().default("1.0"),
    source: text("source").notNull().default("hesap-merkezi"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("consents_user_idx").on(t.userId, t.category)],
);

export type SupportTicket = typeof supportTickets.$inferSelect;
export type Restaurant = typeof restaurants.$inferSelect;
export type MenuItem = typeof menuItems.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type TicketMessage = typeof ticketMessages.$inferSelect;
export type PayoutRequest = typeof payoutRequests.$inferSelect;
export type ShipmentEvent = typeof shipmentEvents.$inferSelect;
export type Courier = typeof couriers.$inferSelect;
export type Tariff = typeof tariffs.$inferSelect;
export type MediaSlot = typeof mediaSlots.$inferSelect;

/* ------------------------------------------------------------------ */
/* Sürücülü yolculuk modülü — additive                                 */
/*                                                                     */
/* Mevcut `rides` tablosu KİRALIK (self-service mikro-mobilite) içindir */
/* ve DOKUNULMADI. Sürücülü yolculuk ayrı tablolarda yaşar.             */
/*                                                                     */
/* BİLİNLİ OLARAK EKLENMEYEN ALANLAR:                                   */
/*  - genderPreference / cinsiyet bazlı eşleştirme: ayrımcılık mevzuatı  */
/*    riski; hukuk onayı olmadan ürünleşmez, şemaya da alınmadı.        */
/*  - sesKaydı: hukuk onayı gerekli, hiç kurulmadı.                     */
/*  - biyometrik doğrulama: kapsam dışı.                                */
/*  - rating default 5.0: uydurma puan olur; ratingSum/ratingCount ile  */
/*    yalnızca gerçek değerlendirmelerden hesaplanır.                   */
/* ------------------------------------------------------------------ */

export const chauffeurProfiles = pgTable(
  "chauffeur_profiles",
  {
    id: serial("id").primaryKey(),
    // Aday henüz hesap açmamış olabilir; bu yüzden nullable.
    // Hesabı olan sürücülerde rol yükseltmesi belge onayından sonra yapılır.
    userId: integer("user_id").references(() => users.id),
    fullName: text("full_name").notNull(),
    phoneMasked: text("phone_masked").notNull().default(""),
    city: text("city").notNull().default("İstanbul"),
    // aday | belge_bekliyor | aktif | pasif | askida
    status: text("status").notNull().default("aday"),
    // temel | ileri (kimlik+ehliyet+ruhsat+sigorta+sicil)
    verificationLevel: text("verification_level").notNull().default("temel"),
    isVerified: boolean("is_verified").notNull().default(false),
    // Ticari yolcu taşıma belgesi doğrulanmadan teklif alamaz.
    commercialDocsVerified: boolean("commercial_docs_verified").notNull().default(false),
    // offline | online_idle | on_trip
    availability: text("availability").notNull().default("offline"),
    ratingSum: integer("rating_sum").notNull().default(0),
    ratingCount: integer("rating_count").notNull().default(0),
    totalTrips: integer("total_trips").notNull().default(0),
    acceptedOffers: integer("accepted_offers").notNull().default(0),
    declinedOffers: integer("declined_offers").notNull().default(0),
    cancelCount: integer("cancel_count").notNull().default(0),
    lastLat: doublePrecision("last_lat"),
    lastLng: doublePrecision("last_lng"),
    lastLocationAt: timestamp("last_location_at", { withTimezone: true }),
    lastOnlineAt: timestamp("last_online_at", { withTimezone: true }),
    suspendedUntil: timestamp("suspended_until", { withTimezone: true }),
    suspensionReason: text("suspension_reason").notNull().default(""),
    languages: text("languages").notNull().default("tr"),
    // Pilot/demo sürücüler arayüzde açıkça etiketlenir.
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("chauffeur_profiles_availability_idx").on(t.availability), index("chauffeur_profiles_user_idx").on(t.userId)],
);

export const chauffeurDocuments = pgTable(
  "chauffeur_documents",
  {
    id: serial("id").primaryKey(),
    chauffeurId: integer("chauffeur_id")
      .notNull()
      .references(() => chauffeurProfiles.id, { onDelete: "cascade" }),
    // identity | driver_license | vehicle_registration | insurance | criminal_record | commercial_license | fitness_report
    docType: text("doc_type").notNull(),
    // Dosya sağlayıcısı yok: yalnızca meta veri tutulur, içerik saklanmaz.
    storageRef: text("storage_ref").notNull().default(""),
    fileName: text("file_name").notNull().default(""),
    // pending | approved | rejected | expired | not_uploaded
    status: text("status").notNull().default("not_uploaded"),
    issuedAt: timestamp("issued_at", { withTimezone: true }),
    expiresAt: timestamp("expires_at", { withTimezone: true }),
    reviewedBy: integer("reviewed_by"),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    rejectionReason: text("rejection_reason").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("chauffeur_documents_chauffeur_idx").on(t.chauffeurId)],
);

export const chauffeurVehicles = pgTable("chauffeur_vehicles", {
  id: serial("id").primaryKey(),
  chauffeurId: integer("chauffeur_id")
    .notNull()
    .references(() => chauffeurProfiles.id, { onDelete: "cascade" }),
  plate: text("plate").notNull(),
  make: text("make").notNull().default(""),
  model: text("model").notNull().default(""),
  year: integer("year"),
  color: text("color").notNull().default(""),
  seatCount: integer("seat_count").notNull().default(4),
  // standard | comfort | accessible | van
  vehicleType: text("vehicle_type").notNull().default("standard"),
  // private | platform
  ownership: text("ownership").notNull().default("private"),
  isActive: boolean("is_active").notNull().default(true),
  documentsVerified: boolean("documents_verified").notNull().default(false),
  lastInspectionAt: timestamp("last_inspection_at", { withTimezone: true }),
  isDemo: boolean("is_demo").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const chauffeurTariffs = pgTable("chauffeur_tariffs", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(), // suruculu_standart | suruculu_konfor
  name: text("name").notNull(),
  baseKurus: integer("base_kurus").notNull(),
  perKmKurus: integer("per_km_kurus").notNull(),
  perMinKurus: integer("per_min_kurus").notNull(),
  minFareKurus: integer("min_fare_kurus").notNull(),
  nightSurchargePercent: integer("night_surcharge_percent").notNull().default(0),
  airportSurchargeKurus: integer("airport_surcharge_kurus").notNull().default(0),
  cancelFeeKurus: integer("cancel_fee_kurus").notNull().default(0),
  commissionPercent: integer("commission_percent").notNull().default(15),
  surgeMultiplier: doublePrecision("surge_multiplier").notNull().default(1),
  isActive: boolean("is_active").notNull().default(true),
});

export const passengerRideRequests = pgTable(
  "passenger_ride_requests",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull().unique(),
    customerId: integer("customer_id")
      .notNull()
      .references(() => users.id),
    pickupDistrict: text("pickup_district").notNull(),
    pickupAddress: text("pickup_address").notNull(),
    pickupLat: doublePrecision("pickup_lat"),
    pickupLng: doublePrecision("pickup_lng"),
    dropDistrict: text("drop_district").notNull(),
    dropAddress: text("drop_address").notNull(),
    dropLat: doublePrecision("drop_lat"),
    dropLng: doublePrecision("drop_lng"),
    distanceKm: doublePrecision("distance_km").notNull().default(5),
    serviceType: text("service_type").notNull().default("standart"),
    vehicleTypeRequested: text("vehicle_type_requested").notNull().default("standard"),
    paymentMethod: text("payment_method").notNull().default("bakiye"),
    tariffCode: text("tariff_code").notNull().default("suruculu_standart"),
    quotedFareKurus: integer("quoted_fare_kurus").notNull().default(0),
    scheduledFor: timestamp("scheduled_for", { withTimezone: true }),
    note: text("note").notNull().default(""),
    idempotencyKey: text("idempotency_key").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("passenger_ride_requests_idem_uq").on(t.idempotencyKey),
    index("passenger_ride_requests_customer_idx").on(t.customerId),
  ],
);

export const passengerRides = pgTable(
  "passenger_rides",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull().unique(),
    requestId: integer("request_id")
      .notNull()
      .references(() => passengerRideRequests.id),
    chauffeurId: integer("chauffeur_id").references(() => chauffeurProfiles.id),
    vehicleId: integer("vehicle_id").references(() => chauffeurVehicles.id),
    // REQUESTED | MATCHING | DRIVER_ASSIGNED | DRIVER_EN_ROUTE | DRIVER_ARRIVED
    // | IN_PROGRESS | COMPLETED | CANCELLED_BY_PASSENGER | CANCELLED_BY_DRIVER
    // | DRIVER_NO_SHOW | SAFETY_INCIDENT
    status: text("status").notNull().default("REQUESTED"),
    quotedFareKurus: integer("quoted_fare_kurus").notNull().default(0),
    finalFareKurus: integer("final_fare_kurus"),
    commissionKurus: integer("commission_kurus").notNull().default(0),
    tariffCode: text("tariff_code").notNull().default("suruculu_standart"),
    paymentStatus: text("payment_status").notNull().default("odeme_bekliyor"),
    matchedAt: timestamp("matched_at", { withTimezone: true }),
    pickupAt: timestamp("pickup_at", { withTimezone: true }),
    dropoffAt: timestamp("dropoff_at", { withTimezone: true }),
    cancelReason: text("cancel_reason").notNull().default(""),
    cancelFeeKurus: integer("cancel_fee_kurus").notNull().default(0),
    distanceKm: doublePrecision("distance_km").notNull().default(0),
    durationMin: integer("duration_min").notNull().default(0),
    // Buluşma doğrulaması: ham OTP saklanmaz, yalnızca özet.
    pickupOtpHash: text("pickup_otp_hash").notNull().default(""),
    otpVerifiedAt: timestamp("otp_verified_at", { withTimezone: true }),
    customerRating: integer("customer_rating"),
    chauffeurRating: integer("chauffeur_rating"),
    shareToken: text("share_token").notNull().default(""),
    isDemo: boolean("is_demo").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("passenger_rides_status_idx").on(t.status), index("passenger_rides_chauffeur_idx").on(t.chauffeurId)],
);

/** APPEND-ONLY: trigger ile UPDATE/DELETE/TRUNCATE engellenir. */
export const passengerRideEvents = pgTable(
  "passenger_ride_events",
  {
    id: serial("id").primaryKey(),
    rideId: integer("ride_id")
      .notNull()
      .references(() => passengerRides.id, { onDelete: "cascade" }),
    eventType: text("event_type").notNull(),
    actor: text("actor").notNull().default("system"),
    lat: doublePrecision("lat"),
    lng: doublePrecision("lng"),
    note: text("note").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("passenger_ride_events_ride_idx").on(t.rideId)],
);

export const chauffeurOffers = pgTable(
  "chauffeur_offers",
  {
    id: serial("id").primaryKey(),
    rideId: integer("ride_id")
      .notNull()
      .references(() => passengerRides.id, { onDelete: "cascade" }),
    chauffeurId: integer("chauffeur_id")
      .notNull()
      .references(() => chauffeurProfiles.id, { onDelete: "cascade" }),
    quotedEtaSec: integer("quoted_eta_sec").notNull().default(0),
    // sent | accepted | declined | expired
    status: text("status").notNull().default("sent"),
    offeredAt: timestamp("offered_at", { withTimezone: true }).notNull().defaultNow(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    respondedAt: timestamp("responded_at", { withTimezone: true }),
  },
  (t) => [index("chauffeur_offers_expires_idx").on(t.expiresAt), index("chauffeur_offers_ride_idx").on(t.rideId)],
);

export const safetyIncidents = pgTable(
  "safety_incidents",
  {
    id: serial("id").primaryKey(),
    code: text("code").notNull().unique(),
    rideId: integer("ride_id").references(() => passengerRides.id),
    reportedByUserId: integer("reported_by_user_id").references(() => users.id),
    reportedByRole: text("reported_by_role").notNull().default("musteri"),
    // harassment | accident | route_issue | wrong_vehicle | no_show | other
    incidentType: text("incident_type").notNull().default("other"),
    description: text("description").notNull().default(""),
    // low | medium | high | critical
    severity: text("severity").notNull().default("medium"),
    // open | assigned | resolved | closed
    status: text("status").notNull().default("open"),
    assignedToUserId: integer("assigned_to_user_id").references(() => users.id),
    resolutionNote: text("resolution_note").notNull().default(""),
    emergencyCallMade: boolean("emergency_call_made").notNull().default(false),
    reportedAt: timestamp("reported_at", { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (t) => [index("safety_incidents_status_idx").on(t.status)],
);

/** Güvenilen kişi: telefon düz metin saklanmaz, yalnızca özet. */
export const trustedContacts = pgTable("trusted_contacts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  phoneHash: text("phone_hash").notNull(),
  phoneMasked: text("phone_masked").notNull().default(""),
  isVerified: boolean("is_verified").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const rideShareSessions = pgTable(
  "ride_share_sessions",
  {
    id: serial("id").primaryKey(),
    rideId: integer("ride_id")
      .notNull()
      .references(() => passengerRides.id, { onDelete: "cascade" }),
    contactId: integer("contact_id").references(() => trustedContacts.id),
    token: text("token").notNull().unique(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    hitCount: integer("hit_count").notNull().default(0),
    lastHitAt: timestamp("last_hit_at", { withTimezone: true }),
    revokedAt: timestamp("revoked_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("ride_share_sessions_ride_idx").on(t.rideId)],
);

export const chauffeurPayouts = pgTable("chauffeur_payouts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  chauffeurId: integer("chauffeur_id")
    .notNull()
    .references(() => chauffeurProfiles.id),
  amountKurus: integer("amount_kurus").notNull(),
  ibanMasked: text("iban_masked").notNull().default(""),
  // beklemede | onaylandi | odendi | reddedildi
  status: text("status").notNull().default("beklemede"),
  requestedByUserId: integer("requested_by_user_id").references(() => users.id),
  approvedByUserId: integer("approved_by_user_id").references(() => users.id),
  ledgerTxId: text("ledger_tx_id").notNull().default(""),
  note: text("note").notNull().default(""),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const chauffeurApplications = pgTable("chauffeur_applications", {
  id: serial("id").primaryKey(),
  fullName: text("full_name").notNull(),
  phoneMasked: text("phone_masked").notNull().default(""),
  city: text("city").notNull().default("İstanbul"),
  vehicleType: text("vehicle_type").notNull().default("standard"),
  ownership: text("ownership").notNull().default("private"),
  hasCommercialLicense: boolean("has_commercial_license").notNull().default(false),
  experienceYears: integer("experience_years").notNull().default(0),
  note: text("note").notNull().default(""),
  // yeni | belge_bekliyor | incelemede | onaylandi | reddedildi
  status: text("status").notNull().default("yeni"),
  userId: integer("user_id").references(() => users.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type ChauffeurProfile = typeof chauffeurProfiles.$inferSelect;
export type PassengerRide = typeof passengerRides.$inferSelect;
export type PassengerRideRequest = typeof passengerRideRequests.$inferSelect;
export type ChauffeurOffer = typeof chauffeurOffers.$inferSelect;
export type SafetyIncident = typeof safetyIncidents.$inferSelect;

/* ------------------------------------------------------------------ */
/* Yönetim paneli: üyeler, CV, işletme, SaaS, CMS                      */
/*                                                                     */
/* Tamamı additive. Silme yerine ARŞİVLEME (archivedAt) kullanılır;     */
/* kalıcı silme arayüzden sunulmaz.                                     */
/* Hassas alanlar (parola, erişim kodu, kart) hiçbir listeye dönmez.    */
/* ------------------------------------------------------------------ */

/** Yönetici notları — üye/işletme/kurye kayıtlarına eklenir. */
export const adminNotes = pgTable(
  "admin_notes",
  {
    id: serial("id").primaryKey(),
    entityKind: text("entity_kind").notNull(), // user | courier | organization | shipment
    entityId: integer("entity_id").notNull(),
    authorId: integer("author_id").references(() => users.id),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("admin_notes_entity_idx").on(t.entityKind, t.entityId)],
);

/** Kurye CV başlığı. Görünürlük varsayılanı alan bazında cv_items'ta. */
export const courierCv = pgTable("courier_cv", {
  id: serial("id").primaryKey(),
  courierId: integer("courier_id")
    .notNull()
    .references(() => couriers.id, { onDelete: "cascade" })
    .unique(),
  displayName: text("display_name").notNull().default(""),
  about: text("about").notNull().default(""),
  // Dosya sağlayıcısı yok: yalnızca referans/yer tutucu, içerik saklanmaz.
  photoRef: text("photo_ref").notNull().default(""),
  // herkse_acik | personele_acik | gizli
  defaultVisibility: text("default_visibility").notNull().default("personele_acik"),
  availabilityNote: text("availability_note").notNull().default(""),
  vehicleNote: text("vehicle_note").notNull().default(""),
  profilePublished: boolean("profile_published").notNull().default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * CV kalemleri — tek polymorphic tablo.
 * kind: experience | education | skill | certification | language | service_area | portfolio
 * Görünürlük kalem bazında: herkese açık / yalnızca personel / gizli.
 */
export const courierCvItems = pgTable(
  "courier_cv_items",
  {
    id: serial("id").primaryKey(),
    cvId: integer("cv_id")
      .notNull()
      .references(() => courierCv.id, { onDelete: "cascade" }),
    kind: text("kind").notNull(),
    title: text("title").notNull(),
    org: text("org").notNull().default(""),
    startsAt: text("starts_at").notNull().default(""),
    endsAt: text("ends_at").notNull().default(""),
    description: text("description").notNull().default(""),
    // herkse_acik | personele_acik | gizli
    visibility: text("visibility").notNull().default("personele_acik"),
    sortIndex: integer("sort_index").notNull().default(0),
    archivedAt: timestamp("archived_at", { withTimezone: true }),
  },
  (t) => [index("courier_cv_items_cv_idx").on(t.cvId, t.kind)],
);

export const orgMembers = pgTable(
  "org_members",
  {
    id: serial("id").primaryKey(),
    orgId: integer("org_id")
      .notNull()
      .references(() => organizations.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    // sahip | yonetici | calisan
    orgRole: text("org_role").notNull().default("calisan"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("org_members_uq").on(t.orgId, t.userId)],
);

export const plans = pgTable("plans", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  monthlyKurus: integer("monthly_kurus").notNull().default(0),
  shipmentLimit: integer("shipment_limit").notNull().default(100),
  seatLimit: integer("seat_limit").notNull().default(3),
  courierLimit: integer("courier_limit").notNull().default(0),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  isActive: boolean("is_active").notNull().default(true),
});

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: serial("id").primaryKey(),
    orgId: integer("org_id")
      .notNull()
      .references(() => organizations.id, { onDelete: "cascade" }),
    planId: integer("plan_id")
      .notNull()
      .references(() => plans.id),
    // deneme | aktif | gecikmis | iptal | suresi_doldu
    status: text("status").notNull().default("deneme"),
    trialEndsAt: timestamp("trial_ends_at", { withTimezone: true }),
    currentPeriodEnd: timestamp("current_period_end", { withTimezone: true }),
    cancelAtPeriodEnd: boolean("cancel_at_period_end").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("subscriptions_org_idx").on(t.orgId)],
);

/**
 * Fatura. KART VERİSİ SAKLANMAZ: yalnızca sağlayıcı işlem referansı.
 * Ödeme sağlayıcısı bağlı değil; status alanı gerçek tahsilatı iddia etmez.
 */
export const invoices = pgTable(
  "invoices",
  {
    id: serial("id").primaryKey(),
    number: text("number").notNull().unique(),
    orgId: integer("org_id")
      .notNull()
      .references(() => organizations.id),
    subscriptionId: integer("subscription_id").references(() => subscriptions.id),
    amountKurus: integer("amount_kurus").notNull().default(0),
    taxKurus: integer("tax_kurus").notNull().default(0),
    totalKurus: integer("total_kurus").notNull().default(0),
    // taslak | gonderildi | odendi | gecikmis | iptal
    status: text("status").notNull().default("taslak"),
    dueDate: timestamp("due_date", { withTimezone: true }),
    paidAt: timestamp("paid_at", { withTimezone: true }),
    providerRef: text("provider_ref").notNull().default(""),
    note: text("note").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("invoices_org_idx").on(t.orgId)],
);

export const cmsVersions = pgTable(
  "cms_versions",
  {
    id: serial("id").primaryKey(),
    pageId: integer("page_id").notNull(),
    version: integer("version").notNull().default(1),
    title: text("title").notNull().default(""),
    body: text("body").notNull().default(""),
    status: text("status").notNull().default("taslak"),
    authorId: integer("author_id").references(() => users.id),
    changeNote: text("change_note").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("cms_versions_page_idx").on(t.pageId, t.version)],
);

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull().default(""),
  body: text("body").notNull().default(""),
  category: text("category").notNull().default("operasyon"),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  coverSlotKey: text("cover_slot_key").notNull().default(""),
  // taslak | incelemede | yayinda | arsiv
  status: text("status").notNull().default("taslak"),
  scheduledFor: timestamp("scheduled_for", { withTimezone: true }),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  authorId: integer("author_id").references(() => users.id),
  metaTitle: text("meta_title").notNull().default(""),
  metaDescription: text("meta_description").notNull().default(""),
  archivedAt: timestamp("archived_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const emailTemplates = pgTable("email_templates", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  channel: text("channel").notNull().default("email"),
  subject: text("subject").notNull().default(""),
  body: text("body").notNull().default(""),
  isActive: boolean("is_active").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const formSubmissions = pgTable("form_submissions", {
  id: serial("id").primaryKey(),
  formKey: text("form_key").notNull(),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull().default({}),
  handled: boolean("handled").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const platformSettings = pgTable("platform_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: jsonb("value").$type<unknown>().notNull().default({}),
  updatedBy: integer("updated_by").references(() => users.id),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AdminNote = typeof adminNotes.$inferSelect;
export type CourierCv = typeof courierCv.$inferSelect;
export type Plan = typeof plans.$inferSelect;
export type Subscription = typeof subscriptions.$inferSelect;
export type Invoice = typeof invoices.$inferSelect;
